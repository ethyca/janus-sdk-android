package com.ethyca.janussdk.android.consent

import android.content.Context
import android.content.SharedPreferences
import com.ethyca.janussdk.android.Janus
import com.ethyca.janussdk.android.LogLevel
import com.ethyca.janussdk.android.core.JanusProvider
import com.ethyca.janussdk.android.models.ConsentMethod
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.util.*

/**
 * Class for managing user consent storage and retrieval
 */
class ConsentManager : ConsentManagerInterface {
    // MARK: - Properties

    // SharedPreferences key constants
    private val consentKey = "com.ethyca.janus.consent"
    private val consentMetadataKey = "com.ethyca.janus.consent.metadata"
    private val fidesStringKey = "com.ethyca.janus.fides_string"
    private val consentMethodKey = "com.ethyca.janus.consent_method"
    private val fidesUserDeviceIdKey = "com.ethyca.janus.fides_user_device_id"
    private val fidesUserDeviceIdTimestampKey = "com.ethyca.janus.fides_user_device_id_timestamp"

    // SharedPreferences instance
    private val sharedPreferences: SharedPreferences

    // IAB TCF storage for writing to default SharedPreferences
    private val iabTCFStorage: IABTCFStorage

    // Gson for JSON serialization/deserialization
    private val gson = Gson()

    // MARK: - Initialization

    /**
     * Primary constructor using the application context from JanusProvider
     */
    constructor() {
        this.sharedPreferences = JanusProvider.applicationContext.getSharedPreferences(
            "com.ethyca.janus.preferences", Context.MODE_PRIVATE
        )
        this.iabTCFStorage = IABTCFStorage()
    }

    /**
     * Secondary constructor for testing with a mock SharedPreferences
     *
     * @param sharedPreferences The SharedPreferences instance to use
     */
    constructor(sharedPreferences: SharedPreferences) {
        this.sharedPreferences = sharedPreferences
        this.iabTCFStorage = IABTCFStorage(sharedPreferences)
    }

    // MARK: - Public Methods

    /**
     * Get the current consent values
     */
    override fun getConsent(): Map<String, Boolean> {
        return loadConsentValues()
    }

    /**
     * Get the current fides_string
     */
    override fun getFidesString(): String {
        return loadFidesString()
    }

    /**
     * Get metadata about consent timestamps and consent method
     */
    override fun getMetadata(): ConsentMetadata {
        val metadata = loadMetadata()

        // Always include the current consent method
        metadata.consentMethod = loadConsentMethod()

        return metadata
    }

    /**
     * Get the current consent method
     */
    override fun getConsentMethod(): ConsentMethod {
        return loadConsentMethod()
    }

    /**
     * Get or generate the fides_user_device_id
     * This ID is used for privacy preference API calls and persists across app launches
     * For GDPR compliance, device IDs expire after one year and are automatically regenerated
     */
    fun getFidesUserDeviceId(): String {
        val existingId = sharedPreferences.getString(fidesUserDeviceIdKey, null)
        val existingTimestamp = sharedPreferences.getLong(fidesUserDeviceIdTimestampKey, 0)
        
        // Check if we have both ID and timestamp, and if timestamp is still valid (less than 1 year old)
        if (existingId != null && existingTimestamp != 0L && 
            existingTimestamp > Calendar.getInstance().apply { add(Calendar.YEAR, -1) }.timeInMillis) {
            return existingId
        }
        
        // Generate a new UUID and timestamp (either missing or expired)
        val deviceId = UUID.randomUUID().toString()
        val currentTime = System.currentTimeMillis()
        val editor = sharedPreferences.edit()
        editor.putString(fidesUserDeviceIdKey, deviceId)
        editor.putLong(fidesUserDeviceIdTimestampKey, currentTime)
        editor.apply()
        
        val reason = if (existingId == null) "No existing device ID" else "Device ID expired"
        Janus.log("Generated new fides_user_device_id", level = LogLevel.DEBUG, metadata = mapOf(
            "deviceId" to deviceId,
            "reason" to reason
        ))
        
        return deviceId
    }

    /**
     * Set multiple consent values
     * @param values Dictionary of consent values to set
     * @param versionHash Version hash from the privacy experience
     * @param fidesString Optional fides_string to save with the consent values
     * @param consentMethod Optional method used to set consent
     */
    override fun setConsent(values: Map<String, Boolean>, versionHash: String, fidesString: String?, consentMethod: ConsentMethod?) {
        Janus.log("ConsentManager.setConsent called", level = LogLevel.DEBUG, metadata = mapOf(
            "versionHash" to versionHash,
            "consentMethod" to (consentMethod?.value ?: ConsentMethod.UNKNOWN.value),
            "fidesString" to (fidesString ?: ""),
            "consentValues" to values.toString()
        ))

        val consent = getConsent().toMutableMap()
        consent.putAll(values)

        // Use elvis operator to provide default values
        saveConsent(consent, fidesString ?: "", consentMethod ?: ConsentMethod.UNKNOWN, versionHash)
    }

    /**
     * Clear all consent values
     * @param clearMetadata Whether to also clear metadata timestamps
     */
    override fun clearConsent(clearMetadata: Boolean) {
        val editor = sharedPreferences.edit()
        editor.remove(consentKey)
        editor.remove(fidesStringKey)
        editor.remove(consentMethodKey)

        if (clearMetadata) {
            editor.remove(consentMetadataKey)
        }

        editor.apply()

        // Also clear IAB TCF values from default SharedPreferences
        iabTCFStorage.clearIABTCFValues()
    }

    // MARK: - Private Methods

    /**
     * Load consent values from SharedPreferences
     */
    private fun loadConsentValues(): Map<String, Boolean> {
        val consentJson = sharedPreferences.getString(consentKey, null) ?: return emptyMap()

        val type = object : TypeToken<Map<String, Boolean>>() {}.type
        return try {
            gson.fromJson(consentJson, type)
        } catch (e: Exception) {
            emptyMap()
        }
    }

    /**
     * Load metadata from SharedPreferences
     */
    private fun loadMetadata(): ConsentMetadata {
        val metadataJson = sharedPreferences.getString(consentMetadataKey, null) ?: return ConsentMetadata()

        return try {
            gson.fromJson(metadataJson, ConsentMetadata::class.java)
        } catch (e: Exception) {
            ConsentMetadata()
        }
    }

    /**
     * Load fides_string from SharedPreferences
     */
    private fun loadFidesString(): String {
        return sharedPreferences.getString(fidesStringKey, "") ?: ""
    }

    /**
     * Load consent method from SharedPreferences
     */
    private fun loadConsentMethod(): ConsentMethod {
        val methodString = sharedPreferences.getString(consentMethodKey, ConsentMethod.UNKNOWN.value) ?: ConsentMethod.UNKNOWN.value
        return ConsentMethod.fromString(methodString)
    }

    /**
     * Save consent values and update metadata
     */
    private fun saveConsent(consent: Map<String, Boolean>, fidesString: String, consentMethod: ConsentMethod, versionHash: String = "") {
        val editor = sharedPreferences.edit()

        // Store consent values as JSON
        val consentJson = gson.toJson(consent)
        editor.putString(consentKey, consentJson)

        // Save the fidesString
        editor.putString(fidesStringKey, fidesString)

        // Save the consent method
        editor.putString(consentMethodKey, consentMethod.value)

        // Apply all changes
        editor.apply()

        // Update metadata timestamps and version hash
        updateMetadata(versionHash)

        // Update IAB TCF values in default SharedPreferences for third-party SDK compatibility
        iabTCFStorage.updateIABTCFValues(fidesString, Janus.currentExperience)
    }

    /**
     * Update metadata timestamps when consent is modified
     * @param versionHash The version hash of the privacy experience
     */
    private fun updateMetadata(versionHash: String = "") {
        val now = Date()
        val metadata = getMetadata()

        // If the createdAt timestamp doesn't exist, set it
        if (metadata.createdAt == null) {
            metadata.createdAt = now
        }

        metadata.updatedAt = now
        metadata.versionHash = versionHash

        // Save the updated metadata
        val metadataJson = gson.toJson(metadata)
        sharedPreferences.edit().putString(consentMetadataKey, metadataJson).apply()
    }
}