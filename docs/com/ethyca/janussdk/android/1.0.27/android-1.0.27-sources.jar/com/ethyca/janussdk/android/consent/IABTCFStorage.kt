package com.ethyca.janussdk.android.consent

import android.content.Context
import android.content.SharedPreferences
import com.ethyca.janussdk.android.Janus
import com.ethyca.janussdk.android.LogLevel
import com.ethyca.janussdk.android.core.JanusProvider
import com.ethyca.janussdk.android.models.PrivacyExperienceItem

/**
 * Handles writing IAB TCF (Transparency and Consent Framework) values to SharedPreferences.
 *
 * Per the IAB TCF v2.2 Mobile Specification, CMPs must write consent data to the
 * default SharedPreferences so that third-party SDKs (like Google Mobile Ads) can
 * read the values.
 *
 * Reference: https://github.com/InteractiveAdvertisingBureau/GDPR-Transparency-and-Consent-Framework/blob/master/TCFv2/IAB%20Tech%20Lab%20-%20CMP%20API%20v2.md
 *
 * ## Known Limitations
 *
 * 1. **Publisher Restrictions (`IABTCF_PublisherRestrictions{ID}`)**: Not implemented.
 *    The IAB spec defines dynamic keys like `IABTCF_PublisherRestrictions2` (one per purpose ID),
 *    which doesn't fit our static key approach. These would require parsing the Publisher
 *    Restrictions section of the TC string and creating keys dynamically.
 *
 * 2. **Publisher TC Segment Fields**: `IABTCF_PublisherConsent`, `IABTCF_PublisherLegitimateInterests`,
 *    `IABTCF_PublisherCustomPurposesConsents`, and `IABTCF_PublisherCustomPurposesLegitimateInterests`
 *    are only populated when the TC string contains a Publisher TC segment (segment type 3).
 *    The server must generate TC strings with this segment for these fields to have values.
 *
 * 3. **Vendor Data Completeness**: Vendor consent and legitimate interest data is extracted
 *    from the TC string as provided by the server. Not all vendors may be present depending
 *    on the CMP configuration and which vendors were disclosed to the user.
 */
class IABTCFStorage {

    companion object {
        // IAB TCF key constants (public for sharing with Flutter plugins and example apps)
        const val IABTCF_CMP_SDK_ID = "IABTCF_CmpSdkID"
        const val IABTCF_CMP_SDK_VERSION = "IABTCF_CmpSdkVersion"
        const val IABTCF_POLICY_VERSION = "IABTCF_PolicyVersion"
        const val IABTCF_GDPR_APPLIES = "IABTCF_gdprApplies"
        const val IABTCF_PUBLISHER_CC = "IABTCF_PublisherCC"
        const val IABTCF_PURPOSE_ONE_TREATMENT = "IABTCF_PurposeOneTreatment"
        const val IABTCF_USE_NON_STANDARD_TEXTS = "IABTCF_UseNonStandardTexts"
        const val IABTCF_TC_STRING = "IABTCF_TCString"
        const val IABTCF_VENDOR_CONSENTS = "IABTCF_VendorConsents"
        const val IABTCF_VENDOR_LEGITIMATE_INTERESTS = "IABTCF_VendorLegitimateInterests"
        const val IABTCF_PURPOSE_CONSENTS = "IABTCF_PurposeConsents"
        const val IABTCF_PURPOSE_LEGITIMATE_INTERESTS = "IABTCF_PurposeLegitimateInterests"
        const val IABTCF_SPECIAL_FEATURES_OPT_INS = "IABTCF_SpecialFeaturesOptIns"
        const val IABTCF_DISCLOSED_VENDORS = "IABTCF_DisclosedVendors"
        const val IABTCF_PUBLISHER_CONSENT = "IABTCF_PublisherConsent"
        const val IABTCF_PUBLISHER_LEGITIMATE_INTERESTS = "IABTCF_PublisherLegitimateInterests"
        const val IABTCF_PUBLISHER_CUSTOM_PURPOSES_CONSENTS = "IABTCF_PublisherCustomPurposesConsents"
        const val IABTCF_PUBLISHER_CUSTOM_PURPOSES_LEGITIMATE_INTERESTS = "IABTCF_PublisherCustomPurposesLegitimateInterests"
        const val IABTCF_ADDTL_CONSENT = "IABTCF_AddtlConsent"

        // Ethyca CMP constants (registered with IAB)
        const val ETHYCA_CMP_ID = 407
        const val CMP_VERSION = 1

        // TCF policy version for TCF v2.2
        private const val TCF_POLICY_VERSION = 4

        // All IABTCF keys for cleanup and iteration purposes (public for sharing)
        val ALL_IABTCF_KEYS = listOf(
            IABTCF_CMP_SDK_ID,
            IABTCF_CMP_SDK_VERSION,
            IABTCF_POLICY_VERSION,
            IABTCF_GDPR_APPLIES,
            IABTCF_PUBLISHER_CC,
            IABTCF_PURPOSE_ONE_TREATMENT,
            IABTCF_USE_NON_STANDARD_TEXTS,
            IABTCF_TC_STRING,
            IABTCF_VENDOR_CONSENTS,
            IABTCF_VENDOR_LEGITIMATE_INTERESTS,
            IABTCF_PURPOSE_CONSENTS,
            IABTCF_PURPOSE_LEGITIMATE_INTERESTS,
            IABTCF_SPECIAL_FEATURES_OPT_INS,
            IABTCF_DISCLOSED_VENDORS,
            IABTCF_PUBLISHER_CONSENT,
            IABTCF_PUBLISHER_LEGITIMATE_INTERESTS,
            IABTCF_PUBLISHER_CUSTOM_PURPOSES_CONSENTS,
            IABTCF_PUBLISHER_CUSTOM_PURPOSES_LEGITIMATE_INTERESTS,
            IABTCF_ADDTL_CONSENT
        )
    }

    // Use the default SharedPreferences as required by IAB spec
    private val sharedPreferences: SharedPreferences

    /**
     * Primary constructor using the application context from JanusProvider.
     *
     * Uses the default SharedPreferences file ({packageName}_preferences) as required
     * by the IAB TCF v2.2 Mobile Specification for third-party SDK compatibility.
     */
    constructor() {
        val context = JanusProvider.applicationContext
        this.sharedPreferences = context.getSharedPreferences(
            "${context.packageName}_preferences",
            Context.MODE_PRIVATE
        )
    }

    /**
     * Secondary constructor for testing with a mock SharedPreferences
     */
    constructor(sharedPreferences: SharedPreferences) {
        this.sharedPreferences = sharedPreferences
    }

    /**
     * Updates IAB TCF values in SharedPreferences based on the current consent state.
     *
     * @param fidesString The fides_string containing TC string and AC string
     * @param experience The privacy experience containing TCF configuration
     */
    fun updateIABTCFValues(fidesString: String?, experience: PrivacyExperienceItem?) {
        if (experience == null) {
            Janus.log("IABTCFStorage: No experience provided, skipping IAB TCF update", level = LogLevel.DEBUG)
            return
        }

        // Only write IAB TCF values for TCF experiences
        if (!isTCFExperience(experience)) {
            Janus.log("IABTCFStorage: Not a TCF experience, skipping IAB TCF update", level = LogLevel.DEBUG)
            return
        }

        val editor = sharedPreferences.edit()

        // Clear all existing IAB TCF values first to prevent stale data
        // This ensures no leftover values from a previous TC string persist
        ALL_IABTCF_KEYS.forEach { key ->
            editor.remove(key)
        }

        // Write CMP constants
        editor.putInt(IABTCF_CMP_SDK_ID, ETHYCA_CMP_ID)
        editor.putInt(IABTCF_CMP_SDK_VERSION, CMP_VERSION)
        editor.putInt(IABTCF_POLICY_VERSION, TCF_POLICY_VERSION)

        // For TCF experiences, gdprApplies should default to true (1).
        // If a TCF experience is being shown, the server has already determined
        // that TCF/GDPR is relevant for this user.
        editor.putInt(IABTCF_GDPR_APPLIES, 1)

        // Write publisher country code if available
        experience.tcfPublisherCountryCode?.let { countryCode ->
            editor.putString(IABTCF_PUBLISHER_CC, countryCode.uppercase())
        }

        // Extract TC string and AC string from fides_string
        val (tcString, acString) = extractFidesStringComponents(fidesString)

        // Write AC string (Google Additional Consent) if available
        acString?.takeIf { it.isNotEmpty() }?.let {
            editor.putString(IABTCF_ADDTL_CONSENT, it)
        }

        // Write TC string and decoded values if available
        if (tcString.isNotEmpty()) {
            editor.putString(IABTCF_TC_STRING, tcString)

            // Decode TC string to extract individual values
            val decodedValues = decodeTCString(tcString)

            // Write decoded values (no need for remove fallbacks - we cleared everything above)
            decodedValues.purposeOneTreatment?.let {
                editor.putInt(IABTCF_PURPOSE_ONE_TREATMENT, it)
            }
            decodedValues.useNonStandardTexts?.let {
                editor.putInt(IABTCF_USE_NON_STANDARD_TEXTS, it)
            }
            decodedValues.vendorConsents?.let {
                editor.putString(IABTCF_VENDOR_CONSENTS, it)
            }
            decodedValues.vendorLegitimateInterests?.let {
                editor.putString(IABTCF_VENDOR_LEGITIMATE_INTERESTS, it)
            }
            decodedValues.purposeConsents?.let {
                editor.putString(IABTCF_PURPOSE_CONSENTS, it)
            }
            decodedValues.purposeLegitimateInterests?.let {
                editor.putString(IABTCF_PURPOSE_LEGITIMATE_INTERESTS, it)
            }
            decodedValues.specialFeaturesOptIns?.let {
                editor.putString(IABTCF_SPECIAL_FEATURES_OPT_INS, it)
            }
            decodedValues.disclosedVendors?.let {
                editor.putString(IABTCF_DISCLOSED_VENDORS, it)
            }
            decodedValues.publisherConsent?.let {
                editor.putString(IABTCF_PUBLISHER_CONSENT, it)
            }
            decodedValues.publisherLegitimateInterests?.let {
                editor.putString(IABTCF_PUBLISHER_LEGITIMATE_INTERESTS, it)
            }
            decodedValues.publisherCustomPurposesConsents?.let {
                editor.putString(IABTCF_PUBLISHER_CUSTOM_PURPOSES_CONSENTS, it)
            }
            decodedValues.publisherCustomPurposesLegitimateInterests?.let {
                editor.putString(IABTCF_PUBLISHER_CUSTOM_PURPOSES_LEGITIMATE_INTERESTS, it)
            }
        }

        editor.apply()

        Janus.log(
            "IABTCFStorage: Updated IAB TCF values",
            level = LogLevel.DEBUG,
            metadata = mapOf(
                "cmpId" to ETHYCA_CMP_ID.toString(),
                "gdprApplies" to "true",
                "hasTCString" to tcString.isNotEmpty().toString(),
                "region" to (experience.region ?: "unknown")
            )
        )
    }

    /**
     * Clears all IAB TCF values from SharedPreferences.
     * Call this when consent is cleared or the SDK is reset.
     */
    fun clearIABTCFValues() {
        val editor = sharedPreferences.edit()
        ALL_IABTCF_KEYS.forEach { key ->
            editor.remove(key)
        }
        editor.apply()

        Janus.log("IABTCFStorage: Cleared all IAB TCF values", level = LogLevel.DEBUG)
    }

    /**
     * Determines if the experience is a TCF experience.
     */
    private fun isTCFExperience(experience: PrivacyExperienceItem): Boolean {
        // Check for TCF-specific fields
        return experience.tcfPurposeConsentIds?.isNotEmpty() == true ||
                experience.tcfVendorConsentIds?.isNotEmpty() == true ||
                experience.tcfPublisherCountryCode != null ||
                experience.minimalTcf == true
    }

    /**
     * Result of extracting fides_string components
     */
    private data class FidesStringComponents(
        val tcString: String,
        val acString: String?
    )

    /**
     * Extracts the TC string and AC string from a fides_string.
     * The fides_string format is: {TC_STRING},{AC_STRING}
     */
    private fun extractFidesStringComponents(fidesString: String?): FidesStringComponents {
        if (fidesString.isNullOrEmpty()) return FidesStringComponents("", null)

        // Split by comma - TC string is the first part, AC string is the second
        val parts = fidesString.split(",", limit = 2)
        val tcString = parts.firstOrNull()?.trim() ?: ""
        val acString = if (parts.size > 1) parts[1].trim() else null

        return FidesStringComponents(tcString, acString)
    }

    /**
     * Data class to hold decoded TC string values
     */
    private data class DecodedTCValues(
        val purposeOneTreatment: Int? = null,
        val useNonStandardTexts: Int? = null,
        val vendorConsents: String? = null,
        val vendorLegitimateInterests: String? = null,
        val purposeConsents: String? = null,
        val purposeLegitimateInterests: String? = null,
        val specialFeaturesOptIns: String? = null,
        val disclosedVendors: String? = null,
        val publisherConsent: String? = null,
        val publisherLegitimateInterests: String? = null,
        val publisherCustomPurposesConsents: String? = null,
        val publisherCustomPurposesLegitimateInterests: String? = null
    )

    /**
     * Decodes a TC string to extract individual values.
     *
     * The TC string is a base64-encoded binary format defined by IAB.
     * TC string format: {core}.{disclosed-vendors}.{allowed-vendors}.{publisher-tc}
     */
    private fun decodeTCString(tcString: String): DecodedTCValues {
        try {
            // TC strings can have multiple segments separated by '.'
            val segments = tcString.split(".")
            if (segments.isEmpty()) return DecodedTCValues()

            // Parse core segment (always first)
            val coreSegment = segments[0]

            // Decode base64 to bytes
            val bytes = android.util.Base64.decode(coreSegment, android.util.Base64.URL_SAFE)
            if (bytes.size < 15) {
                Janus.log("IABTCFStorage: TC string too short to decode", level = LogLevel.DEBUG)
                return DecodedTCValues()
            }

            // Create a bit reader to extract values
            val bits = BitReader(bytes)

            // TC string v2 format (bit positions from IAB spec):
            // Version: 6 bits (position 0-5)
            val version = bits.readInt(6)
            if (version != 2) {
                Janus.log("IABTCFStorage: Unsupported TC string version: $version", level = LogLevel.DEBUG)
                return DecodedTCValues()
            }

            // Created: 36 bits (position 6-41)
            bits.skip(36)

            // LastUpdated: 36 bits (position 42-77)
            bits.skip(36)

            // CmpId: 12 bits (position 78-89)
            bits.skip(12)

            // CmpVersion: 12 bits (position 90-101)
            bits.skip(12)

            // ConsentScreen: 6 bits (position 102-107)
            bits.skip(6)

            // ConsentLanguage: 12 bits (position 108-119)
            bits.skip(12)

            // VendorListVersion: 12 bits (position 120-131)
            bits.skip(12)

            // TcfPolicyVersion: 6 bits (position 132-137)
            bits.skip(6)

            // IsServiceSpecific: 1 bit (position 138)
            bits.skip(1)

            // UseNonStandardTexts: 1 bit (position 139)
            val useNonStandardTexts = bits.readInt(1)

            // SpecialFeatureOptIns: 12 bits (position 140-151)
            val specialFeaturesOptInsBits = bits.readBits(12)
            val specialFeaturesOptIns = bitsToString(specialFeaturesOptInsBits, 12)

            // PurposesConsent: 24 bits (position 152-175)
            val purposeConsentsBits = bits.readBits(24)
            val purposeConsents = bitsToString(purposeConsentsBits, 24)

            // PurposesLITransparency: 24 bits (position 176-199)
            val purposeLegintBits = bits.readBits(24)
            val purposeLegitimateInterests = bitsToString(purposeLegintBits, 24)

            // PurposeOneTreatment: 1 bit (position 200)
            val purposeOneTreatment = bits.readInt(1)

            // PublisherCC: 12 bits (position 201-212) - already handled from experience
            bits.skip(12)

            // Now we're at the vendor consent section
            // MaxVendorId: 16 bits
            val maxVendorId = bits.readInt(16)

            // IsRangeEncoding: 1 bit
            val isRangeEncoding = bits.readInt(1) == 1

            val vendorConsents: String = when {
                maxVendorId == 0 -> ""  // No vendors - empty string per IAB spec
                !isRangeEncoding -> {
                    // BitField encoding - read maxVendorId bits
                    val vendorConsentBits = bits.readBits(maxVendorId)
                    bitsToString(vendorConsentBits, maxVendorId)
                }
                else -> {
                    // Range encoding - decode to bitfield string
                    decodeRangeToString(bits, maxVendorId)
                }
            }

            // Vendor Legitimate Interests section (same structure as vendor consents)
            // MaxVendorIdLI: 16 bits
            val maxVendorIdLI = bits.readInt(16)

            // IsRangeEncodingLI: 1 bit
            val isRangeEncodingLI = bits.readInt(1) == 1

            val vendorLegitimateInterests: String = when {
                maxVendorIdLI == 0 -> ""  // No vendors with legitimate interests - empty string per IAB spec
                !isRangeEncodingLI -> {
                    // BitField encoding - read maxVendorIdLI bits
                    val vendorLIBits = bits.readBits(maxVendorIdLI)
                    bitsToString(vendorLIBits, maxVendorIdLI)
                }
                else -> {
                    // Range encoding - decode to bitfield string
                    decodeRangeToString(bits, maxVendorIdLI)
                }
            }

            // Parse additional segments (if present)
            // Segment types: 1 = Disclosed Vendors, 2 = Allowed Vendors, 3 = Publisher TC
            var disclosedVendors: String? = null
            var publisherConsent: String? = null
            var publisherLegitimateInterests: String? = null
            var publisherCustomPurposesConsents: String? = null
            var publisherCustomPurposesLegitimateInterests: String? = null

            for (i in 1 until segments.size) {
                try {
                    val segmentBytes = android.util.Base64.decode(segments[i], android.util.Base64.URL_SAFE)
                    if (segmentBytes.isEmpty()) continue

                    val segmentReader = BitReader(segmentBytes)
                    val segmentType = segmentReader.readInt(3)

                    when (segmentType) {
                        1 -> { // Disclosed Vendors
                            disclosedVendors = decodeVendorSegment(segmentReader)
                        }
                        2 -> { // Allowed Vendors (we don't need this per IAB mobile spec)
                            // Skip
                        }
                        3 -> { // Publisher TC
                            val publisherResult = decodePublisherTCSegment(segmentReader)
                            publisherConsent = publisherResult.publisherConsent
                            publisherLegitimateInterests = publisherResult.publisherLegitimateInterests
                            publisherCustomPurposesConsents = publisherResult.customPurposesConsent
                            publisherCustomPurposesLegitimateInterests = publisherResult.customPurposesLegitimateInterests
                        }
                        else -> {
                            Janus.log("IABTCFStorage: Unknown segment type: $segmentType", level = LogLevel.DEBUG)
                        }
                    }
                } catch (e: Exception) {
                    Janus.log("IABTCFStorage: Failed to decode segment $i", level = LogLevel.DEBUG)
                }
            }

            return DecodedTCValues(
                purposeOneTreatment = purposeOneTreatment,
                useNonStandardTexts = useNonStandardTexts,
                vendorConsents = vendorConsents,
                vendorLegitimateInterests = vendorLegitimateInterests,
                purposeConsents = purposeConsents,
                purposeLegitimateInterests = purposeLegitimateInterests,
                specialFeaturesOptIns = specialFeaturesOptIns,
                disclosedVendors = disclosedVendors,
                publisherConsent = publisherConsent,
                publisherLegitimateInterests = publisherLegitimateInterests,
                publisherCustomPurposesConsents = publisherCustomPurposesConsents,
                publisherCustomPurposesLegitimateInterests = publisherCustomPurposesLegitimateInterests
            )
        } catch (e: Exception) {
            Janus.log(
                "IABTCFStorage: Failed to decode TC string",
                level = LogLevel.WARNING,
                metadata = mapOf("error" to (e.message ?: "unknown"))
            )
            return DecodedTCValues()
        }
    }

    /**
     * Converts a list of bits to a binary string representation.
     */
    private fun bitsToString(bits: List<Boolean>, length: Int): String {
        val sb = StringBuilder()
        for (i in 0 until length) {
            sb.append(if (i < bits.size && bits[i]) "1" else "0")
        }
        return sb.toString()
    }

    /**
     * Decodes range-encoded vendor data to a binary string.
     * Range encoding is used when it's more efficient than a bitfield.
     */
    private fun decodeRangeToString(reader: BitReader, maxId: Int): String {
        val bits = BooleanArray(maxId) { false }
        val numEntries = reader.readInt(12)
        for (i in 0 until numEntries) {
            val isRange = reader.readInt(1) == 1
            val startId = reader.readInt(16)
            if (isRange) {
                val endId = reader.readInt(16)
                // Guard against malformed TC strings where startId > endId
                if (startId > endId) continue
                for (vendorId in startId..endId) {
                    if (vendorId > 0 && vendorId <= maxId) {
                        bits[vendorId - 1] = true
                    }
                }
            } else {
                if (startId > 0 && startId <= maxId) {
                    bits[startId - 1] = true
                }
            }
        }
        return bits.map { if (it) "1" else "0" }.joinToString("")
    }

    /**
     * Decodes a vendor segment (Disclosed Vendors or Allowed Vendors).
     * Format: SegmentType (3 bits, already read), MaxVendorId (16 bits), IsRangeEncoding (1 bit), then bitfield or ranges
     */
    private fun decodeVendorSegment(reader: BitReader): String {
        val maxVendorId = reader.readInt(16)
        val isRangeEncoding = reader.readInt(1) == 1

        return when {
            maxVendorId == 0 -> ""
            !isRangeEncoding -> {
                val bits = reader.readBits(maxVendorId)
                bitsToString(bits, maxVendorId)
            }
            else -> decodeRangeToString(reader, maxVendorId)
        }
    }

    /**
     * Result of decoding Publisher TC segment
     */
    private data class PublisherTCResult(
        val publisherConsent: String,
        val publisherLegitimateInterests: String,
        val customPurposesConsent: String,
        val customPurposesLegitimateInterests: String
    )

    /**
     * Decodes the Publisher TC segment.
     * Format: SegmentType (3 bits, already read), PubPurposesConsent (24 bits), PubPurposesLITransparency (24 bits),
     *         NumCustomPurposes (6 bits), CustomPurposesConsent (N bits), CustomPurposesLITransparency (N bits)
     */
    private fun decodePublisherTCSegment(reader: BitReader): PublisherTCResult {
        // Publisher Purposes Consent: 24 bits (purposes 1-24)
        val pubPurposesConsentBits = reader.readBits(24)
        val publisherConsent = bitsToString(pubPurposesConsentBits, 24)

        // Publisher Purposes LI Transparency: 24 bits
        val pubPurposesLIBits = reader.readBits(24)
        val publisherLegitimateInterests = bitsToString(pubPurposesLIBits, 24)

        // Number of Custom Purposes: 6 bits
        val numCustomPurposes = reader.readInt(6)

        val customPurposesConsent: String
        val customPurposesLegitimateInterests: String

        if (numCustomPurposes > 0) {
            // Custom Purposes Consent: numCustomPurposes bits
            val customConsentBits = reader.readBits(numCustomPurposes)
            customPurposesConsent = bitsToString(customConsentBits, numCustomPurposes)

            // Custom Purposes LI Transparency: numCustomPurposes bits
            val customLIBits = reader.readBits(numCustomPurposes)
            customPurposesLegitimateInterests = bitsToString(customLIBits, numCustomPurposes)
        } else {
            customPurposesConsent = ""
            customPurposesLegitimateInterests = ""
        }

        return PublisherTCResult(
            publisherConsent = publisherConsent,
            publisherLegitimateInterests = publisherLegitimateInterests,
            customPurposesConsent = customPurposesConsent,
            customPurposesLegitimateInterests = customPurposesLegitimateInterests
        )
    }

    /**
     * Helper class for reading bits from a byte array.
     */
    private class BitReader(private val bytes: ByteArray) {
        private var bitPosition = 0

        fun readInt(numBits: Int): Int {
            var value = 0
            for (i in 0 until numBits) {
                val byteIndex = bitPosition / 8
                val bitIndex = 7 - (bitPosition % 8)
                if (byteIndex < bytes.size) {
                    val bit = (bytes[byteIndex].toInt() shr bitIndex) and 1
                    value = (value shl 1) or bit
                }
                bitPosition++
            }
            return value
        }

        fun readBits(numBits: Int): List<Boolean> {
            val bits = mutableListOf<Boolean>()
            for (i in 0 until numBits) {
                val byteIndex = bitPosition / 8
                val bitIndex = 7 - (bitPosition % 8)
                if (byteIndex < bytes.size) {
                    val bit = (bytes[byteIndex].toInt() shr bitIndex) and 1
                    bits.add(bit == 1)
                } else {
                    bits.add(false)
                }
                bitPosition++
            }
            return bits
        }

        fun skip(numBits: Int) {
            bitPosition += numBits
        }
    }
}
