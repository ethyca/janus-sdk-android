package com.ethyca.janussdk.android.models

/** Enum representing the different methods by which consent can be collected */
enum class ConsentMethod(val value: String) {
    /** User clicked save button or explicitly saved preferences */
    SAVE("save"),

    /** User clicked accept/opt-in button */
    ACCEPT("accept"),

    /** User clicked reject/opt-out button */
    REJECT("reject"),

    /** User acknowledged a notice (typically for informational notices) */
    ACKNOWLEDGE("acknowledge"),

    /** User dismissed the privacy experience without making explicit choices */
    DISMISS("dismiss"),

    /** Default/fallback value when method is not specified or not known */
    UNKNOWN("unknown"),

    /** Error state when consent method could not be determined */
    ERROR("error"),

    /** Consent was set programmatically by FidesJS (e.g. from a FidesUpdated web event) */
    FIDES_JS_UPDATE("fides_js_update");

    companion object {
        /**
         * Get ConsentMethod from string value, defaulting to UNKNOWN if not found
         * @param value The string value to convert
         * @return The corresponding ConsentMethod or UNKNOWN if not found
         */
        fun fromString(value: String?): ConsentMethod {
            return values().find { it.value == value } ?: UNKNOWN
        }
    }
}

/**
 * Determines the format of consent values returned by external interfaces. Mirrors the
 * ConsentFlagType enum from FidesJS
 */
enum class ConsentFlagType(val value: String) {
    /** Consent values are returned as boolean (true/false) */
    BOOLEAN("boolean"),

    /**
     * Consent values are returned as consent mechanism strings (opt_in, opt_out, acknowledge,
     * not_applicable)
     */
    CONSENT_MECHANISM("consent_mechanism");

    companion object {
        /**
         * Get ConsentFlagType from string value, defaulting to BOOLEAN if not found
         * @param value The string value to convert
         * @return The corresponding ConsentFlagType or BOOLEAN if not found
         */
        fun fromString(value: String?): ConsentFlagType {
            return values().find { it.value == value } ?: BOOLEAN
        }
    }
}

/**
 * Represents user consent preferences as strings. Mirrors the UserConsentPreference enum from
 * FidesJS
 */
enum class UserConsentPreference(val value: String) {
    /** User has opted in to the privacy notice */
    OPT_IN("opt_in"),

    /** User has opted out of the privacy notice */
    OPT_OUT("opt_out"),

    /** User has acknowledged the privacy notice (typically for notice-only mechanisms) */
    ACKNOWLEDGE("acknowledge"),

    /** The privacy notice is not applicable to this user */
    NOT_APPLICABLE("not_applicable");

    companion object {
        /**
         * Get UserConsentPreference from string value, defaulting to OPT_OUT if not found
         * @param value The string value to convert
         * @return The corresponding UserConsentPreference or OPT_OUT if not found
         */
        fun fromString(value: String?): UserConsentPreference {
            return values().find { it.value == value } ?: OPT_OUT
        }
    }
}

/**
 * Represents the mechanism by which consent is collected for a privacy notice. Mirrors the
 * ConsentMechanism enum from FidesJS
 */
enum class ConsentMechanism(val value: String) {
    /** User must actively opt in */
    OPT_IN("opt_in"),

    /** User must actively opt out */
    OPT_OUT("opt_out"),

    /** Notice only - no action required from user */
    NOTICE_ONLY("notice_only");

    companion object {
        /**
         * Get ConsentMechanism from string value, defaulting to OPT_IN if not found
         * @param value The string value to convert
         * @return The corresponding ConsentMechanism or OPT_IN if not found
         */
        fun fromString(value: String?): ConsentMechanism {
            return values().find { it.value == value } ?: OPT_IN
        }
    }
}

/**
 * Controls how non-applicable privacy notices are handled in consent objects.
 * Mirrors the ConsentNonApplicableFlagMode enum from FidesJS
 */
enum class ConsentNonApplicableFlagMode(val value: String) {
    /** Non-applicable notices are omitted from the consent object (default) */
    OMIT("omit"),

    /** Non-applicable notices are included in the consent object with appropriate values */
    INCLUDE("include");

    companion object {
        /**
         * Get ConsentNonApplicableFlagMode from string value, defaulting to OMIT if not found
         * @param value The string value to convert
         * @return The corresponding ConsentNonApplicableFlagMode or OMIT if not found
         */
        fun fromString(value: String?): ConsentNonApplicableFlagMode {
            return values().find { it.value == value } ?: OMIT
        }
    }
}
