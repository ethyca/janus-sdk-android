package com.ethyca.janussdk.android.core

import android.app.Activity
import android.content.Context
import android.webkit.WebView
import com.ethyca.janussdk.android.JanusConfiguration
import com.ethyca.janussdk.android.JanusError
import com.ethyca.janussdk.android.events.JanusEvent
import com.ethyca.janussdk.android.consent.ConsentMetadata
import com.ethyca.janussdk.android.models.ConsentMethod
import com.ethyca.janussdk.android.models.PrivacyExperienceItem
import com.ethyca.janussdk.android.models.IPLocationResponse

/**
 * Core interface that defines the capabilities of the JanusSDK.
 * This interface is implemented by JanusImplementation and used by the JanusSDK facade.
 */
interface JanusInterface {
    /**
     * Initialize the SDK with configuration
     *
     * @param activity The current activity (can be used for UI operations)
     * @param config Configuration data
     * @param completion Callback with success flag and optional error
     */
    fun initialize(activity: Activity, config: JanusConfiguration, completion: (Boolean, JanusError?) -> Unit)

    /**
     * Get the user's region by IP address lookup
     *
     * @param completion Callback with success flag, IPLocationResponse data, and optional error
     */
    fun getLocationByIPAddress(completion: (Boolean, IPLocationResponse?, JanusError?) -> Unit)

    /**
     * Indicates whether a valid privacy experience is available for the current region and property ID
     */
    val hasExperience: Boolean

    /**
     * Determines if the privacy experience should be shown to the user
     * This is based on whether a valid experience exists and if consent is missing or outdated
     */
    val shouldShowExperience: Boolean

    /**
     * The current privacy experience item, if available
     */
    val currentExperience: PrivacyExperienceItem?

    /**
     * Current consent values (format depends on consentFlagType configuration)
     */
    val consent: Map<String, Any>
    
    /**
     * Current consent values as boolean (for internal use only)
     */
    val internalConsent: Map<String, Boolean>

    /**
     * Metadata about the consent including timestamps
     */
    val consentMetadata: ConsentMetadata

    /**
     * Get the Fides string representation of consent
     */
    val fidesString: String

    /**
     * Get the region currently being used by the SDK
     * This is set during initialization from the provided config or IP geolocation
     */
    val region: String

    /**
     * Shows the privacy experience UI
     *
     * @param activity The activity to present from
     */
    fun showExperience(activity: Activity)

    /**
     * Add a consent event listener
     *
     * @param listener Callback function that receives events
     * @return A unique identifier for the listener
     */
    fun addConsentEventListener(listener: (JanusEvent) -> Unit): String

    /**
     * Remove a consent event listener
     *
     * @param listenerId The identifier of the listener to remove
     */
    fun removeConsentEventListener(listenerId: String)

    /**
     * Create a WebView that's configured for consent management
     *
     * @param context The context to create the WebView in
     * @param autoSyncOnStart Whether to enable initial synchronization when the webview loads (default is true)
     * @return A WebView configured for consent management
     */
    fun createConsentWebView(context: Context, autoSyncOnStart: Boolean = true): WebView

    /**
     * Release a WebView created with createConsentWebView
     *
     * @param webView The WebView to release
     */
    fun releaseConsentWebView(webView: WebView)

    /**
     * Clear all consent data
     *
     * @param clearMetadata Whether to also clear metadata
     */
    fun clearConsent(applicationContext: Context? = null, clearMetadata: Boolean = false)

    /**
     * Programmatically set consent values from outside the native privacy experience.
     *
     * Use cases include bidirectional sync with custom WebViews running FidesJS, and
     * pre-populating consent from legacy storage during app migration.
     *
     * @param values Map of notice keys to boolean consent values
     * @param fidesString Optional fides string (TCF use cases)
     * @param consentMethod How consent was collected. Defaults to null (stored as UNKNOWN)
     * @param saveToFides If true, persists to Fides backend via privacy-preferences API.
     *   Silently no-ops if no privacy experience is currently loaded.
     */
    fun setConsent(
        values: Map<String, Boolean>,
        fidesString: String? = null,
        consentMethod: ConsentMethod? = null,
        saveToFides: Boolean = false
    )

    /**
     * Notify event listeners of a new event
     *
     * @param event The event to dispatch
     */
    fun notifyEventListeners(event: JanusEvent)

    /**
     * Whether to map JanusEvents to FidesJS events in WebViews
     */
    val fidesEvents: Boolean
} 
