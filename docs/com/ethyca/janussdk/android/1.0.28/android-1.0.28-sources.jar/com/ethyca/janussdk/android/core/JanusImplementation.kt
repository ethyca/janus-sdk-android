package com.ethyca.janussdk.android.core

import android.app.Activity
import android.content.Context
import android.webkit.WebView
import com.ethyca.janussdk.android.events.*
import com.ethyca.janussdk.android.JanusConfiguration
import com.ethyca.janussdk.android.JanusError
import com.ethyca.janussdk.android.api.APIError
import com.ethyca.janussdk.android.api.IPLocationAPI
import com.ethyca.janussdk.android.api.PrivacyExperienceAPI
import com.ethyca.janussdk.android.api.Result
import com.ethyca.janussdk.android.consent.ConsentManager
import com.ethyca.janussdk.android.consent.ConsentMetadata
import com.ethyca.janussdk.android.models.ConsentMethod
import com.ethyca.janussdk.android.models.ConsentNonApplicableFlagMode
import com.ethyca.janussdk.android.models.IPLocationResponse
import com.ethyca.janussdk.android.models.PrivacyExperienceItem
import com.ethyca.janussdk.android.models.PrivacyExperienceResponse
import com.ethyca.janussdk.android.ui.view.TCFWebViewActivity
import com.ethyca.janussdk.android.utils.TranslationMatcher
import com.ethyca.janussdk.android.webview.WebViewManager
import com.ethyca.janussdk.android.ui.view.TCFWebViewHelper
import com.ethyca.janussdk.android.Janus
import com.ethyca.janussdk.android.LogLevel
import com.ethyca.janussdk.android.api.PrivacyPreferencesAPI
import com.ethyca.janussdk.android.models.ConsentFlagType
import com.ethyca.janussdk.android.models.PrivacyNotice
import com.ethyca.janussdk.android.models.UserPreference
import com.ethyca.janussdk.android.utils.ConsentTransformationUtils
import java.util.*

/// Component type identifiers used in privacy experiences
public enum class ComponentType(val value: String) {
    OVERLAY("overlay"),
    HEADLESS("headless"),
    PRIVACY_CENTER("privacy_center"),
    TCF_OVERLAY("tcf_overlay"),
    BANNER_AND_MODAL("banner_and_modal"),
    MODAL("modal");
}

/**
 * Core implementation of the JanusSDK
 *
 * This class implements the JanusInterface interface and provides the actual
 * functionality of the SDK. It's a singleton accessed through JanusProvider.
 */
class JanusImplementation : JanusInterface {
    private var isInitialized = false
    private var configuration: JanusConfiguration? = null
    private val eventListeners = mutableMapOf<String, (JanusEvent) -> Unit>()
    private var privacyExperienceResponse: PrivacyExperienceResponse? = null
    private var _region: String = ""

    // Flag to control whether to use the main thread handler (for testing)
    var useMainThreadHandler: Boolean = true

    // Lock object for synchronizing experience loading state
    private val experienceLock = Any()

    // Thread-safe flag to prevent showing experience multiple times
    @Volatile
    private var isLoadingExperience: Boolean = false

    // Dependencies
    private lateinit var consentManager: ConsentManager
    private lateinit var privacyExperienceService: PrivacyExperienceAPI
    private val ipLocationAPI: IPLocationAPI

    /**
     * Main constructor
     */
    constructor() {
        // Initialize with default dependencies
        ipLocationAPI = IPLocationAPI.shared
    }

    /**
     * Constructor for dependency injection during testing
     */
    constructor(
        consentManager: ConsentManager,
        privacyExperienceService: PrivacyExperienceAPI,
        ipLocationAPI: IPLocationAPI
    ) {
        this.consentManager = consentManager
        this.privacyExperienceService = privacyExperienceService
        this.ipLocationAPI = ipLocationAPI
    }
    
    /**
     * Get the region currently being used by the SDK
     */
    override val region: String
        get() = _region
    
    // Mock data for initial implementation
    override val hasExperience: Boolean
        get() {
            // First check if we have a valid current experience
            val experience = currentExperience ?: return false

            // Check first if there are privacy notices
            if (experience.privacyNotices?.isNotEmpty() == true) {
                return true
            }

            // If there are no privacy notices, check if the experience config has a title or description
            // in the default translation
            val translations = experience.experienceConfig?.translations ?: return false

            // Look for the default translation
            val defaultTranslation = translations.find { it.isDefault == true } ?: translations.firstOrNull()

            // If there's a default translation with either a title or description, consider it a valid experience
            return defaultTranslation?.let {
                (it.title != null || it.description != null)
            } ?: false
        }

    override val currentExperience: PrivacyExperienceItem?
        get() {
            val items = privacyExperienceResponse?.items ?: return null
            if (items.isEmpty()) return null

            // Filter out these types of experiences
            val filteredItems = items.filter {
                val component = it.experienceConfig?.component ?: ""
                component != ComponentType.OVERLAY.value && 
                component != ComponentType.HEADLESS.value && 
                component != ComponentType.PRIVACY_CENTER.value
            }
            
            if (filteredItems.isEmpty()) return null

            // the backend should not return multiples of these types for a single region, but just in case
            // 1. First try to find tcf_overlay
            val tcfOverlayItem = filteredItems.find {
                it.experienceConfig?.component == ComponentType.TCF_OVERLAY.value
            }
            if (tcfOverlayItem != null) return tcfOverlayItem
            
            // 2. Find first non-modal item (currently this is banner_and_modal)
            val nonModalItem = filteredItems.find {
                it.experienceConfig?.component != ComponentType.MODAL.value
            }
            if (nonModalItem != null) return nonModalItem
            
            // 3. Find first modal item
            val modalItem = filteredItems.find {
                it.experienceConfig?.component == ComponentType.MODAL.value
            }
            
            return modalItem
        }

    override val shouldShowExperience: Boolean
        get() {
            // Check if there is a valid experience
            if (!hasExperience) {
                return false
            }

            // only show modal experiences if called for explicitly
            if (currentExperience?.experienceConfig?.component == ComponentType.MODAL.value) {
                return false
            }

            // If the user's consent was implied, show the experience again
            if (consentManager.getConsentMethod() == ConsentMethod.DISMISS) {
                return true
            }

            // Check if consent is missing or outdated
            // Check if the user's consent collection keys match privacy experience notice keys
            val privacyNotices = currentExperience?.privacyNotices ?: return false
            val existingConsentKeys = internalConsent.keys.toSet()
            val experienceNoticeKeys = privacyNotices.mapNotNull { it.noticeKey }.toSet()

            // If there are notice keys that don't have corresponding consent values, show the experience
            // This checks if experienceNoticeKeys is a subset of existingConsentKeys
            if (!experienceNoticeKeys.all { it in existingConsentKeys }) {
                return true
            }

            // Always resurface banner for TCF unless the saved version_hash matches
            if (currentExperience?.isTCFExperience == true &&
                consentManager.getMetadata().versionHash != (currentExperience?.meta?.versionHash ?: "")) {
                return true
            }

            // Check if consent metadata exists and has an updatedAt timestamp
            val metadata = consentMetadata
            if (metadata.updatedAt == null) {
                return true
            }

            // Check if the updatedAt timestamp is over a year old
            val updatedAt = metadata.updatedAt ?: return false
            val calendar = Calendar.getInstance()
            val oneYearAgo = calendar.apply {
                add(Calendar.YEAR, -1)
            }.time

            if (updatedAt.before(oneYearAgo)) {
                return true
            }

            // If none of the conditions for showing the experience are met, return false
            return false
        }

    override val consent: Map<String, Any>
        get() {
            // Get the consent flag type and non-applicable flag mode from configuration
            val flagType = configuration?.consentFlagType ?: ConsentFlagType.BOOLEAN
            val nonApplicableFlagMode = configuration?.consentNonApplicableFlagMode ?: ConsentNonApplicableFlagMode.OMIT
            
            // Get current privacy notices for transformation context
            val privacyNotices = currentExperience?.privacyNotices
            
            // First, transform consent values based on the flag type
            var transformedConsent = ConsentTransformationUtils.applyOverridesToConsent(
                booleanConsent = internalConsent,
                flagType = flagType,
                privacyNotices = privacyNotices
            )
            
            // Then, handle non-applicable notices based on the flag mode
            val nonApplicableNotices = currentExperience?.nonApplicablePrivacyNotices
            if (nonApplicableNotices != null) {
                transformedConsent = ConsentTransformationUtils.handleNonApplicableNotices(
                    consent = transformedConsent,
                    nonApplicableNotices = nonApplicableNotices,
                    flagType = flagType,
                    mode = nonApplicableFlagMode
                )
            }
            
            // Return the transformed consent dictionary
            return transformedConsent
        }
    
    override val internalConsent: Map<String, Boolean>
        get() = consentManager.getConsent()

    override val consentMetadata: ConsentMetadata
        get() = consentManager.getMetadata()

    override val fidesString: String
        get() = consentManager.getFidesString()

    override val fidesEvents: Boolean
        get() = configuration?.fidesEvents ?: true

    override fun initialize(activity: Activity, config: JanusConfiguration, completion: (Boolean, JanusError?) -> Unit) {
        // Reset all state variables at the beginning of initialization to prevent stale data
        privacyExperienceResponse = null
        _region = ""
        isInitialized = false

        // Store the application context from the activity
        JanusProvider.setApplicationContext(activity.applicationContext)

        // Initialize ConsentManager with application context if it hasn't been initialized yet
        // This is only needed for the default constructor case
        if (!::consentManager.isInitialized) {
            consentManager = ConsentManager()
        }

        // Store configuration
        configuration = config
        
        // Store configuration in JanusProvider for other components to access
        JanusProvider.setConfiguration(config)

        // Configure WebViewManager with the fidesEvents setting
        WebViewManager.configure(fidesEvents = config.fidesEvents)

        // Check if the API host is valid
        if (config.apiHost.isEmpty()) {
            completion(false, JanusError.InvalidConfiguration())
            return
        }

        // TODO: fix with proper DI, for now this prevents overwriting mock privacy experience APIs
        if (!config.apiHost.startsWith("mock://")) {
            // Create a new instance with the configured API host
            Janus.log("Using API Host: ${config.apiHost}", level = LogLevel.INFO)
            privacyExperienceService = PrivacyExperienceAPI(config.apiHost)
        }

        // Create a wrapper completion handler that shows the experience after success
        val wrappedCompletion: (Boolean, JanusError?) -> Unit = { success, error ->
            // Call the original completion handler first
            completion(success, error)

            // If initialization was successful, try to show the experience if autoShowExperience is true
            if (success && config.autoShowExperience) {
                if (useMainThreadHandler) {
                    // Use a handler to post on main thread
                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                        autoShowExperienceIfAvailable(activity)
                    }
                } else {
                    // Skip the handler in test environments
                    autoShowExperienceIfAvailable(activity)
                }
            }
        }

        // If a region is provided, use it directly
        if (config.region.isNotEmpty()) {
            Janus.log("Using provided region '${config.region}' and skipping IP location detection", level = LogLevel.INFO)
            _region = config.region
            fetchPrivacyExperience(
                region = config.region,
                propertyId = config.propertyId,
                completion = wrappedCompletion
            )
            return
        }

        // If ipLocation is true, use the IPLocationAPI to fetch region
        if (config.ipLocation) {
            getLocationByIPAddress { success, locationData, error ->
                if (success) {
                    // Use the location property for the region
                    val region = locationData?.location ?: ""
                    if (region.isNotEmpty()) {
                        Janus.log("Using IP-detected region '${region}'", level = LogLevel.INFO)
                        _region = region
                        fetchPrivacyExperience(
                            region = region, 
                            propertyId = config.propertyId, 
                            completion = wrappedCompletion
                        )
                    } else {
                        // If location API returned empty or null location
                        completion(false, JanusError.NoRegionProvidedIPLocationFailed(locationData))
                    }
                } else {
                    // Handle geolocation failure
                    if (error is JanusError.IPLocationFailed) {
                        completion(false, JanusError.NoRegionProvidedIPLocationFailed(error.ipLocationResponse))
                    } else {
                        completion(false, error)
                    }
                }
            }
        } else {
            // If both region is empty and ipLocation is false, throw noRegionProvided error
            completion(false, JanusError.NoRegionProvidedIPLocationFalse())
        }
    }
    
    /**
     * Get the user's region by IP address lookup
     *
     * @param completion Callback with success flag, IPLocationResponse data, and optional error
     */
    override fun getLocationByIPAddress(completion: (Boolean, IPLocationResponse?, JanusError?) -> Unit) {
        fetchIPLocation { result ->
            when (result) {
                is Result.Success -> {
                    val locationData = result.value
                    // Check if the location data is valid (has at least a country or region)
                    if (locationData.location.isNullOrEmpty() && locationData.country.isNullOrEmpty() && locationData.region.isNullOrEmpty()) {
                        // Empty or invalid data
                        completion(false, locationData, JanusError.IPLocationFailed(locationData))
                    } else {
                        // Success with valid data
                        completion(true, locationData, null)
                    }
                }
                is Result.Failure -> {
                    // Network error or other API error
                    completion(false, null, JanusError.NetworkError(result.error))
                }
            }
        }
    }
    
    override fun showExperience(activity: Activity) {
        if (!isInitialized) {
            throw JanusError.NotInitialized()
        }

        // Check if a privacy experience is available
        if (!hasExperience) {
            Janus.log("Show experience called, but there is no privacy experience", level = LogLevel.WARNING)
            return
        }

        // Check if we're already showing an experience to prevent duplicates
        synchronized(experienceLock) {
            if (isLoadingExperience) {
                Janus.log("Show experience called, but experience is already loading", level = LogLevel.WARNING)
                return
            }
            isLoadingExperience = true
        }

        // Get the current experience
        currentExperience?.let {
            // Determine if this is a TCF experience
            if (it.isTCFExperience == true) {
                // Get the preferred locale for the TCF experience
                val preferredLocale = TranslationMatcher.preferredLocale(it.availableLocales)

                // Show TCF experience
                showTCFExperience(activity, preferredLocale)
            } else {
                // Launch the standard Privacy Experience Activity
                val intent = android.content.Intent(activity, com.ethyca.janussdk.android.ui.view.PrivacyExperienceActivity::class.java)
                activity.startActivity(intent)

                // Notify listeners that experience was shown
                notifyEventListeners(ExperienceShownEvent())
                
                // Reset the flag since experience is now shown
                synchronized(experienceLock) {
                    isLoadingExperience = false
                }
            }
        }
    }

    /**
     * Shows the TCF privacy experience in a full-screen modal.
     *
     * @param activity The activity from which to show the experience
     * @param preferredLocale The preferred locale for the TCF experience
     */
    private fun showTCFExperience(activity: Activity, preferredLocale: String) {
        // Get the configuration
        val config = configuration ?: throw JanusError.NotInitialized()
        
        // Prefer privacyCenterHost if available, otherwise fall back to apiHost
        val host = config.privacyCenterHost.ifEmpty {
            config.apiHost
        }

        // Use the helper to create a ready WebView, then start the activity
        TCFWebViewHelper.createReadyWebView(
            context = activity,
            host = host,
            region = config.region,
            propertyId = config.propertyId,
            preferredLocale = preferredLocale
        ) { webViewId ->
            // This callback is called when webView is ready (after element detection + delay)
            val intent = TCFWebViewActivity.createIntent(activity, webViewId)
            activity.startActivity(intent)
            
            // Generate and fire the appropriate event when the view is shown
            val showEvent = ExperienceShownEvent()
            notifyEventListeners(showEvent)
            
            // Reset the flag since experience is now shown
            synchronized(experienceLock) {
                isLoadingExperience = false
            }
        }
    }

    override fun addConsentEventListener(listener: (JanusEvent) -> Unit): String {
        val id = UUID.randomUUID().toString()
        eventListeners[id] = listener
        return id
    }

    override fun removeConsentEventListener(listenerId: String) {
        eventListeners.remove(listenerId)
    }

    override fun createConsentWebView(context: Context, autoSyncOnStart: Boolean): WebView {
        if (!isInitialized) {
            throw JanusError.NotInitialized()
        }

        // Use WebViewManager to create and manage the WebView
        return WebViewManager.createConsentWebView(context, autoSyncOnStart)
    }

    override fun releaseConsentWebView(webView: WebView) {
        // Use WebViewManager to release the WebView and clean up resources
        WebViewManager.releaseConsentWebView(webView)
    }

    override fun clearConsent(applicationContext: Context?, clearMetadata: Boolean) {
        // if an application context was provided use that to establish the shared preferences to clear
        applicationContext?.let {
            JanusProvider.setApplicationContext(applicationContext)
            if (!::consentManager.isInitialized) {
                consentManager = ConsentManager()
            }
        }

        if (!::consentManager.isInitialized) {
            throw IllegalStateException(
                "Application context must be set before accessing this method. Either call Janus.initialize() or provide the applicationContext parameter."
            )
        }

        consentManager.clearConsent(clearMetadata)

        if (isInitialized) {
            // Propagate the empty consent to all managed WebViews
            WebViewManager.propagateConsentToOtherWebViews(
                consentValues = emptyMap(),
                sourceWebView = null,
                consentMethod = "janus_clear"
            )
        }
    }

    override fun notifyEventListeners(event: JanusEvent) {
        eventListeners.values.forEach { listener ->
            listener(event)
        }
    }

    override fun setConsent(
        values: Map<String, Boolean>,
        fidesString: String?,
        consentMethod: ConsentMethod?,
        saveToFides: Boolean
    ) {
        consentManager.setConsent(
            values = values,
            versionHash = Janus.currentExperience?.meta?.versionHash ?: "",
            fidesString = fidesString,
            consentMethod = consentMethod
        )

        notifyEventListeners(ExperienceSelectionUpdatedEvent())

        // No source WebView to exclude — propagates to all managed WebViews.
        // Loop prevention relies on FidesJS idempotency (FidesUpdated is not re-fired when
        // consent values are unchanged). Internal WebView-initiated paths pass sourceWebView
        // via propagateConsentToOtherWebViews(sourceWebView:) to exclude the origin WebView.
        // Use Janus.consent (transformed per consentFlagType) rather than the raw boolean
        // values map, to match the format the WebView-initiated path sends.
        WebViewManager.propagateConsentToOtherWebViews(
            consentValues = Janus.consent,
            sourceWebView = null,
            consentMethod = consentMethod?.value
        )

        if (!saveToFides) return
        val experience = Janus.currentExperience ?: return

        val effectiveConsentMethod = consentMethod ?: ConsentMethod.SAVE
        val preferences = buildPreferencesFromExperience(
            consentChanges = values,
            consentMethod = effectiveConsentMethod,
            notices = experience.privacyNotices ?: emptyList()
        )
        if (preferences.isEmpty()) return

        PrivacyPreferencesAPI().savePrivacyPreferencesRaw(
            consentChanges = values,
            consentMethod = effectiveConsentMethod,
            fidesString = fidesString,
            preferences = preferences,
            privacyExperienceConfigHistoryId = experience.experienceConfig?.translations?.firstOrNull()?.privacyExperienceConfigHistoryId,
            servedNoticeHistoryId = null
        )
    }

    private fun buildPreferencesFromExperience(
        consentChanges: Map<String, Boolean>,
        consentMethod: ConsentMethod,
        notices: List<PrivacyNotice>
    ): List<UserPreference> {
        val matchedKeys = mutableSetOf<String>()
        val preferences = notices.flatMap { it.allNotices }.mapNotNull { notice ->
            val key = notice.noticeKey ?: return@mapNotNull null
            val value = consentChanges[key] ?: return@mapNotNull null
            val historyId = TranslationMatcher.find(notice.translations)?.privacyNoticeHistoryId ?: return@mapNotNull null
            matchedKeys.add(key)
            val preference = when {
                consentMethod == ConsentMethod.ACKNOWLEDGE -> "acknowledge"
                value -> "opt_in"
                else -> "opt_out"
            }
            UserPreference(privacyNoticeHistoryId = historyId, preference = preference)
        }
        consentChanges.keys.filter { it !in matchedKeys }.forEach { key ->
            Janus.log("No privacy notice found for consent key '$key' — skipping server sync for this key", level = LogLevel.WARNING)
        }
        return preferences
    }

    /**
     * Fetch location data using IP geolocation
     *
     * @param completion Callback with the result
     */
    private fun fetchIPLocation(completion: (Result<IPLocationResponse>) -> Unit) {
        ipLocationAPI.fetchLocation(completion)
    }

    /**
     * Fetch privacy experience data from the API
     *
     * @param region The region code for the privacy experience
     * @param propertyId The property ID for the privacy experience (optional)
     * @param fetchFullExperienceAsync Whether to fetch the full experience asynchronously after the minimal one
     * @param completion Completion handler called when the fetch completes
     */
    private fun fetchPrivacyExperience(
        region: String,
        propertyId: String?,
        fetchFullExperienceAsync: Boolean = false,
        completion: (Boolean, JanusError?) -> Unit
    ) {
        // First fetch with minimal TCF for faster initial loading
        privacyExperienceService.fetchPrivacyExperiences(
            region = region,
            propertyId = propertyId,
            page = null,
            size = null,
            minimalTcf = true
        ) { result ->
            when (result) {
                is Result.Success -> {
                    // Store the minimal response
                    privacyExperienceResponse = result.value
                    isInitialized = true

                    // Synchronously prepopulate required consent (notice_only) before returning
                    try {
                        currentExperience?.let { experience ->
                            // Flatten notices
                            val flattened = mutableListOf<com.ethyca.janussdk.android.models.PrivacyNotice>()
                            fun walk(n: com.ethyca.janussdk.android.models.PrivacyNotice) {
                                flattened.add(n)
                                n.children?.forEach { walk(it) }
                            }
                            experience.privacyNotices?.forEach { walk(it) }

                            // Only prepopulate when non-applicable flag mode is INCLUDE
                            val mode = configuration?.consentNonApplicableFlagMode ?: ConsentNonApplicableFlagMode.OMIT
                            if (mode == ConsentNonApplicableFlagMode.INCLUDE) {
                                // Set notice_only to true
                                val requiredKeys = flattened
                                    .filter { it.consentMechanism == "notice_only" }
                                    .mapNotNull { it.noticeKey }

                                if (requiredKeys.isNotEmpty() || (experience.nonApplicablePrivacyNotices?.isNotEmpty() == true)) {
                                    val initial = consentManager.getConsent().toMutableMap()
                                    requiredKeys.forEach { initial[it] = true }
                                    // Also mark non-applicable as true in boolean mode when including
                                    experience.nonApplicablePrivacyNotices?.forEach { key -> initial[key] = true }
                                    // Preserve existing fidesString to avoid clearing saved TC string
                                    consentManager.setConsent(
                                        values = initial,
                                        versionHash = experience.meta?.versionHash ?: "",
                                        fidesString = consentManager.getFidesString(),
                                        consentMethod = com.ethyca.janussdk.android.models.ConsentMethod.ACKNOWLEDGE
                                    )
                                }
                            }
                        }
                    } catch (e: Exception) {
                        Janus.log("Prepopulate required consent failed", level = LogLevel.WARNING, error = e)
                    }

                    // Call the completion handler with success
                    completion(true, null)

                    // Optionally fetch the full version asynchronously if requested
                    if (fetchFullExperienceAsync) {
                        privacyExperienceService.fetchPrivacyExperiences(
                            region = region,
                            propertyId = propertyId,
                            page = null,
                            size = null,
                            minimalTcf = false
                        ) { fullResult ->
                            when (fullResult) {
                                is Result.Success -> {
                                    // Replace the minimal response with the full one
                                    privacyExperienceResponse = fullResult.value
                                    Janus.log("Full privacy experience data loaded successfully", level = LogLevel.DEBUG)
                                }
                                is Result.Failure -> {
                                    // Just log the error but don't fail - we already have the minimal data
                                    Janus.log("Failed to load full privacy experience data", level = LogLevel.ERROR, error = fullResult.error)
                                }
                            }
                        }
                    }
                }
                is Result.Failure -> {
                    // Map APIError to JanusError
                    val error = result.error
                    val janusError = when (error) {
                        is APIError.NetworkError ->
                            JanusError.NetworkError(error.error)
                        is APIError.ServerError ->
                            if (error.code == 401 || error.code == 403) {
                                JanusError.AuthenticationFailed()
                            } else {
                                JanusError.ApiError(error.errorMessage)
                            }
                        is APIError.InvalidURL,
                        is APIError.InvalidResponse,
                        is APIError.DecodingError,
                        is APIError.UnknownError,
                        is APIError.NoData ->
                            JanusError.ApiError(error.message)
                        is APIError.BadResponse ->
                            JanusError.ApiError("Bad response with status code: ${error.statusCode}")
                    }
                    completion(false, janusError)
                }
            }
        }
    }

    /**
     * Automatically show the privacy experience if one is available
     * This is called after successful SDK initialization
     *
     * @param activity The current activity to show the experience from
     */
    private fun autoShowExperienceIfAvailable(activity: Activity) {
        Janus.log("Checking if privacy experience should be shown after initialization", level = LogLevel.DEBUG)

        // Only proceed if shouldShowExperience is true
        if (!shouldShowExperience) {
            Janus.log("Not showing privacy experience, shouldShowExperience is false", level = LogLevel.DEBUG)
            return
        }

        Janus.log("Automatically showing privacy experience after initialization", level = LogLevel.INFO)

        try {
            if (useMainThreadHandler) {
                // We have a direct reference to the activity now, no need for complex introspection
                showExperience(activity)
            } else {
                // In test environments, just log that we would show the experience
                Janus.log("Would show privacy experience (skipped in test environment)", level = LogLevel.DEBUG)
            }
        } catch (e: Exception) {
            Janus.log("Failed to automatically show privacy experience", level = LogLevel.ERROR, error = e)
        }
    }
}
