package com.ethyca.janussdk.android

import android.app.Activity
import android.content.Context
import android.webkit.WebView
import com.ethyca.janussdk.android.core.JanusProvider
import com.ethyca.janussdk.android.consent.ConsentMetadata
import com.ethyca.janussdk.android.models.ConsentMethod
import com.ethyca.janussdk.android.models.IPLocationResponse
import com.ethyca.janussdk.android.models.PrivacyExperienceItem
import com.ethyca.janussdk.android.events.JanusEvent

/**
 * Main entry point for the Janus SDK
 *
 * This class provides a static API that delegates to the underlying JanusImplementation
 * through the JanusProvider. This ensures a simple public API while maintaining testability.
 */
object Janus {
    
    // MARK: - Private Properties
    
    /**
     * The current logger instance. Defaults to DefaultJanusLogger.
     * Thread-safe through @Volatile and synchronized access.
     */
    @Volatile
    private var _logger: JanusLogger = DefaultJanusLogger()
    
    // MARK: - Public Properties
    
    /**
     * Indicates whether a valid privacy experience is available for the current region and property ID
     */
    val hasExperience: Boolean
        get() = JanusProvider.shared.hasExperience
    
    /**
     * Determines if the privacy experience should be shown to the user
     * This is based on whether a valid experience exists and if consent is missing or outdated
     */
    val shouldShowExperience: Boolean
        get() = JanusProvider.shared.shouldShowExperience
    
    /**
     * The current privacy experience item, if available
     */
    val currentExperience: PrivacyExperienceItem?
        get() = JanusProvider.shared.currentExperience
    
    /**
     * Whether the current privacy experience is a TCF experience
     */
    val isTCFExperience: Boolean
        get() = currentExperience?.isTCFExperience ?: false
    
    /**
     * Current consent values (format depends on consentFlagType configuration)
     */
    val consent: Map<String, Any>
        get() = JanusProvider.shared.consent
    
    /**
     * Current consent values as boolean (for internal use only)
     */
    internal val internalConsent: Map<String, Boolean>
        get() = JanusProvider.shared.internalConsent
    
    /**
     * Metadata about the consent including timestamps
     */
    val consentMetadata: ConsentMetadata
        get() = JanusProvider.shared.consentMetadata
    
    /**
     * Get the Fides string representation of consent
     */
    val fidesString: String
        get() = JanusProvider.shared.fidesString
    
    /**
     * Get the region currently being used by the SDK
     * This is set during initialization from the provided config or IP geolocation
     */
    val region: String
        get() = JanusProvider.shared.region
    
    // MARK: - Public Methods
    
    /**
     * Initialize the SDK with configuration
     *
     * @param activity The activity to present UI from
     * @param config Configuration data
     * @param completion Callback with success flag and optional error
     */
    fun initialize(activity: Activity, config: JanusConfiguration, completion: (Boolean, JanusError?) -> Unit) {
        // First set the application context on the provider to avoid circular dependency
        JanusProvider.setApplicationContext(activity.applicationContext)
        
        // Now we can safely access the shared instance
        JanusProvider.shared.initialize(activity, config, completion)
    }
    
    /**
     * Get the user's region by IP address lookup
     *
     * @param completion Callback with success flag, IPLocationResponse data, and optional error
     */
    fun getLocationByIPAddress(completion: (Boolean, IPLocationResponse?, JanusError?) -> Unit) {
        JanusProvider.shared.getLocationByIPAddress(completion)
    }
    
    /**
     * Shows the privacy experience UI
     *
     * @param activity The activity to present from
     */
    fun showExperience(activity: Activity) {
        JanusProvider.shared.showExperience(activity)
    }
    
    /**
     * Add a consent event listener
     *
     * @param listener Callback function that receives events
     * @return A unique identifier for the listener
     */
    fun addConsentEventListener(listener: (JanusEvent) -> Unit): String {
        return JanusProvider.shared.addConsentEventListener(listener)
    }
    
    /**
     * Remove a consent event listener
     *
     * @param listenerId The identifier of the listener to remove
     */
    fun removeConsentEventListener(listenerId: String) {
        JanusProvider.shared.removeConsentEventListener(listenerId)
    }
    
    /**
     * Create a WebView that's configured for consent management
     *
     * @param context The context to create the WebView in
     * @param autoSyncOnStart Whether to enable initial synchronization when the webview loads (default is true)
     * @return A WebView configured for consent management
     */
    fun createConsentWebView(context: Context, autoSyncOnStart: Boolean = true): WebView {
        return JanusProvider.shared.createConsentWebView(context, autoSyncOnStart)
    }
    
    /**
     * Release a WebView created with createConsentWebView
     *
     * @param webView The WebView to release
     */
    fun releaseConsentWebView(webView: WebView) {
        JanusProvider.shared.releaseConsentWebView(webView)
    }
    
    /**
     * Clear all consent data
     *
     * @param clearMetadata Whether to also clear metadata
     */
    fun clearConsent(applicationContext: Context? = null, clearMetadata: Boolean = false) {
        JanusProvider.shared.clearConsent(applicationContext, clearMetadata)
    }

    /**
     * Programmatically set consent values from outside the native privacy experience.
     *
     * Use cases include bidirectional sync with custom WebViews running FidesJS, and
     * pre-populating consent from legacy storage during app migration.
     *
     * @param values Map of notice keys to boolean consent values
     * @param fidesString Optional fides string (TCF use cases)
     * @param consentMethod How consent was collected. Defaults to null (stored as UNKNOWN)
     * @param saveToFides If true, persists to Fides backend via privacy-preferences API.
     *   Silently no-ops if no privacy experience is currently loaded.
     */
    fun setConsent(
        values: Map<String, Boolean>,
        fidesString: String? = null,
        consentMethod: ConsentMethod? = null,
        saveToFides: Boolean = false
    ) {
        JanusProvider.shared.setConsent(values, fidesString, consentMethod, saveToFides)
    }
    
    // MARK: - Internal Methods
    
    /**
     * Notify event listeners of a new event
     * This is internal and used for testing
     *
     * @param event The event to dispatch
     */
    internal fun notifyEventListeners(event: JanusEvent) {
        JanusProvider.shared.notifyEventListeners(event)
    }
    
    // MARK: - Logging
    
    /**
     * Set the logger implementation for the SDK
     *
     * @param logger The logger implementation to use. Pass null to reset to default.
     */
    @Synchronized
    fun setLogger(logger: JanusLogger?) {
        _logger = logger ?: DefaultJanusLogger()
    }
    
    /**
     * Log a message with optional level, metadata, and error
     * Internal use only - not part of the public SDK API
     *
     * @param message The message to log
     * @param level The log level (defaults to INFO)
     * @param metadata Optional metadata map to include with the log
     * @param error Optional exception for error-specific logging
     */
    internal fun log(message: String, level: LogLevel = LogLevel.INFO, metadata: Map<String, String>? = null, error: Throwable? = null) {
        _logger.log(message, level, metadata, error)
    }
} 
