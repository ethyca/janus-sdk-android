package com.ethyca.janussdk.android.ui

import com.ethyca.janussdk.android.Janus
import com.ethyca.janussdk.android.LogLevel
import com.ethyca.janussdk.android.api.NoticesServedAPI
import com.ethyca.janussdk.android.api.PrivacyPreferencesAPI
import com.ethyca.janussdk.android.consent.ConsentManagerInterface
import com.ethyca.janussdk.android.events.ExperienceClosedEvent
import com.ethyca.janussdk.android.events.ExperienceSelectionUpdatedEvent
import com.ethyca.janussdk.android.events.ExperienceSelectionUpdatingEvent
import com.ethyca.janussdk.android.models.ConsentMechanism
import com.ethyca.janussdk.android.models.ConsentMethod
import com.ethyca.janussdk.android.models.ExperienceConfigTranslation
import com.ethyca.janussdk.android.models.PrivacyExperienceItem
import com.ethyca.janussdk.android.models.PrivacyNotice
import com.ethyca.janussdk.android.models.ServingComponent
import com.ethyca.janussdk.android.models.TranslatedPrivacyNotice
import com.ethyca.janussdk.android.utils.ConsentTransformationUtils
import com.ethyca.janussdk.android.utils.TranslationMatcher

/**
 * Consent actions for one showing of a privacy experience, shared by the banner and the modal.
 */
internal class ExperienceConsentSession(
    val experience: PrivacyExperienceItem,
    private val consentManager: ConsentManagerInterface,
    private val privacyPreferencesAPI: PrivacyPreferencesAPI = PrivacyPreferencesAPI(),
    private val noticesServedAPI: NoticesServedAPI = NoticesServedAPI()
) {
    val translatedExperienceConfig: ExperienceConfigTranslation? =
        experience.experienceConfig?.translations?.let { TranslationMatcher.find(it) }

    val allNotices: List<TranslatedPrivacyNotice> = flattenNotices(experience.privacyNotices ?: emptyList())

    /** Whether a consent or close event already fired, so dismissal must not fire another */
    var eventFiredOnDismiss = false
        private set

    private var servedNoticeHistoryId: String? = null

    /** Banner heading; falls back to the modal title like FidesJS does */
    val bannerTitle: String?
        get() = translatedExperienceConfig?.bannerTitle?.ifEmpty { null } ?: translatedExperienceConfig?.title

    /** Banner body; falls back to the modal description like FidesJS does */
    val bannerDescription: String?
        get() = translatedExperienceConfig?.bannerDescription?.ifEmpty { null } ?: translatedExperienceConfig?.description

    /** Whether the banner offers a single Acknowledge button; `gpc_conditional` maps to opt in/opt out because apps have no GPC signal */
    val bannerShowsAcknowledgeOnly: Boolean
        get() = experience.privacyNotices.orEmpty().all { it.consentMechanism == NOTICE_ONLY } ||
            experience.experienceConfig?.layer1ButtonOptions == LAYER1_ACKNOWLEDGE

    val isDismissable: Boolean
        get() = experience.isDismissable

    fun recordNoticesServed(servingComponent: ServingComponent) {
        noticesServedAPI.recordNoticesServed(
            experience,
            allNotices,
            translatedExperienceConfig?.privacyExperienceConfigHistoryId ?: "",
            servingComponent
        ) { response ->
            servedNoticeHistoryId = response?.servedNoticeHistoryId
        }
    }

    fun acceptAll() {
        applyConsentChangesAndNotify(allNotices.associate { it.noticeKey to true }, "accept_all", ConsentMethod.ACCEPT)
    }

    fun rejectAll() {
        val rejectedValues = allNotices.associate { it.noticeKey to (it.consentMechanism == NOTICE_ONLY) }
        applyConsentChangesAndNotify(rejectedValues, "reject_all", ConsentMethod.REJECT)
    }

    fun savePreferences(consentValues: Map<String, Boolean>) {
        applyConsentChangesAndNotify(consentValues, "save_button", ConsentMethod.SAVE)
    }

    /** Acknowledge the experience, saving the current toggles like FidesJS does; notice_only is always on */
    fun acknowledgeAll(consentValues: Map<String, Boolean>) {
        applyConsentChangesAndNotify(
            ConsentTransformationUtils.acknowledgedConsent(allNotices, consentValues),
            "acknowledged",
            ConsentMethod.ACKNOWLEDGE
        )
    }

    /** Toggle values the modal would open with: saved consent, else the notice default */
    fun initialToggleValues(): Map<String, Boolean> {
        val savedConsent = consentManager.getConsent()
        return allNotices.associate { it.noticeKey to (savedConsent[it.noticeKey] ?: (it.defaultPreference == "opt_in")) }
    }

    /** Close without an explicit choice; applies notice defaults when the user has no saved consent */
    fun dismiss(closeMethod: String) {
        if (eventFiredOnDismiss) return

        val hasExistingConsent = allNotices.any { Janus.internalConsent.containsKey(it.noticeKey) }
        if (hasExistingConsent) {
            Janus.notifyEventListeners(ExperienceClosedEvent(closeMethod))
            eventFiredOnDismiss = true
        } else {
            // Imply consent to true if defaultPreference is "opt_in" or "acknowledge"
            val defaultConsent = allNotices.associate {
                it.noticeKey to (it.defaultPreference == "opt_in" || it.defaultPreference == "acknowledge")
            }
            applyConsentChangesAndNotify(defaultConsent, closeMethod, ConsentMethod.DISMISS)
        }
    }

    /** Hand off to another experience view without recording a close */
    fun markHandedOff() {
        eventFiredOnDismiss = true
    }

    private fun applyConsentChangesAndNotify(changes: Map<String, Boolean>, closeMethod: String, consentMethod: ConsentMethod) {
        Janus.log("$closeMethod: $changes", level = LogLevel.DEBUG)
        Janus.notifyEventListeners(ExperienceSelectionUpdatingEvent(changes))

        // TODO: Placeholder for fides_string once this view supports TCF
        val fidesString = ""

        consentManager.setConsent(
            values = changes,
            versionHash = experience.meta?.versionHash ?: "",
            fidesString = fidesString,
            consentMethod = consentMethod
        )

        privacyPreferencesAPI.savePrivacyPreferences(
            consentChanges = changes,
            consentMethod = consentMethod,
            fidesString = fidesString,
            notices = allNotices,
            privacyExperienceConfigHistoryId = translatedExperienceConfig?.privacyExperienceConfigHistoryId,
            servedNoticeHistoryId = servedNoticeHistoryId
        )

        Janus.notifyEventListeners(ExperienceSelectionUpdatedEvent())
        Janus.notifyEventListeners(ExperienceClosedEvent(closeMethod))
        eventFiredOnDismiss = true
    }

    private companion object {
        val NOTICE_ONLY = ConsentMechanism.NOTICE_ONLY.value
        const val LAYER1_ACKNOWLEDGE = "acknowledge"

        /** Flattens child notices, keeping only those with a notice key */
        fun flattenNotices(notices: List<PrivacyNotice>): List<TranslatedPrivacyNotice> = notices.flatMap { notice ->
            val self = if (notice.noticeKey.isNullOrEmpty()) {
                emptyList()
            } else {
                listOf(TranslatedPrivacyNotice(notice, notice.translations?.let { TranslationMatcher.find(it) }))
            }
            self + flattenNotices(notice.children.orEmpty())
        }
    }
}
