package com.ethyca.janussdk.android.api

import android.content.Context
import android.content.SharedPreferences
import com.ethyca.janussdk.android.core.JanusProvider
import com.ethyca.janussdk.android.models.PrivacyPreferencesRequest
import com.ethyca.janussdk.android.models.UserPreference
import com.google.gson.Gson
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

internal class PrivacyPreferencesDelivery(
    private val storage: SharedPreferences,
    private val retryDelayMillis: Long = 2_000,
    private val send: (PrivacyPreferencesRequest, String) -> Result = { request, host ->
        PrivacyPreferencesAPI().sendPrivacyPreferencesRequest(request, host)
    }
) {
    enum class Result { SUCCESS, RETRYABLE_FAILURE, PERMANENT_FAILURE }

    data class PendingSave(
        val id: String,
        val request: PrivacyPreferencesRequest,
        val apiHost: String,
        val createdAt: Long,
        val attempts: Int
    )

    companion object {
        const val STORAGE_KEY = "janus.pendingPrivacyPreferences"
        private const val MAX_ATTEMPTS = 10
        private const val MAX_AGE_MILLIS = 7L * 24 * 60 * 60 * 1000

        val shared: PrivacyPreferencesDelivery by lazy {
            PrivacyPreferencesDelivery(
                JanusProvider.applicationContext.getSharedPreferences("janus_privacy_preferences", Context.MODE_PRIVATE)
            )
        }
    }

    private val gson = Gson()
    private val executor = Executors.newSingleThreadScheduledExecutor { runnable ->
        Thread(runnable, "janus-privacy-preferences").apply { isDaemon = true }
    }
    private val lock = Any()
    private val completions = mutableMapOf<String, MutableList<(Boolean) -> Unit>>()
    private var inFlightId: String? = null
    private var scheduledRetry: ScheduledFuture<*>? = null

    fun enqueue(request: PrivacyPreferencesRequest, apiHost: String, completion: ((Boolean) -> Unit)? = null) {
        val pending: PendingSave
        val supersededCallbacks: List<(Boolean) -> Unit>
        synchronized(lock) {
            val previous = pendingSave()
            val merged = previous?.takeIf { canMerge(it, request, apiHost) }
            val combinedRequest = merged?.let { merge(it.request, request) } ?: request
            pending = PendingSave(
                id = UUID.randomUUID().toString(),
                request = combinedRequest,
                apiHost = apiHost,
                createdAt = merged?.createdAt ?: System.currentTimeMillis(),
                attempts = 0
            )
            supersededCallbacks = if (previous != null && inFlightId != previous.id) {
                val previousCallbacks = completions.remove(previous.id).orEmpty()
                if (merged != null) {
                    completions.getOrPut(pending.id) { mutableListOf() }.addAll(previousCallbacks)
                    emptyList()
                } else {
                    previousCallbacks
                }
            } else emptyList()
            if (completion != null) completions.getOrPut(pending.id) { mutableListOf() }.add(completion)
            storage.edit().putString(STORAGE_KEY, gson.toJson(pending)).apply()
            scheduledRetry?.cancel(false)
            scheduledRetry = null
        }
        supersededCallbacks.forEach { callback -> executor.execute { callback(false) } }
        executor.execute { attempt(pending.id) }
    }

    fun retryPending(apiHost: String? = null, completion: ((Boolean) -> Unit)? = null) {
        val expiredCallbacks = synchronized(lock) {
            val current = pendingSave()
            if (current != null && (isExpired(current) || (apiHost != null && current.apiHost != apiHost))) {
                storage.edit().remove(STORAGE_KEY).apply()
                completions.remove(current.id).orEmpty()
            } else {
                emptyList()
            }
        }
        expiredCallbacks.forEach { callback -> executor.execute { callback(false) } }
        val pending = synchronized(lock) { pendingSave() }
        if (pending == null) {
            completion?.invoke(true)
            return
        }
        synchronized(lock) {
            if (completion != null) completions.getOrPut(pending.id) { mutableListOf() }.add(completion)
            scheduledRetry?.cancel(false)
            scheduledRetry = null
        }
        executor.execute { attempt(pending.id) }
    }

    fun cancelRetry() {
        synchronized(lock) {
            scheduledRetry?.cancel(false)
            scheduledRetry = null
        }
    }

    fun discardPending(completion: (() -> Unit)? = null) {
        val callbacks = synchronized(lock) {
            scheduledRetry?.cancel(false)
            scheduledRetry = null
            val pending = pendingSave()
            storage.edit().remove(STORAGE_KEY).apply()
            pending?.let { completions.remove(it.id) }.orEmpty()
        }
        executor.execute {
            callbacks.forEach { callback -> callback(false) }
            completion?.invoke()
        }
    }

    private fun pendingSave(): PendingSave? {
        val raw = storage.getString(STORAGE_KEY, null) ?: return null
        val pending = runCatching { gson.fromJson(raw, PendingSave::class.java) }
            .getOrNull()
            ?.takeIf { candidate ->
                runCatching {
                    candidate.id.isNotBlank() && candidate.apiHost.isNotBlank() &&
                        candidate.request.propertyId.isNotBlank() && candidate.request.browserIdentity.fidesUserDeviceId.isNotBlank()
                }.getOrDefault(false)
            }
        if (pending == null) storage.edit().remove(STORAGE_KEY).apply()
        return pending
    }

    private fun attempt(expectedId: String) {
        val pending = synchronized(lock) {
            pendingSave()?.takeIf { it.id == expectedId }?.also { inFlightId = it.id }
        }
        if (pending == null) {
            val callbacks = synchronized(lock) { completions.remove(expectedId).orEmpty() }
            callbacks.forEach { callback -> callback(false) }
            return
        }
        val result = try {
            send(pending.request, pending.apiHost)
        } catch (_: Exception) {
            Result.RETRYABLE_FAILURE
        }
        val callbacks: List<(Boolean) -> Unit>
        synchronized(lock) {
            inFlightId = null
            val latest = pendingSave()
            if (latest?.id != pending.id) {
                callbacks = completions.remove(pending.id).orEmpty()
                if (latest != null) executor.execute { attempt(latest.id) }
            } else {
                when {
                    result == Result.SUCCESS -> storage.edit().remove(STORAGE_KEY).apply()
                    result == Result.PERMANENT_FAILURE || isExpired(pending) || pending.attempts + 1 >= MAX_ATTEMPTS ->
                        storage.edit().remove(STORAGE_KEY).apply()
                    else -> {
                        val updated = pending.copy(attempts = pending.attempts + 1)
                        storage.edit().putString(STORAGE_KEY, gson.toJson(updated)).apply()
                        val delay = (retryDelayMillis * (1L shl (updated.attempts - 1))).coerceAtMost(300_000)
                        scheduledRetry?.cancel(false)
                        scheduledRetry = executor.schedule({ attempt(updated.id) }, delay, TimeUnit.MILLISECONDS)
                    }
                }
                callbacks = completions.remove(pending.id).orEmpty()
            }
        }
        callbacks.forEach { callback -> callback(result == Result.SUCCESS) }
    }

    private fun isExpired(pending: PendingSave): Boolean =
        System.currentTimeMillis() - pending.createdAt >= MAX_AGE_MILLIS

    private fun canMerge(previous: PendingSave, request: PrivacyPreferencesRequest, apiHost: String): Boolean =
        previous.apiHost == apiHost &&
            previous.request.propertyId == request.propertyId &&
            previous.request.browserIdentity == request.browserIdentity

    private fun merge(previous: PrivacyPreferencesRequest, latest: PrivacyPreferencesRequest): PrivacyPreferencesRequest {
        val preferences = (previous.preferences + latest.preferences)
            .associateBy { it.privacyNoticeHistoryId }
            .values
            .toList()
        return latest.copy(
            preferences = preferences,
            fidesString = latest.fidesString ?: previous.fidesString,
            privacyExperienceConfigHistoryId = latest.privacyExperienceConfigHistoryId ?: previous.privacyExperienceConfigHistoryId,
            servedNoticeHistoryId = latest.servedNoticeHistoryId ?: previous.servedNoticeHistoryId
        )
    }
}
