package com.ethyca.janussdk.android.ui.view

import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback

/** Runs [onDismiss] on back press only while [isDismissable] holds; otherwise the press is consumed */
internal fun ComponentActivity.dismissOnBackIfAllowed(isDismissable: () -> Boolean, onDismiss: () -> Unit) {
    onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
        override fun handleOnBackPressed() {
            if (isDismissable()) onDismiss()
        }
    })
}
