package com.ethyca.janussdk.android.ui.view

import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.net.toUri
import androidx.recyclerview.widget.LinearLayoutManager
import com.ethyca.janussdk.android.Janus
import com.ethyca.janussdk.android.LogLevel
import com.ethyca.janussdk.android.R
import com.ethyca.janussdk.android.consent.ConsentManager
import com.ethyca.janussdk.android.core.JanusProvider
import com.ethyca.janussdk.android.databinding.ActivityPrivacyExperienceBinding
import com.ethyca.janussdk.android.events.ExperienceClosedEvent
import com.ethyca.janussdk.android.models.ConsentMechanism
import com.ethyca.janussdk.android.models.ExperienceConfigTranslation
import com.ethyca.janussdk.android.models.PrivacyExperienceItem
import com.ethyca.janussdk.android.models.ServingComponent
import com.ethyca.janussdk.android.ui.ExperienceConsentSession
import com.ethyca.janussdk.android.ui.adapter.PrivacyNoticeAdapter
import com.ethyca.janussdk.android.utils.UrlHelper

/**
 * Activity that displays the privacy experience UI to the user.
 * This is a modal full-screen UI that allows users to view and update their privacy settings.
 */
class PrivacyExperienceActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPrivacyExperienceBinding
    private lateinit var noticeAdapter: PrivacyNoticeAdapter

    private var session: ExperienceConsentSession? = null
    private var closedWithoutSession = false

    // Back is only blocked once usable content is on screen, never on the error or loading state
    private var contentShown = false

    companion object {
        private const val TAG = "PrivacyExperience"
        private const val ATTRIBUTION_URL = "https://www.ethyca.com/janus?utm_source=fides_consent_sdk&utm_medium=referral&utm_campaign=cmp_backlinks&utm_term=janus"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Apply the privacy experience theme
        setTheme(R.style.Theme_JanusSDK_Dialog)

        // Initialize binding
        binding = ActivityPrivacyExperienceBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Set up the back press handling
        setupBackPressHandling()

        // Set up the UI
        setupUI()

        // Load the privacy experience
        loadPrivacyExperience()
    }

    private fun setupBackPressHandling() {
        dismissOnBackIfAllowed({ !contentShown || (session?.isDismissable ?: true) }) {
            dismiss("back_button")
            finish()
        }
    }

    private fun setupUI() {
        // Set up RecyclerView
        binding.privacyNoticesRecyclerView.layoutManager = LinearLayoutManager(this)
        noticeAdapter = PrivacyNoticeAdapter()
        binding.privacyNoticesRecyclerView.adapter = noticeAdapter
        
        // Set up powered by footer click handler
        setupPoweredByFooter()
    }
    
    /**
     * Set up click handler for the powered by footer to open Ethyca website
     */
    private fun setupPoweredByFooter() {
        val poweredByFooter = findViewById<LinearLayout>(R.id.powered_by_footer)
        poweredByFooter?.setOnClickListener {
            UrlHelper.openInBrowser(this, ATTRIBUTION_URL.toUri())
        }
    }

    /**
     * Load the privacy experience from Janus
     */
    private fun loadPrivacyExperience() {
        // Show loading state
        showLoadingState()

        try {
            // Get the current experience from Janus (already fetched during initialization)
            val experience = JanusProvider.shared.currentExperience

            if (experience != null) {
                updateUI(ExperienceConsentSession(experience, ConsentManager()).also { session = it })
            } else {
                showErrorState("No privacy experience available")
            }
        } catch (e: Exception) {
            showErrorState(e.message ?: "Failed to load privacy experience")
        }
    }

    /**
     * Update the UI with the privacy experience data
     */
    private fun updateUI(session: ExperienceConsentSession) {
        val experience = session.experience
        val translation = session.translatedExperienceConfig

        binding.privacyExperienceTitle.text = translation?.title ?: "Privacy Settings"
        binding.privacyExperienceDescription.setHtmlContent(
            htmlContent = translation?.description ?: "Please review your privacy choices.",
            vendorCount = experience.vendorCount
        )

        // Log the Privacy Experience UI setup with structured metadata
        Janus.log("Showing Privacy Experience UI", metadata = mapOf(
            "notices" to session.allNotices.map { it.title }.filter { it.isNotEmpty() }.joinToString(", "),
            "consent" to Janus.internalConsent.toString()
        ), level = LogLevel.DEBUG)

        // Initialize adapter with notices (includes children flattened)
        noticeAdapter.setNotices(session.allNotices)

        setupActionButtons(experience, translation)
        showContentState()

        // Record that notices were served now that the content is visible to the user
        session.recordNoticesServed(ServingComponent.MODAL)
    }

    /**
     * Show the primary save button and hide the secondary one
     */
    private fun showPrimarySaveButton() {
        binding.savePreferencesButtonSecondary.visibility = View.GONE
        binding.savePreferencesButtonPrimary.visibility = View.VISIBLE
    }

    /**
     * Show the secondary save button and hide the primary one
     */
    private fun showSecondarySaveButton() {
        binding.savePreferencesButtonPrimary.visibility = View.GONE
        binding.savePreferencesButtonSecondary.visibility = View.VISIBLE
    }

    /**
     * Configure the action buttons based on experience data
     */
    private fun setupActionButtons(experience: PrivacyExperienceItem, translation: ExperienceConfigTranslation?) {
        val noticesCount = experience.privacyNotices?.size ?: 0
        val allNoticesAreNoticeOnly = experience.privacyNotices?.all { it.consentMechanism == ConsentMechanism.NOTICE_ONLY.value } ?: false

        // Case 1: No privacy notices or all are notice_only - show only acknowledge button
        if (noticesCount == 0 || allNoticesAreNoticeOnly) {
            // Hide other buttons
            binding.acceptAllButton.visibility = View.GONE
            binding.rejectAllButton.visibility = View.GONE

            // Show primary save button as acknowledge (filled style when it's the only button)
            showPrimarySaveButton()
            binding.savePreferencesButtonPrimary.text = translation?.acknowledgeButtonLabel ?: "OK"
            binding.savePreferencesButtonPrimary.setOnClickListener {
                session?.acknowledgeAll(noticeAdapter.getConsentValues())
                finish()
            }
        }
        // Case 2: Exactly one privacy notice (not notice_only) - show only save button
        else if (noticesCount == 1) {
            // Hide other buttons
            binding.acceptAllButton.visibility = View.GONE
            binding.rejectAllButton.visibility = View.GONE

            // Show primary save button (filled style when it's the only button)
            showPrimarySaveButton()
            binding.savePreferencesButtonPrimary.text = translation?.saveButtonLabel ?: "Save"
            binding.savePreferencesButtonPrimary.setOnClickListener {
                session?.savePreferences(noticeAdapter.getConsentValues())
                finish()
            }
        }
        // Case 3: Multiple privacy notices (at least one not notice_only) - show all three buttons
        else {
            // Configure Accept All button
            binding.acceptAllButton.visibility = View.VISIBLE
            binding.acceptAllButton.text = translation?.acceptButtonLabel ?: "Opt in to all"
            binding.acceptAllButton.setOnClickListener {
                session?.acceptAll()
                finish()
            }

            // Configure Reject All button
            binding.rejectAllButton.visibility = View.VISIBLE
            binding.rejectAllButton.text = translation?.rejectButtonLabel ?: "Opt out of all"
            binding.rejectAllButton.setOnClickListener {
                session?.rejectAll()
                finish()
            }

            // Configure Save button - use secondary style (outlined) when other buttons are visible
            showSecondarySaveButton()
            binding.savePreferencesButtonSecondary.text = translation?.saveButtonLabel ?: "Save"
            binding.savePreferencesButtonSecondary.setOnClickListener {
                session?.savePreferences(noticeAdapter.getConsentValues())
                finish()
            }
        }
    }

    /**
     * Show the loading state
     */
    private fun showLoadingState() {
        binding.progressBar.visibility = View.VISIBLE
        binding.errorView.visibility = View.GONE
    }

    /**
     * Show the error state
     */
    private fun showErrorState(message: String) {
        contentShown = false
        binding.progressBar.visibility = View.GONE
        binding.errorView.visibility = View.VISIBLE
        binding.errorTextView.text = message
    }

    /**
     * Show the content state
     */
    private fun showContentState() {
        contentShown = true
        binding.progressBar.visibility = View.GONE
        binding.errorView.visibility = View.GONE
    }

    /**
     * Handle when the user swipes to dismiss the sheet
     */
    override fun finish() {
        // Finishing without a recorded choice counts as a swipe dismiss
        dismiss("swipe_dismiss")
        super.finish()
    }

    /** Without a loaded experience there is nothing to save, but listeners still need the close event */
    private fun dismiss(closeMethod: String) {
        val session = session
        if (session != null) {
            session.dismiss(closeMethod)
            return
        }
        if (closedWithoutSession) return
        closedWithoutSession = true
        Janus.notifyEventListeners(ExperienceClosedEvent(closeMethod))
    }
}
