package com.ethyca.janussdk.android.api

import androidx.annotation.VisibleForTesting
import com.ethyca.janussdk.android.Janus
import com.ethyca.janussdk.android.LogLevel
import com.ethyca.janussdk.android.consent.ConsentManager
import com.ethyca.janussdk.android.core.JanusProvider
import com.ethyca.janussdk.android.models.BrowserIdentity
import com.ethyca.janussdk.android.models.ConsentMethod
import com.ethyca.janussdk.android.models.PrivacyExperienceItem
import com.ethyca.janussdk.android.models.PrivacyPreferencesRequest
import com.ethyca.janussdk.android.models.TranslatedPrivacyNotice
import com.ethyca.janussdk.android.models.UserPreference
import com.ethyca.janussdk.android.utils.ConsentTransformationUtils
import com.google.gson.Gson
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets

/**
 * API client for saving privacy preferences asynchronously
 */
open class PrivacyPreferencesAPI {

    /**
     * Creates connection to URL
     * @param url The URL to connect to
     * @return HttpURLConnection
     */
    protected open fun createConnection(url: URL): HttpURLConnection {
        return url.openConnection() as HttpURLConnection
    }

    /**
     * Save privacy preferences from user consent changes asynchronously
     *
     * @param consentChanges Map of consent key to boolean value representing the user's choices
     * @param consentMethod The method used to collect consent
     * @param fidesString Optional fides string from TCF (if available)
     * @param notices List of privacy notices with pre-resolved translations
     * @param privacyExperienceConfigHistoryId Optional privacy experience config history ID from the current experience
     * @param completion Optional completion handler - receives true on success, false on failure
     */
    fun savePrivacyPreferences(
        consentChanges: Map<String, Boolean>,
        consentMethod: ConsentMethod,
        fidesString: String? = null,
        notices: List<TranslatedPrivacyNotice>,
        privacyExperienceConfigHistoryId: String? = null,
        servedNoticeHistoryId: String? = null,
        completion: ((Boolean) -> Unit)? = null
    ) {
        // Get configuration from JanusProvider
        val configuration = JanusProvider.configuration
        
        // Check if privacy preferences saving is enabled
        if (!configuration.saveUserPreferencesToFides) {
            Janus.log("Privacy preferences saving is disabled", level = LogLevel.DEBUG)
            completion?.invoke(true) // Consider this a success since it's intentionally disabled
            return
        }

        val experience = Janus.currentExperience
        if (experience == null) {
            Janus.log("No current privacy experience available for preferences", level = LogLevel.WARNING)
            completion?.invoke(false)
            return
        }

        val preferences = buildUserPreferences(consentChanges, notices)
        savePrivacyPreferencesRaw(consentChanges, consentMethod, fidesString, preferences, privacyExperienceConfigHistoryId, servedNoticeHistoryId, completion)
    }

    /**
     * Save privacy preferences with a pre-built UserPreference list (no TranslatedPrivacyNotice required).
     * Used by the public setConsent() API which derives preferences directly from the raw experience model.
     */
    fun savePrivacyPreferencesRaw(
        consentChanges: Map<String, Boolean>,
        consentMethod: ConsentMethod,
        fidesString: String? = null,
        preferences: List<UserPreference>,
        privacyExperienceConfigHistoryId: String? = null,
        servedNoticeHistoryId: String? = null,
        completion: ((Boolean) -> Unit)? = null
    ) {
        val configuration = JanusProvider.configuration

        if (!configuration.saveUserPreferencesToFides) {
            Janus.log("Privacy preferences saving is disabled", level = LogLevel.DEBUG)
            completion?.invoke(true)
            return
        }

        if (Janus.currentExperience == null) {
            Janus.log("No current privacy experience available for preferences", level = LogLevel.DEBUG)
            completion?.invoke(false)
            return
        }

        if (preferences.isEmpty()) {
            Janus.log("No valid preferences to save", level = LogLevel.DEBUG)
            completion?.invoke(true) // Consider this a success since there's nothing to save
            return
        }

        val consentManager = ConsentManager()
        val request = PrivacyPreferencesRequest(
            propertyId = configuration.propertyId,
            source = "Janus SDK",
            browserIdentity = BrowserIdentity(
                fidesUserDeviceId = consentManager.getFidesUserDeviceId(),
                externalId = JanusProvider.externalId
            ),
            preferences = preferences,
            userGeography = Janus.region.replace("-", "_").lowercase(), // backend expects lowercase with underscores
            fidesString = if (fidesString.isNullOrEmpty()) null else fidesString,
            privacyExperienceConfigHistoryId = privacyExperienceConfigHistoryId,
            servedNoticeHistoryId = servedNoticeHistoryId,
            method = consentMethod.value.takeUnless { consentMethod == ConsentMethod.UNKNOWN },
            requestOrigin = "api"
        )

        PrivacyPreferencesDelivery.shared.enqueue(request, configuration.apiHost, completion)
    }

    internal fun sendPrivacyPreferencesRequest(request: PrivacyPreferencesRequest, apiHost: String): PrivacyPreferencesDelivery.Result {
        return try {
            val url = URL("$apiHost/api/v1/privacy-preferences")
            Janus.log("Saving privacy preferences", level = LogLevel.DEBUG, metadata = mapOf(
                "url" to url.toString(),
                "propertyId" to request.propertyId,
                "userGeography" to request.userGeography,
                "preferencesCount" to request.preferences.size.toString(),
                "fidesUserDeviceId" to request.browserIdentity.fidesUserDeviceId,
                "servedNoticeHistoryId" to (request.servedNoticeHistoryId ?: "null")
            ))
            val connection = createConnection(url)
            connection.requestMethod = "PATCH"
            connection.connectTimeout = 10_000
            connection.readTimeout = 10_000
            connection.setRequestProperty("Content-Type", "application/json")
            connection.setRequestProperty("Accept", "application/json")
            connection.setRequestProperty("Fides-Client", "Janus-SDK")
            connection.doOutput = true

            try {
                OutputStreamWriter(connection.outputStream, StandardCharsets.UTF_8).use { writer ->
                    writer.write(Gson().toJson(request))
                }
                val responseCode = connection.responseCode
                if (responseCode in 200..299) {
                    Janus.log("Privacy preferences saved successfully", level = LogLevel.DEBUG)
                    PrivacyPreferencesDelivery.Result.SUCCESS
                } else {
                    val errorMessage = connection.errorStream?.bufferedReader()?.use { it.readText() } ?: "No error message"
                    Janus.log("Failed to save privacy preferences", level = LogLevel.WARNING, metadata = mapOf(
                        "statusCode" to responseCode.toString(),
                        "errorMessage" to errorMessage
                    ))
                    if (responseCode in 400..499) PrivacyPreferencesDelivery.Result.PERMANENT_FAILURE
                    else PrivacyPreferencesDelivery.Result.RETRYABLE_FAILURE
                }
            } finally {
                connection.disconnect()
            }
        } catch (e: Exception) {
            Janus.log("Network error saving privacy preferences", level = LogLevel.WARNING, error = e)
            PrivacyPreferencesDelivery.Result.RETRYABLE_FAILURE
        }
    }

    /**
     * Build the user preferences list from consent changes and notices
     *
     * @param consentChanges Map of consent key to boolean value
     * @param notices List of privacy notices with privacy_notice_history_id from resolved translations
     * @return List of UserPreference objects
     */
    @VisibleForTesting(otherwise = VisibleForTesting.PRIVATE)
    internal fun buildUserPreferences(
        consentChanges: Map<String, Boolean>,
        notices: List<TranslatedPrivacyNotice>
    ): List<UserPreference> {
        val preferences = mutableListOf<UserPreference>()

        // For each consent change, find the corresponding privacy notice and extract the privacy_notice_history_id
        consentChanges.forEach { (noticeKey, consentValue) ->
            val notice = notices.find { it.noticeKey == noticeKey }
            
            if (notice != null) {
                val privacyNoticeHistoryId = notice.privacyNoticeHistoryId
                
                if (privacyNoticeHistoryId != null) {
                    val preferenceValue = ConsentTransformationUtils.preferenceValue(consentValue, notice.consentMechanism)

                    preferences.add(
                        UserPreference(
                            privacyNoticeHistoryId = privacyNoticeHistoryId,
                            preference = preferenceValue
                        )
                    )

                    Janus.log("Added preference for notice", level = LogLevel.DEBUG, metadata = mapOf(
                        "noticeKey" to noticeKey,
                        "privacyNoticeHistoryId" to privacyNoticeHistoryId,
                        "preference" to preferenceValue
                    ))
                } else {
                    Janus.log("No privacy_notice_history_id found for notice", level = LogLevel.WARNING, metadata = mapOf(
                        "noticeKey" to noticeKey
                    ))
                }
            } else {
                Janus.log("No privacy notice found for consent key", level = LogLevel.WARNING, metadata = mapOf(
                    "noticeKey" to noticeKey
                ))
            }
        }

        return preferences
    }
} 