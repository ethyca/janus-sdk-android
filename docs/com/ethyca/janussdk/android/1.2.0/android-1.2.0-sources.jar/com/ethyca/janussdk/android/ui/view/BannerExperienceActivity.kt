package com.ethyca.janussdk.android.ui.view

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.ethyca.janussdk.android.Janus
import com.ethyca.janussdk.android.R
import com.ethyca.janussdk.android.consent.ConsentManager
import com.ethyca.janussdk.android.core.JanusProvider
import com.ethyca.janussdk.android.databinding.ActivityBannerExperienceBinding
import com.ethyca.janussdk.android.events.ExperienceShownEvent
import com.ethyca.janussdk.android.models.ServingComponent
import com.ethyca.janussdk.android.ui.ExperienceConsentSession

/**
 * Compact first-layer banner for `banner_and_modal` experiences; Settings hands off to [PrivacyExperienceActivity].
 */
class BannerExperienceActivity : AppCompatActivity() {

    private lateinit var binding: ActivityBannerExperienceBinding
    private var session: ExperienceConsentSession? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBannerExperienceBinding.inflate(layoutInflater)
        setContentView(binding.root)
        keepBannerAboveNavigationBar()

        val experience = JanusProvider.shared.currentExperience
        if (experience == null) {
            super.finish()
            return
        }
        val session = ExperienceConsentSession(experience, ConsentManager()).also { session = it }

        bindContent(session)
        bindButtons(session)
        setupBackPressHandling(session)
        session.recordNoticesServed(ServingComponent.BANNER)
    }

    /** Pads the card by the navigation-bar inset, which edge-to-edge windows (targetSdk 35+) otherwise draw under */
    private fun keepBannerAboveNavigationBar() {
        val container = binding.bannerContainer
        val basePadding = container.paddingBottom
        ViewCompat.setOnApplyWindowInsetsListener(container) { view, insets ->
            val navigationBar = insets.getInsets(WindowInsetsCompat.Type.navigationBars())
            view.setPadding(view.paddingLeft, view.paddingTop, view.paddingRight, basePadding + navigationBar.bottom)
            insets
        }
    }

    private fun bindContent(session: ExperienceConsentSession) {
        binding.bannerTitle.text = session.bannerTitle.orEmpty()
        val description = session.bannerDescription
        if (description == null) {
            binding.bannerDescriptionScroll.visibility = View.GONE
        } else {
            binding.bannerDescription.setHtmlContent(description, session.experience.vendorCount)
            capDescriptionHeight()
        }
    }

    private fun capDescriptionHeight() {
        val maxHeight = (MAX_DESCRIPTION_HEIGHT_DP * resources.displayMetrics.density).toInt()
        binding.bannerDescriptionScroll.post {
            if (binding.bannerDescriptionScroll.height > maxHeight) {
                binding.bannerDescriptionScroll.layoutParams.height = maxHeight
                binding.bannerDescriptionScroll.requestLayout()
            }
        }
    }

    private fun bindButtons(session: ExperienceConsentSession) {
        val translation = session.translatedExperienceConfig
        val acknowledgeOnly = session.bannerShowsAcknowledgeOnly

        binding.bannerAcknowledgeButton.visibility = if (acknowledgeOnly) View.VISIBLE else View.GONE
        binding.bannerAcceptAllButton.visibility = if (acknowledgeOnly) View.GONE else View.VISIBLE
        binding.bannerRejectAllButton.visibility = if (acknowledgeOnly) View.GONE else View.VISIBLE

        translation?.acknowledgeButtonLabel?.let { binding.bannerAcknowledgeButton.text = it }
        translation?.acceptButtonLabel?.let { binding.bannerAcceptAllButton.text = it }
        translation?.rejectButtonLabel?.let { binding.bannerRejectAllButton.text = it }
        translation?.privacyPreferencesLinkLabel?.let { binding.bannerSettingsButton.text = it }

        binding.bannerAcknowledgeButton.setOnClickListener { session.acknowledgeAll(session.initialToggleValues()); finish() }
        binding.bannerAcceptAllButton.setOnClickListener { session.acceptAll(); finish() }
        binding.bannerRejectAllButton.setOnClickListener { session.rejectAll(); finish() }
        binding.bannerSettingsButton.setOnClickListener { openSettings(session) }

        if (session.isDismissable) {
            binding.bannerCloseButton.visibility = View.VISIBLE
            binding.bannerCloseButton.setOnClickListener { session.dismiss("close_button"); finish() }
        }
    }

    private fun setupBackPressHandling(session: ExperienceConsentSession) {
        dismissOnBackIfAllowed({ session.isDismissable }) {
            session.dismiss("back_button")
            finish()
        }
    }

    private fun openSettings(session: ExperienceConsentSession) {
        session.markHandedOff()
        startActivity(Intent(this, PrivacyExperienceActivity::class.java))
        Janus.notifyEventListeners(ExperienceShownEvent())
        finish()
    }

    override fun finish() {
        // Finishing without a recorded choice counts as a dismiss, matching the modal
        session?.dismiss("swipe_dismiss")
        super.finish()
    }

    private companion object {
        const val MAX_DESCRIPTION_HEIGHT_DP = 240
    }
}
