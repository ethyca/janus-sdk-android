package com.ethyca.janussdk.android.models

import com.ethyca.janussdk.android.utils.TranslationInterface
import com.ethyca.janussdk.android.utils.TranslationWithDefaultInterface
import java.util.Date

/**
 * Response from the Privacy Experience API
 */
data class PrivacyExperienceResponse(
    val items: List<PrivacyExperienceItem>? = null,
    val total: Int? = null,
    val page: Int? = null,
    val size: Int? = null,
    val pages: Int? = null
)

/**
 * An individual privacy experience configuration item
 */
data class PrivacyExperienceItem(
    val id: String? = null,
    val createdAt: Date? = null,
    val updatedAt: Date? = null,
    val region: String? = null,
    val gppSettings: GPPSettings? = null,
    val privacyNotices: List<PrivacyNotice>? = null,
    val nonApplicablePrivacyNotices: List<String>? = null,
    val experienceConfig: ExperienceConfig? = null,
    val availableLocales: List<String>? = null,
    val meta: PrivacyMeta? = null,
    val tcfSystemLegitimateInterests: List<TCFSystem>? = null,
    val tcfSpecialFeatures: List<TCFSpecialFeature>? = null,
    val tcfVendorLegitimateInterests: List<TCFVendorLegitimateInterest>? = null,
    val tcfVendorRelationships: List<TCFVendorRelationship>? = null,
    val gvlTranslations: Map<String, GVLTranslation>? = null,
    val tcfPurposeConsents: List<TCFPurposeItem>? = null,
    val tcfVendorConsents: List<TCFVendor>? = null,
    val tcfPurposeLegitimateInterests: List<TCFPurposeItem>? = null,
    val tcfSystemRelationships: List<TCFSystemRelationship>? = null,
    val tcfSpecialPurposes: List<TCFSpecialPurpose>? = null,
    val gvl: Map<String, String>? = null,
    val tcfPublisherCountryCode: String? = null,

    // Minimal TCF specific fields
    val minimalTcf: Boolean? = null,
    val vendorCount: Int? = null,
    val tcfVendorConsentIds: List<String>? = null,
    val tcfVendorLegitimateInterestIds: List<String>? = null,
    val tcfPurposeConsentIds: List<Int>? = null,
    val tcfPurposeLegitimateInterestIds: List<Int>? = null,
    val tcfSpecialFeatureIds: List<Int>? = null,
    val tcfSpecialPurposeIds: List<Int>? = null,
    val tcfFeatureIds: List<Int>? = null,
    val tcfSystemConsentIds: List<String>? = null,
    val tcfSystemLegitimateInterestIds: List<String>? = null,
    val tcfPurposeNames: List<String>? = null,
    val tcfSpecialFeatureNames: List<String>? = null
) {
    // Computed property to get all notices (including children) in a flat list
    val allNotices: List<PrivacyNotice>
        get() {
            val notices = mutableListOf<PrivacyNotice>()
            privacyNotices?.let { notices.addAll(it) }
            privacyNotices?.forEach { notice ->
                notice.children?.let { children ->
                    notices.addAll(children.flatMap { it.allNotices })
                }
            }
            return notices
        }

    // Computed property to determine if this is a TCF experience
    val isTCFExperience: Boolean
        get() {
            // Check if the experience config component contains "tcf"
            val hasTcfComponent = experienceConfig?.component?.contains("tcf", ignoreCase = true) == true

            // Check if there are TCF purpose consent IDs
            val hasTcfPurposeConsentIds = tcfPurposeConsentIds?.isNotEmpty() == true

            // Check if there are TCF purpose consents
            val hasTcfPurposeConsents = tcfPurposeConsents?.isNotEmpty() == true

            // Return true if any of the TCF indicators are present
            return hasTcfComponent || hasTcfPurposeConsentIds || hasTcfPurposeConsents
        }
}

/**
 * Represents the GVL translations for a specific language
 */
data class GVLTranslation(
    val gvlSpecificationVersion: Int? = null,
    val vendorListVersion: Int? = null,
    val tcfPolicyVersion: Int? = null,
    val lastUpdated: String? = null,
    val purposes: Map<String, GVLPurpose>? = null
)

/**
 * Represents a GVL Purpose
 */
data class GVLPurpose(
    val id: Int? = null,
    val name: String? = null,
    val description: String? = null,
    val illustrations: List<String>? = null
)

/**
 * Represents a TCF Purpose Item used in purpose consents and legitimate interests
 */
data class TCFPurposeItem(
    val id: Int? = null,
    val name: String? = null,
    val description: String? = null,
    val illustrations: List<String>? = null,
    val dataUses: List<String>? = null,
    val defaultPreference: String? = null,
    val vendors: List<TCFVendor>? = null,
    val systems: List<TCFSystem>? = null
)

/**
 * Represents a TCF Vendor Legitimate Interest object
 */
data class TCFVendorLegitimateInterest(
    val id: String? = null,
    val hasVendorId: Boolean? = null,
    val name: String? = null,
    val description: String? = null,
    val vendorDeletedDate: String? = null,
    val defaultPreference: String? = null,
    val purposeLegitimateInterests: List<PurposeLegitimateInterest>? = null
)

/**
 * Represents a Purpose Legitimate Interest within a TCF Vendor
 */
data class PurposeLegitimateInterest(
    val id: Int? = null,
    val name: String? = null,
    val retentionPeriod: String? = null
)

/**
 * Represents a TCF Special Feature object seen in some API responses
 */
data class TCFSpecialFeature(
    val id: Int? = null,
    val name: String? = null,
    val description: String? = null,
    val defaultPreference: String? = null,
    val vendors: List<TCFVendor>? = null,
    val systems: List<TCFSystem>? = null
)

/**
 * Represents a TCF Vendor object
 */
data class TCFVendor(
    val id: String? = null,
    val name: String? = null
)

/**
 * Represents a TCF System object
 */
class TCFSystem {
    // Empty class that will be expanded when we know more about the implementation

    // Override equals and hashCode for proper collection handling
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        return true
    }

    override fun hashCode(): Int {
        return javaClass.hashCode()
    }
}

/**
 * Global Privacy Platform settings
 */
data class GPPSettings(
    val usApproach: String? = null,
    val mspaServiceProviderMode: Boolean? = null,
    val mspaOptOutOptionMode: Boolean? = null,
    val mspaCoveredTransactions: Boolean? = null,
    val enableTcfeuString: Boolean? = null,
    val enabled: Boolean? = null
)

/**
 * Represents the GPP field mapping structure
 */
data class GPPFieldMapping(
    val region: String? = null,
    val mechanism: List<GPPMechanism>? = null,
    val notice: List<String>? = null
) {
    // Computed property to get all mechanisms
    val allMechanisms: List<GPPMechanism>
        get() = mechanism ?: emptyList()
}

/**
 * Represents a GPP mechanism mapping
 */
data class GPPMechanism(
    val optOut: String? = null,
    val notAvailable: String? = null,
    val notOptOut: String? = null,
    val field: String? = null
)

/**
 * Privacy notice definition
 */
data class PrivacyNotice(
    val name: String? = null,
    val noticeKey: String? = null,
    val internalDescription: String? = null,
    val consentMechanism: String? = null,
    val dataUses: List<String>? = null,
    val enforcementLevel: String? = null,
    val disabled: Boolean? = null,
    val hasGpcFlag: Boolean? = null,
    val framework: String? = null,
    val defaultPreference: String? = null,
    val id: String? = null,
    val origin: String? = null,
    val createdAt: Date? = null,
    val updatedAt: Date? = null,
    val cookies: List<Cookie>? = null,
    val systemsApplicable: Boolean? = null,
    val translations: List<PrivacyNoticeTranslation>? = null,
    val children: List<PrivacyNotice>? = null,
    val gppFieldMapping: List<GPPFieldMapping>? = null
) {
    // Computed property to get all notices (including children) in a flat list
    val allNotices: List<PrivacyNotice>
        get() {
            val notices = mutableListOf(this)
            children?.let { childList ->
                notices.addAll(childList.flatMap { it.allNotices })
            }
            return notices
        }
}

/**
 * Cookie definition
 */
data class Cookie(
    val name: String? = null,
    val path: String? = null,
    val domain: String? = null
)

/**
 * Translation for a privacy notice
 */
data class PrivacyNoticeTranslation(
    override val language: String? = null,
    val title: String? = null,
    val description: String? = null,
    val privacyNoticeHistoryId: String? = null
) : TranslationInterface

/**
 * Configuration for the privacy experience UI
 */
data class ExperienceConfig(
    val name: String? = null,
    val disabled: Boolean? = null,
    val dismissable: Boolean? = null,
    val showLayer1Notices: Boolean? = null,
    val layer1ButtonOptions: String? = null,
    val allowLanguageSelection: Boolean? = null,
    val autoDetectLanguage: Boolean? = null,
    val autoSubdomainCookieDeletion: Boolean? = null,
    val regions: List<String>? = null,
    val id: String? = null,
    val createdAt: Date? = null,
    val updatedAt: Date? = null,
    val component: String? = null,
    val translations: List<ExperienceConfigTranslation>? = null,
    val properties: List<PropertyInfo>? = null
)

/**
 * Translation for the experience configuration
 */
data class ExperienceConfigTranslation(
    override val language: String? = null,
    val acceptButtonLabel: String? = null,
    val acknowledgeButtonLabel: String? = null,
    val bannerTitle: String? = null,
    override val isDefault: Boolean? = null,
    val modalLinkLabel: String? = null,
    val privacyPolicyLinkLabel: String? = null,
    val privacyPolicyUrl: String? = null,
    val privacyPreferencesLinkLabel: String? = null,
    val purposeHeader: String? = null,
    val rejectButtonLabel: String? = null,
    val saveButtonLabel: String? = null,
    val title: String? = null,
    val bannerDescription: String? = null,
    val description: String? = null,
    val privacyExperienceConfigHistoryId: String? = null
) : TranslationWithDefaultInterface

/**
 * Metadata for the privacy experience
 */
data class PrivacyMeta(
    val versionHash: String? = null,
    val acceptAllFidesString: String? = null,
    val acceptAllFidesMobileData: FidesMobileData? = null,
    val rejectAllFidesString: String? = null,
    val rejectAllFidesMobileData: FidesMobileData? = null
)

/**
 * Property information
 */
data class PropertyInfo(
    val id: String? = null,
    val name: String? = null
)

/**
 * Represents a TCF Vendor Relationship
 */
data class TCFVendorRelationship(
    val id: String? = null,
    val name: String? = null
)

/**
 * Represents a TCF System Relationship
 */
data class TCFSystemRelationship(
    val id: String? = null,
    val name: String? = null
)

/**
 * Represents a TCF Special Purpose
 */
data class TCFSpecialPurpose(
    val id: Int? = null,
    val name: String? = null,
    val description: String? = null
)
