package com.ethyca.janussdk.android.models

/**
 * Mapper to convert between DTO and domain models for privacy experience data
 */
object PrivacyExperienceMapper {

    /**
     * Maps a DTO response to a domain model response
     */
    fun mapResponseToDomain(dto: PrivacyExperienceResponseDTO): PrivacyExperienceResponse {
        return PrivacyExperienceResponse(
            items = dto.items?.map { mapItemToDomain(it) },
            total = dto.total,
            page = dto.page,
            size = dto.size,
            pages = dto.pages
        )
    }
    
    /**
     * Maps a privacy experience item DTO to domain model
     */
    fun mapItemToDomain(dto: PrivacyExperienceItemDTO): PrivacyExperienceItem {
        return PrivacyExperienceItem(
            id = dto.id,
            createdAt = dto.createdAt,
            updatedAt = dto.updatedAt,
            region = dto.region,
            gppSettings = dto.gppSettings?.let { mapGppSettingsToDomain(it) },
            privacyNotices = dto.privacyNotices?.map { mapNoticeToDomain(it) },
            nonApplicablePrivacyNotices = dto.nonApplicablePrivacyNotices,
            experienceConfig = dto.experienceConfig?.let { mapConfigToDomain(it) },
            availableLocales = dto.availableLocales,
            meta = dto.meta?.let { mapMetaToDomain(it) },
            tcfSystemLegitimateInterests = dto.tcfSystemLegitimateInterests?.map { mapSystemToDomain() },
            tcfSpecialFeatures = dto.tcfSpecialFeatures?.map { mapSpecialFeatureToDomain(it) },
            tcfVendorLegitimateInterests = dto.tcfVendorLegitimateInterests?.map { mapVendorLegitimateInterestToDomain(it) },
            tcfVendorRelationships = dto.tcfVendorRelationships?.map { mapVendorRelationshipToDomain(it) },
            gvlTranslations = dto.gvlTranslations?.mapValues { mapGvlTranslationToDomain(it.value) },
            tcfPurposeConsents = dto.tcfPurposeConsents?.map { mapTcfPurposeItemToDomain(it) },
            tcfVendorConsents = dto.tcfVendorConsents?.map { mapVendorToDomain(it) },
            tcfPurposeLegitimateInterests = dto.tcfPurposeLegitimateInterests?.map { mapTcfPurposeItemToDomain(it) },
            tcfSystemRelationships = dto.tcfSystemRelationships?.map { mapSystemRelationshipToDomain(it) },
            tcfSpecialPurposes = dto.tcfSpecialPurposes?.map { mapSpecialPurposeToDomain(it) },
            gvl = dto.gvl,
            tcfPublisherCountryCode = dto.tcfPublisherCountryCode,
            
            // Minimal TCF specific fields
            minimalTcf = dto.minimalTcf,
            vendorCount = dto.vendorCount,
            tcfVendorConsentIds = dto.tcfVendorConsentIds,
            tcfVendorLegitimateInterestIds = dto.tcfVendorLegitimateInterestIds,
            tcfPurposeConsentIds = dto.tcfPurposeConsentIds,
            tcfPurposeLegitimateInterestIds = dto.tcfPurposeLegitimateInterestIds,
            tcfSpecialFeatureIds = dto.tcfSpecialFeatureIds,
            tcfSpecialPurposeIds = dto.tcfSpecialPurposeIds,
            tcfFeatureIds = dto.tcfFeatureIds,
            tcfSystemConsentIds = dto.tcfSystemConsentIds,
            tcfSystemLegitimateInterestIds = dto.tcfSystemLegitimateInterestIds,
            tcfPurposeNames = dto.tcfPurposeNames,
            tcfSpecialFeatureNames = dto.tcfSpecialFeatureNames
        )
    }
    
    /**
     * Maps a GVLTranslation DTO to domain model
     */
    private fun mapGvlTranslationToDomain(dto: GVLTranslationDTO): GVLTranslation {
        return GVLTranslation(
            gvlSpecificationVersion = dto.gvlSpecificationVersion,
            vendorListVersion = dto.vendorListVersion,
            tcfPolicyVersion = dto.tcfPolicyVersion,
            lastUpdated = dto.lastUpdated,
            purposes = dto.purposes?.mapValues { mapGvlPurposeToDomain(it.value) }
        )
    }
    
    /**
     * Maps a GVLPurpose DTO to domain model
     */
    private fun mapGvlPurposeToDomain(dto: GVLPurposeDTO): GVLPurpose {
        return GVLPurpose(
            id = dto.id,
            name = dto.name,
            description = dto.description,
            illustrations = dto.illustrations
        )
    }
    
    /**
     * Maps a TCFPurposeItem DTO to domain model
     */
    private fun mapTcfPurposeItemToDomain(dto: TCFPurposeItemDTO): TCFPurposeItem {
        return TCFPurposeItem(
            id = dto.id,
            name = dto.name,
            description = dto.description,
            illustrations = dto.illustrations,
            dataUses = dto.dataUses,
            defaultPreference = dto.defaultPreference,
            vendors = dto.vendors?.map { mapVendorToDomain(it) },
            systems = dto.systems?.map { mapSystemToDomain() }
        )
    }
    
    /**
     * Maps a TCFVendorLegitimateInterest DTO to domain model
     */
    private fun mapVendorLegitimateInterestToDomain(dto: TCFVendorLegitimateInterestDTO): TCFVendorLegitimateInterest {
        return TCFVendorLegitimateInterest(
            id = dto.id,
            hasVendorId = dto.hasVendorId,
            name = dto.name,
            description = dto.description,
            vendorDeletedDate = dto.vendorDeletedDate,
            defaultPreference = dto.defaultPreference,
            purposeLegitimateInterests = dto.purposeLegitimateInterests?.map { mapPurposeLegitimateInterestToDomain(it) }
        )
    }
    
    /**
     * Maps a PurposeLegitimateInterest DTO to domain model
     */
    private fun mapPurposeLegitimateInterestToDomain(dto: PurposeLegitimateInterestDTO): PurposeLegitimateInterest {
        return PurposeLegitimateInterest(
            id = dto.id,
            name = dto.name,
            retentionPeriod = dto.retentionPeriod
        )
    }
    
    /**
     * Maps a TCFSpecialFeature DTO to domain model
     */
    private fun mapSpecialFeatureToDomain(dto: TCFSpecialFeatureDTO): TCFSpecialFeature {
        return TCFSpecialFeature(
            id = dto.id,
            name = dto.name,
            description = dto.description,
            defaultPreference = dto.defaultPreference,
            vendors = dto.vendors?.map { mapVendorToDomain(it) },
            systems = dto.systems?.map { mapSystemToDomain() }
        )
    }
    
    /**
     * Maps a TCFVendor DTO to domain model
     */
    private fun mapVendorToDomain(dto: TCFVendorDTO): TCFVendor {
        return TCFVendor(
            id = dto.id,
            name = dto.name
        )
    }
    
    /**
     * Maps a TCFSystem DTO to domain model
     */
    private fun mapSystemToDomain(): TCFSystem {
        return TCFSystem()
    }
    
    /**
     * Maps a GPPSettings DTO to domain model
     */
    private fun mapGppSettingsToDomain(dto: GPPSettingsDTO): GPPSettings {
        return GPPSettings(
            usApproach = dto.usApproach,
            mspaServiceProviderMode = dto.mspaServiceProviderMode,
            mspaOptOutOptionMode = dto.mspaOptOutOptionMode,
            mspaCoveredTransactions = dto.mspaCoveredTransactions,
            enableTcfeuString = dto.enableTcfeuString,
            enabled = dto.enabled
        )
    }
    
    /**
     * Maps a GPPFieldMapping DTO to domain model
     */
    private fun mapGppFieldMappingToDomain(dto: GPPFieldMappingDTO): GPPFieldMapping {
        return GPPFieldMapping(
            region = dto.region,
            mechanism = dto.mechanism?.map { mapGppMechanismToDomain(it) },
            notice = dto.notice
        )
    }
    
    /**
     * Maps a GPPMechanism DTO to domain model
     */
    private fun mapGppMechanismToDomain(dto: GPPMechanismDTO): GPPMechanism {
        return GPPMechanism(
            optOut = dto.optOut,
            notAvailable = dto.notAvailable,
            notOptOut = dto.notOptOut,
            field = dto.field
        )
    }
    
    /**
     * Maps a PrivacyNotice DTO to domain model
     */
    private fun mapNoticeToDomain(dto: PrivacyNoticeDTO): PrivacyNotice {
        return PrivacyNotice(
            name = dto.name,
            noticeKey = dto.noticeKey,
            internalDescription = dto.internalDescription,
            consentMechanism = dto.consentMechanism,
            dataUses = dto.dataUses,
            enforcementLevel = dto.enforcementLevel,
            disabled = dto.disabled,
            hasGpcFlag = dto.hasGpcFlag,
            framework = dto.framework,
            defaultPreference = dto.defaultPreference,
            id = dto.id,
            origin = dto.origin,
            createdAt = dto.createdAt,
            updatedAt = dto.updatedAt,
            cookies = dto.cookies?.map { mapCookieToDomain(it) },
            systemsApplicable = dto.systemsApplicable,
            translations = dto.translations?.map { mapNoticeTranslationToDomain(it) },
            children = dto.children?.map { mapNoticeToDomain(it) },
            gppFieldMapping = dto.gppFieldMapping?.map { mapGppFieldMappingToDomain(it) }
        )
    }
    
    /**
     * Maps a Cookie DTO to domain model
     */
    private fun mapCookieToDomain(dto: CookieDTO): Cookie {
        return Cookie(
            name = dto.name,
            path = dto.path,
            domain = dto.domain
        )
    }
    
    /**
     * Maps a PrivacyNoticeTranslation DTO to domain model
     */
    private fun mapNoticeTranslationToDomain(dto: PrivacyNoticeTranslationDTO): PrivacyNoticeTranslation {
        return PrivacyNoticeTranslation(
            language = dto.language,
            title = dto.title,
            description = dto.description,
            privacyNoticeHistoryId = dto.privacyNoticeHistoryId
        )
    }
    
    /**
     * Maps an ExperienceConfig DTO to domain model
     */
    private fun mapConfigToDomain(dto: ExperienceConfigDTO): ExperienceConfig {
        return ExperienceConfig(
            name = dto.name,
            disabled = dto.disabled,
            dismissable = dto.dismissable,
            showLayer1Notices = dto.showLayer1Notices,
            layer1ButtonOptions = dto.layer1ButtonOptions,
            allowLanguageSelection = dto.allowLanguageSelection,
            autoDetectLanguage = dto.autoDetectLanguage,
            autoSubdomainCookieDeletion = dto.autoSubdomainCookieDeletion,
            regions = dto.regions,
            id = dto.id,
            createdAt = dto.createdAt,
            updatedAt = dto.updatedAt,
            component = dto.component,
            translations = dto.translations?.map { mapConfigTranslationToDomain(it) },
            properties = dto.properties?.map { mapPropertyInfoToDomain(it) }
        )
    }
    
    /**
     * Maps an ExperienceConfigTranslation DTO to domain model
     */
    private fun mapConfigTranslationToDomain(dto: ExperienceConfigTranslationDTO): ExperienceConfigTranslation {
        return ExperienceConfigTranslation(
            language = dto.language,
            acceptButtonLabel = dto.acceptButtonLabel,
            acknowledgeButtonLabel = dto.acknowledgeButtonLabel,
            bannerTitle = dto.bannerTitle,
            isDefault = dto.isDefault,
            modalLinkLabel = dto.modalLinkLabel,
            privacyPolicyLinkLabel = dto.privacyPolicyLinkLabel,
            privacyPolicyUrl = dto.privacyPolicyUrl,
            privacyPreferencesLinkLabel = dto.privacyPreferencesLinkLabel,
            purposeHeader = dto.purposeHeader,
            rejectButtonLabel = dto.rejectButtonLabel,
            saveButtonLabel = dto.saveButtonLabel,
            title = dto.title,
            bannerDescription = dto.bannerDescription,
            description = dto.description,
            privacyExperienceConfigHistoryId = dto.privacyExperienceConfigHistoryId
        )
    }
    
    /**
     * Maps a PrivacyMeta DTO to domain model
     */
    private fun mapMetaToDomain(dto: PrivacyMetaDTO): PrivacyMeta {
        return PrivacyMeta(
            versionHash = dto.versionHash,
            acceptAllFidesString = dto.acceptAllFidesString,
            acceptAllFidesMobileData = dto.acceptAllFidesMobileData,
            rejectAllFidesString = dto.rejectAllFidesString,
            rejectAllFidesMobileData = dto.rejectAllFidesMobileData
        )
    }
    
    /**
     * Maps a PropertyInfo DTO to domain model
     */
    private fun mapPropertyInfoToDomain(dto: PropertyInfoDTO): PropertyInfo {
        return PropertyInfo(
            id = dto.id,
            name = dto.name
        )
    }
    
    /**
     * Maps a TCFVendorRelationship DTO to domain model
     */
    private fun mapVendorRelationshipToDomain(dto: TCFVendorRelationshipDTO): TCFVendorRelationship {
        return TCFVendorRelationship(
            id = dto.id,
            name = dto.name
        )
    }
    
    /**
     * Maps a TCFSystemRelationship DTO to domain model
     */
    private fun mapSystemRelationshipToDomain(dto: TCFSystemRelationshipDTO): TCFSystemRelationship {
        return TCFSystemRelationship(
            id = dto.id,
            name = dto.name
        )
    }
    
    /**
     * Maps a TCFSpecialPurpose DTO to domain model
     */
    private fun mapSpecialPurposeToDomain(dto: TCFSpecialPurposeDTO): TCFSpecialPurpose {
        return TCFSpecialPurpose(
            id = dto.id,
            name = dto.name,
            description = dto.description
        )
    }
    
    /**
     * Maps a domain response to a DTO response (for cases where we need to convert back)
     */
    fun mapResponseToDto(domain: PrivacyExperienceResponse): PrivacyExperienceResponseDTO {
        return PrivacyExperienceResponseDTO(
            items = domain.items?.map { mapItemToDto(it) },
            total = domain.total,
            page = domain.page,
            size = domain.size,
            pages = domain.pages
        )
    }
    
    /**
     * Maps a privacy experience item domain model to DTO 
     */
    fun mapItemToDto(domain: PrivacyExperienceItem): PrivacyExperienceItemDTO {
        return PrivacyExperienceItemDTO(
            id = domain.id,
            createdAt = domain.createdAt,
            updatedAt = domain.updatedAt,
            region = domain.region,
            gppSettings = domain.gppSettings?.let { mapGppSettingsToDto(it) },
            privacyNotices = domain.privacyNotices?.map { mapNoticeToDto(it) },
            nonApplicablePrivacyNotices = domain.nonApplicablePrivacyNotices,
            experienceConfig = domain.experienceConfig?.let { mapConfigToDto(it) },
            availableLocales = domain.availableLocales,
            meta = domain.meta?.let { mapMetaToDto(it) },
            tcfSystemLegitimateInterests = domain.tcfSystemLegitimateInterests?.map { mapSystemToDto() },
            tcfSpecialFeatures = domain.tcfSpecialFeatures?.map { mapSpecialFeatureToDto(it) },
            tcfVendorLegitimateInterests = domain.tcfVendorLegitimateInterests?.map { mapVendorLegitimateInterestToDto(it) },
            tcfVendorRelationships = domain.tcfVendorRelationships?.map { mapVendorRelationshipToDto(it) },
            gvlTranslations = domain.gvlTranslations?.mapValues { mapGvlTranslationToDto(it.value) },
            tcfPurposeConsents = domain.tcfPurposeConsents?.map { mapTcfPurposeItemToDto(it) },
            tcfVendorConsents = domain.tcfVendorConsents?.map { mapVendorToDto(it) },
            tcfPurposeLegitimateInterests = domain.tcfPurposeLegitimateInterests?.map { mapTcfPurposeItemToDto(it) },
            tcfSystemRelationships = domain.tcfSystemRelationships?.map { mapSystemRelationshipToDto(it) },
            tcfSpecialPurposes = domain.tcfSpecialPurposes?.map { mapSpecialPurposeToDto(it) },
            gvl = domain.gvl,
            tcfPublisherCountryCode = domain.tcfPublisherCountryCode,
            
            // Minimal TCF specific fields
            minimalTcf = domain.minimalTcf,
            vendorCount = domain.vendorCount,
            tcfVendorConsentIds = domain.tcfVendorConsentIds,
            tcfVendorLegitimateInterestIds = domain.tcfVendorLegitimateInterestIds,
            tcfPurposeConsentIds = domain.tcfPurposeConsentIds,
            tcfPurposeLegitimateInterestIds = domain.tcfPurposeLegitimateInterestIds,
            tcfSpecialFeatureIds = domain.tcfSpecialFeatureIds,
            tcfSpecialPurposeIds = domain.tcfSpecialPurposeIds,
            tcfFeatureIds = domain.tcfFeatureIds,
            tcfSystemConsentIds = domain.tcfSystemConsentIds,
            tcfSystemLegitimateInterestIds = domain.tcfSystemLegitimateInterestIds,
            tcfPurposeNames = domain.tcfPurposeNames,
            tcfSpecialFeatureNames = domain.tcfSpecialFeatureNames
        )
    }
    
    // The following methods convert from domain models to DTOs
    
    private fun mapGvlTranslationToDto(domain: GVLTranslation): GVLTranslationDTO {
        return GVLTranslationDTO(
            gvlSpecificationVersion = domain.gvlSpecificationVersion,
            vendorListVersion = domain.vendorListVersion,
            tcfPolicyVersion = domain.tcfPolicyVersion,
            lastUpdated = domain.lastUpdated,
            purposes = domain.purposes?.mapValues { mapGvlPurposeToDto(it.value) }
        )
    }
    
    private fun mapGvlPurposeToDto(domain: GVLPurpose): GVLPurposeDTO {
        return GVLPurposeDTO(
            id = domain.id,
            name = domain.name,
            description = domain.description,
            illustrations = domain.illustrations
        )
    }
    
    private fun mapTcfPurposeItemToDto(domain: TCFPurposeItem): TCFPurposeItemDTO {
        return TCFPurposeItemDTO(
            id = domain.id,
            name = domain.name,
            description = domain.description,
            illustrations = domain.illustrations,
            dataUses = domain.dataUses,
            defaultPreference = domain.defaultPreference,
            vendors = domain.vendors?.map { mapVendorToDto(it) },
            systems = domain.systems?.map { mapSystemToDto() }
        )
    }
    
    private fun mapVendorLegitimateInterestToDto(domain: TCFVendorLegitimateInterest): TCFVendorLegitimateInterestDTO {
        return TCFVendorLegitimateInterestDTO(
            id = domain.id,
            hasVendorId = domain.hasVendorId,
            name = domain.name,
            description = domain.description,
            vendorDeletedDate = domain.vendorDeletedDate,
            defaultPreference = domain.defaultPreference,
            purposeLegitimateInterests = domain.purposeLegitimateInterests?.map { mapPurposeLegitimateInterestToDto(it) }
        )
    }
    
    private fun mapPurposeLegitimateInterestToDto(domain: PurposeLegitimateInterest): PurposeLegitimateInterestDTO {
        return PurposeLegitimateInterestDTO(
            id = domain.id,
            name = domain.name,
            retentionPeriod = domain.retentionPeriod
        )
    }
    
    private fun mapSpecialFeatureToDto(domain: TCFSpecialFeature): TCFSpecialFeatureDTO {
        return TCFSpecialFeatureDTO(
            id = domain.id,
            name = domain.name,
            description = domain.description,
            defaultPreference = domain.defaultPreference,
            vendors = domain.vendors?.map { mapVendorToDto(it) },
            systems = domain.systems?.map { mapSystemToDto() }
        )
    }
    
    private fun mapVendorToDto(domain: TCFVendor): TCFVendorDTO {
        return TCFVendorDTO(
            id = domain.id,
            name = domain.name
        )
    }
    
    private fun mapSystemToDto(): TCFSystemDTO {
        return TCFSystemDTO()
    }
    
    private fun mapGppSettingsToDto(domain: GPPSettings): GPPSettingsDTO {
        return GPPSettingsDTO(
            usApproach = domain.usApproach,
            mspaServiceProviderMode = domain.mspaServiceProviderMode,
            mspaOptOutOptionMode = domain.mspaOptOutOptionMode,
            mspaCoveredTransactions = domain.mspaCoveredTransactions,
            enableTcfeuString = domain.enableTcfeuString,
            enabled = domain.enabled
        )
    }
    
    private fun mapGppFieldMappingToDto(domain: GPPFieldMapping): GPPFieldMappingDTO {
        return GPPFieldMappingDTO(
            region = domain.region,
            mechanism = domain.mechanism?.map { mapGppMechanismToDto(it) },
            notice = domain.notice
        )
    }
    
    private fun mapGppMechanismToDto(domain: GPPMechanism): GPPMechanismDTO {
        return GPPMechanismDTO(
            optOut = domain.optOut,
            notAvailable = domain.notAvailable,
            notOptOut = domain.notOptOut,
            field = domain.field
        )
    }
    
    private fun mapNoticeToDto(domain: PrivacyNotice): PrivacyNoticeDTO {
        return PrivacyNoticeDTO(
            name = domain.name,
            noticeKey = domain.noticeKey,
            internalDescription = domain.internalDescription,
            consentMechanism = domain.consentMechanism,
            dataUses = domain.dataUses,
            enforcementLevel = domain.enforcementLevel,
            disabled = domain.disabled,
            hasGpcFlag = domain.hasGpcFlag,
            framework = domain.framework,
            defaultPreference = domain.defaultPreference,
            id = domain.id,
            origin = domain.origin,
            createdAt = domain.createdAt,
            updatedAt = domain.updatedAt,
            cookies = domain.cookies?.map { mapCookieToDto(it) },
            systemsApplicable = domain.systemsApplicable,
            translations = domain.translations?.map { mapNoticeTranslationToDto(it) },
            children = domain.children?.map { mapNoticeToDto(it) },
            gppFieldMapping = domain.gppFieldMapping?.map { mapGppFieldMappingToDto(it) }
        )
    }
    
    private fun mapCookieToDto(domain: Cookie): CookieDTO {
        return CookieDTO(
            name = domain.name,
            path = domain.path,
            domain = domain.domain
        )
    }
    
    private fun mapNoticeTranslationToDto(domain: PrivacyNoticeTranslation): PrivacyNoticeTranslationDTO {
        return PrivacyNoticeTranslationDTO(
            language = domain.language,
            title = domain.title,
            description = domain.description,
            privacyNoticeHistoryId = domain.privacyNoticeHistoryId
        )
    }
    
    private fun mapConfigToDto(domain: ExperienceConfig): ExperienceConfigDTO {
        return ExperienceConfigDTO(
            name = domain.name,
            disabled = domain.disabled,
            dismissable = domain.dismissable,
            showLayer1Notices = domain.showLayer1Notices,
            layer1ButtonOptions = domain.layer1ButtonOptions,
            allowLanguageSelection = domain.allowLanguageSelection,
            autoDetectLanguage = domain.autoDetectLanguage,
            autoSubdomainCookieDeletion = domain.autoSubdomainCookieDeletion,
            regions = domain.regions,
            id = domain.id,
            createdAt = domain.createdAt,
            updatedAt = domain.updatedAt,
            component = domain.component,
            translations = domain.translations?.map { mapConfigTranslationToDto(it) },
            properties = domain.properties?.map { mapPropertyInfoToDto(it) }
        )
    }
    
    private fun mapConfigTranslationToDto(domain: ExperienceConfigTranslation): ExperienceConfigTranslationDTO {
        return ExperienceConfigTranslationDTO(
            language = domain.language,
            acceptButtonLabel = domain.acceptButtonLabel,
            acknowledgeButtonLabel = domain.acknowledgeButtonLabel,
            bannerTitle = domain.bannerTitle,
            isDefault = domain.isDefault,
            modalLinkLabel = domain.modalLinkLabel,
            privacyPolicyLinkLabel = domain.privacyPolicyLinkLabel,
            privacyPolicyUrl = domain.privacyPolicyUrl,
            privacyPreferencesLinkLabel = domain.privacyPreferencesLinkLabel,
            purposeHeader = domain.purposeHeader,
            rejectButtonLabel = domain.rejectButtonLabel,
            saveButtonLabel = domain.saveButtonLabel,
            title = domain.title,
            bannerDescription = domain.bannerDescription,
            description = domain.description,
            privacyExperienceConfigHistoryId = domain.privacyExperienceConfigHistoryId
        )
    }
    
    private fun mapMetaToDto(domain: PrivacyMeta): PrivacyMetaDTO {
        return PrivacyMetaDTO(
            versionHash = domain.versionHash,
            acceptAllFidesString = domain.acceptAllFidesString,
            acceptAllFidesMobileData = domain.acceptAllFidesMobileData,
            rejectAllFidesString = domain.rejectAllFidesString,
            rejectAllFidesMobileData = domain.rejectAllFidesMobileData
        )
    }
    
    private fun mapPropertyInfoToDto(domain: PropertyInfo): PropertyInfoDTO {
        return PropertyInfoDTO(
            id = domain.id,
            name = domain.name
        )
    }
    
    private fun mapVendorRelationshipToDto(domain: TCFVendorRelationship): TCFVendorRelationshipDTO {
        return TCFVendorRelationshipDTO(
            id = domain.id,
            name = domain.name
        )
    }
    
    private fun mapSystemRelationshipToDto(domain: TCFSystemRelationship): TCFSystemRelationshipDTO {
        return TCFSystemRelationshipDTO(
            id = domain.id,
            name = domain.name
        )
    }
    
    private fun mapSpecialPurposeToDto(domain: TCFSpecialPurpose): TCFSpecialPurposeDTO {
        return TCFSpecialPurposeDTO(
            id = domain.id,
            name = domain.name,
            description = domain.description
        )
    }
} 
