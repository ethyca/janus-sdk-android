package com.ethyca.janussdk.android.utils

/**
 * Enum containing all API route paths used by the Janus SDK
 */
enum class ApiRoutes(val path: String) {
    NOTICES_SERVED("/api/v1/notices-served"),
    PRIVACY_EXPERIENCE("/api/v1/privacy-experience")
} 