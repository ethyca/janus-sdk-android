package com.ethyca.janussdk.android.webview

import android.content.Context
import android.webkit.WebView
import com.ethyca.janussdk.android.Janus
import com.ethyca.janussdk.android.LogLevel
import com.ethyca.janussdk.android.consent.ConsentManager
import com.ethyca.janussdk.android.models.ConsentMethod
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * A utility class that provides synchronization capabilities for WebViews.
 * This handles consent data synchronization between native storage and JavaScript.
 */
class WebViewSynchronizer(private val bridge: FidesJSBridge) {
    companion object {
        private const val TAG = "WebViewSynchronizer"
    }

    // Private instance of ConsentManager for updating consent values
    private val consentManager = ConsentManager()

    /**
     * Synchronizes consent data between native storage and JavaScript.
     * Compares timestamps to determine which side has the most recent data.
     *
     * @param webView The WebView to synchronize with
     */
    fun synchronizeConsentData(webView: WebView) {
        // Get Janus consent metadata
        val janusMetadata = Janus.consentMetadata
        val janusUpdatedAt = janusMetadata.updatedAt

        // Log the attempt with formatted timestamp
        Janus.log("Attempting to synchronize using janusUpdatedAt: ${formatDate(janusUpdatedAt)}", level = LogLevel.DEBUG)

        // Get FidesJS consent metadata
        getConsentMetadataFromJS(webView) { _, fidesUpdatedAt ->
            // Log retrieved timestamp
            Janus.log("Retrieved fidesUpdatedAt: ${formatDate(fidesUpdatedAt)}", level = LogLevel.DEBUG)

            // If both sides have updatedAt timestamps, compare them
            if (janusUpdatedAt != null && fidesUpdatedAt != null) {
                if (fidesUpdatedAt.after(janusUpdatedAt)) {
                    // FidesJS has more recent data - get its consent values and update local storage
                    Janus.log("Fides has more recent data, updating Janus", level = LogLevel.DEBUG)
                    updateJanusFromWebView()
                } else {
                    // Janus storage has more recent data - update FidesJS
                    Janus.log("Janus has more recent data, updating Fides", level = LogLevel.DEBUG)
                    bridge.sendConsentUpdateToJS(Janus.consent)
                }
            } else if (janusUpdatedAt != null) {
                // Only Janus storage has updatedAt timestamp data - update FidesJS
                Janus.log("Only Janus has updatedAt timestamp, updating Fides", level = LogLevel.DEBUG)
                bridge.sendConsentUpdateToJS(Janus.consent)
            } else if (fidesUpdatedAt != null) {
                // Only FidesJS has updatedAt timestamp data - update local storage
                Janus.log("Only Fides has updatedAt timestamp, updating Janus", level = LogLevel.DEBUG)
                updateJanusFromWebView()
            } else {
                // Neither side has updatedAt timestamps - no sync needed
                Janus.log("Neither side has updatedAt timestamps, no sync needed", level = LogLevel.DEBUG)
            }
        }
    }

    /**
     * Updates Janus consent values from a WebView and propagates to other WebViews
     */
    private fun updateJanusFromWebView() {
        bridge.getConsentValuesFromJS { consentValues, fidesString, consentMethod ->
            if (consentValues.isNotEmpty()) {
                // Update consent using the ConsentManager instance
                consentManager.setConsent(
                    values = consentValues,
                    versionHash = Janus.currentExperience?.meta?.versionHash ?: "",
                    fidesString = fidesString,
                    consentMethod = ConsentMethod.fromString(consentMethod)
                )

                // Propagation to other WebViews happens through Janus event system
            }
        }
    }

    /**
     * Retrieves consent timestamp metadata from FidesJS
     */
    private fun getConsentMetadataFromJS(webView: WebView, completion: (Date?, Date?) -> Unit) {
        val jsCode = "window.Janus.getFidesConsentMetadata();"

        webView.evaluateJavascript(jsCode) { result ->
            val unescapedResult = bridge.unescapeJsResult(result)

            if (unescapedResult.isNullOrEmpty()) {
                completion(null, null)
                return@evaluateJavascript
            }

            try {
                // Parse the JSON string to get timestamp metadata
                val jsonObject = org.json.JSONObject(unescapedResult)

                // Convert timestamp strings to Date objects
                val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
                dateFormat.timeZone = TimeZone.getTimeZone("UTC")

                var createdAt: Date? = null
                var updatedAt: Date? = null

                if (jsonObject.has("createdAt") && !jsonObject.isNull("createdAt")) {
                    val createdAtString = jsonObject.getString("createdAt")
                    if (createdAtString.isNotEmpty()) {
                        createdAt = dateFormat.parse(createdAtString)
                    }
                }

                if (jsonObject.has("updatedAt") && !jsonObject.isNull("updatedAt")) {
                    val updatedAtString = jsonObject.getString("updatedAt")
                    if (updatedAtString.isNotEmpty()) {
                        updatedAt = dateFormat.parse(updatedAtString)
                    }
                }

                completion(createdAt, updatedAt)
            } catch (e: Exception) {
                Janus.log("Error parsing consent metadata: $unescapedResult", level = LogLevel.ERROR, error = e)
                completion(null, null)
            }
        }
    }

    /**
     * Returns a precise timestamp without timezone information as a string
     * Takes an optional Date and returns formatted string or "nil" if date is nil
     */
    private fun formatDate(date: Date?): String {
        if (date == null) {
            return "nil"
        }

        val formatter = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS", Locale.US)
        return formatter.format(date)
    }
}