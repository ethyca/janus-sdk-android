package com.ethyca.janussdk.android.models

import com.google.gson.annotations.SerializedName

/**
 * Model representing a response from the IP location API
 */
data class IPLocationResponse(
    /**
     * Country code (e.g., "US")
     */
    val country: String? = null,
    
    /**
     * IP address with port
     */
    val ip: String? = null,
    
    /**
     * Location in ISO-3166-2 format (e.g., "US-CA")
     */
    val location: String? = null,
    
    /**
     * Region code (e.g., "CA")
     */
    val region: String? = null
) 