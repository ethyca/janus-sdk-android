package com.ethyca.janussdk.android.api

sealed class APIError : Exception() {
    object InvalidURL : APIError()
    data class NetworkError(val error: Throwable) : APIError()
    object InvalidResponse : APIError()
    data class DecodingError(val error: Throwable) : APIError()
    data class ServerError(val code: Int, val errorMessage: String) : APIError()
    object UnknownError : APIError()
    object NoData : APIError()
    data class BadResponse(val statusCode: Int) : APIError()

    override val message: String
        get() = when (this) {
            is InvalidURL -> "Invalid URL"
            is NetworkError -> "Network error: ${error.message}"
            is InvalidResponse -> "Invalid response from server"
            is DecodingError -> "Failed to decode response: ${error.message}"
            is ServerError -> "Server error $code: $errorMessage"
            is UnknownError -> "Unknown error occurred"
            is NoData -> "No data received from server"
            is BadResponse -> "Bad response status code: $statusCode"
        }
} 