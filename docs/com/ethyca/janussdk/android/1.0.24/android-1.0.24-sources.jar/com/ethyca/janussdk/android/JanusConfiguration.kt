package com.ethyca.janussdk.android

import com.ethyca.janussdk.android.models.ConsentFlagType
import com.ethyca.janussdk.android.models.ConsentNonApplicableFlagMode

@DslMarker
annotation class JanusDsl

/**
 * Immutable configuration object for the Janus SDK
 */
data class JanusConfiguration(
    var apiHost: String,
    var privacyCenterHost: String = "",
    var propertyId: String = "",
    var region: String = "",
    val ipLocation: Boolean = true,
    val fidesEvents: Boolean = true,
    val autoShowExperience: Boolean = true,
    val saveUserPreferencesToFides: Boolean = true,
    val saveNoticesServedToFides: Boolean = true,
    val consentFlagType: ConsentFlagType = ConsentFlagType.BOOLEAN,
    val consentNonApplicableFlagMode: ConsentNonApplicableFlagMode = ConsentNonApplicableFlagMode.OMIT
) {
    init {
        apiHost = normalizeAPIHost(apiHost)
        privacyCenterHost = normalizeAPIHost(privacyCenterHost)
    }
    
    /**
     * Java-style Builder
     */
    class Builder {
        private var apiHost: String = ""
        private var privacyCenterHost: String = ""
        private var propertyId: String = ""
        private var region: String = ""
        private var ipLocation: Boolean = true
        private var fidesEvents: Boolean = true
        private var autoShowExperience: Boolean = true
        private var saveUserPreferencesToFides: Boolean = true
        private var saveNoticesServedToFides: Boolean = true
        private var consentFlagType: ConsentFlagType = ConsentFlagType.BOOLEAN
        private var consentNonApplicableFlagMode: ConsentNonApplicableFlagMode = ConsentNonApplicableFlagMode.OMIT

        fun apiHost(apiHost: String) = apply { this.apiHost = normalizeAPIHost(apiHost) }
        fun privacyCenterHost(privacyCenterHost: String) = apply { this.privacyCenterHost = normalizeAPIHost(privacyCenterHost) }
        fun propertyId(propertyId: String) = apply { this.propertyId = propertyId }
        fun region(region: String) = apply { this.region = region }
        fun ipLocation(ipLocation: Boolean) = apply { this.ipLocation = ipLocation }
        fun fidesEvents(fidesEvents: Boolean) = apply { this.fidesEvents = fidesEvents }
        fun autoShowExperience(autoShowExperience: Boolean) = apply { this.autoShowExperience = autoShowExperience }
        fun saveUserPreferencesToFides(saveUserPreferencesToFides: Boolean) = apply { this.saveUserPreferencesToFides = saveUserPreferencesToFides }
        fun saveNoticesServedToFides(saveNoticesServedToFides: Boolean) = apply { this.saveNoticesServedToFides = saveNoticesServedToFides }
        fun consentFlagType(consentFlagType: ConsentFlagType) = apply { this.consentFlagType = consentFlagType }
        fun consentNonApplicableFlagMode(consentNonApplicableFlagMode: ConsentNonApplicableFlagMode) = apply { this.consentNonApplicableFlagMode = consentNonApplicableFlagMode }

        fun build(): JanusConfiguration {
            return JanusConfiguration(
                apiHost = JanusConfiguration.normalizeAPIHost(apiHost),
                privacyCenterHost = JanusConfiguration.normalizeAPIHost(privacyCenterHost),
                propertyId = propertyId,
                region = region,
                ipLocation = ipLocation,
                fidesEvents = fidesEvents,
                autoShowExperience = autoShowExperience,
                saveUserPreferencesToFides = saveUserPreferencesToFides,
                saveNoticesServedToFides = saveNoticesServedToFides,
                consentFlagType = consentFlagType,
                consentNonApplicableFlagMode = consentNonApplicableFlagMode
            )
        }
    }

    companion object {
        /**
         * Normalize API host by removing trailing slashes
         */
        @JvmStatic
        internal fun normalizeAPIHost(host: String): String {
            var normalizedHost = host
            while (normalizedHost.endsWith("/")) {
                normalizedHost = normalizedHost.substring(0, normalizedHost.length - 1)
            }
            return normalizedHost
        }
        
        /**
         * Kotlin-style DSL entry point
         */
        @JvmStatic
        operator fun invoke(block: JanusConfigurationBuilder.() -> Unit): JanusConfiguration {
            val builder = JanusConfigurationBuilder()
            builder.block()
            return builder.build()
        }
    }
}

/**
 * Kotlin-style builder for JanusConfiguration DSL
 */
@JanusDsl
class JanusConfigurationBuilder {
    var apiHost: String = ""
    var privacyCenterHost: String = ""
    var propertyId: String = ""
    var region: String = ""
    var ipLocation: Boolean = true
    var fidesEvents: Boolean = true
    var autoShowExperience: Boolean = true
    var saveUserPreferencesToFides: Boolean = true
    var saveNoticesServedToFides: Boolean = true
    var consentFlagType: ConsentFlagType = ConsentFlagType.BOOLEAN
    var consentNonApplicableFlagMode: ConsentNonApplicableFlagMode = ConsentNonApplicableFlagMode.OMIT

    fun build(): JanusConfiguration {
        return JanusConfiguration(
            apiHost = JanusConfiguration.normalizeAPIHost(apiHost),
            privacyCenterHost = JanusConfiguration.normalizeAPIHost(privacyCenterHost),
            propertyId = propertyId,
            region = region,
            ipLocation = ipLocation,
            fidesEvents = fidesEvents,
            autoShowExperience = autoShowExperience,
            saveUserPreferencesToFides = saveUserPreferencesToFides,
            saveNoticesServedToFides = saveNoticesServedToFides,
            consentFlagType = consentFlagType,
            consentNonApplicableFlagMode = consentNonApplicableFlagMode
        )
    }
}
