package com.ethyca.janussdk.android.ui.view

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import com.ethyca.janussdk.android.Janus
import com.ethyca.janussdk.android.LogLevel
import com.ethyca.janussdk.android.events.*
import com.ethyca.janussdk.android.R
import com.ethyca.janussdk.android.consent.ConsentManager
import com.ethyca.janussdk.android.models.ConsentMethod
import com.ethyca.janussdk.android.utils.UrlHelper
import com.ethyca.janussdk.android.webview.TCFWebViewJSBridge
import com.ethyca.janussdk.android.webview.WebViewManager

/**
 * Activity for displaying TCF privacy experiences in a WebView.
 * This is the Android equivalent of iOS's TCFWebViewController.
 */
class TCFWebViewActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "TCFWebViewActivity"

        // Intent extra keys
        private const val EXTRA_WEBVIEW_ID = "webview_id"

        /**
         * Creates an intent to launch the TCFWebViewActivity with a pre-loaded WebView.
         *
         * @param context The context to create the intent from
         * @param webViewId The ID reference to the WebView from WebViewManager
         * @return An Intent configured to launch TCFWebViewActivity
         */
        fun createIntent(
            context: Context,
            webViewId: String
        ): Intent {
            return Intent(context, TCFWebViewActivity::class.java).apply {
                putExtra(EXTRA_WEBVIEW_ID, webViewId)
            }
        }
    }

    // UI components
    private var webView: WebView? = null
    private var jsBridge: TCFWebViewJSBridge? = null

    // Dependencies
    private lateinit var consentManager: ConsentManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tcf_webview)

        // Extract webView from WebViewManager using ID reference
        val webViewId = intent.getStringExtra(EXTRA_WEBVIEW_ID)
        val managedWebView = webViewId?.let { WebViewManager.getWebView(it) }
        
        // Check all conditions for TCF WebView availability
        if (webViewId == null || managedWebView == null || managedWebView.bridge !is TCFWebViewJSBridge) {
            Janus.log(
                "Unable to initialize TCF WebView. Closing TCFWebViewActivity gracefully.",
                metadata = mapOf(
                    "webViewId" to (webViewId ?: "null"),
                    "webViewHash" to (managedWebView?.webView?.hashCode()?.toString() ?: "null"),
                    "tcfCapableBridge" to (managedWebView?.bridge?.let { it is TCFWebViewJSBridge }?.toString() ?: "null")
                ),
                level = LogLevel.ERROR
            )
            setResult(Activity.RESULT_CANCELED)
            finish()
            return
        }
        
        webView = managedWebView.webView
        jsBridge = managedWebView.bridge

        // Initialize consent manager for storing/retrieving consent
        consentManager = ConsentManager()

        // Setup the pre-loaded WebView
        setupWebView()
    }

    @SuppressLint("WebViewApiAvailability")
    private fun setupWebView() {
        val webView = this.webView ?: return
        val jsBridge = this.jsBridge ?: return
        
        // Add the pre-loaded WebView to container (already loaded and ready)
        val container = findViewById<FrameLayout>(R.id.tcf_webview_container)
        container.addView(webView, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))

        // Set up custom WebViewClient that handles links in the ewbview
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val originalWebViewClient = webView.webViewClient

            webView.webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    request?.url?.let {
                        UrlHelper.openInBrowser(this@TCFWebViewActivity, it)
                    }
                    return true
                }

                // preserves original onPageFinished handler
                override fun onPageFinished(view: WebView?, url: String?) {
                    originalWebViewClient.onPageFinished(view, url)
                }
            }
        } else {
            // older API versions wont preserve the onPageFinished behavior of our webview - that is ok
            // because the onPageFinished would have fired at this point since the activity is not created
            // until after the current the webview has been fully loaded by TCFWebViewHelper
            webView.webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    request?.url?.let {
                        UrlHelper.openInBrowser(this@TCFWebViewActivity, it)
                    }
                    return true
                }
            }
        }

        // Set up the onModalHiding callback (hide UI immediately)
        jsBridge.onModalHiding = {
            handleModalHiding()
        }
        
        // Set up the onModalHide callback (close completely)
        jsBridge.onModalHide = {
            handleModalHide()
        }
    }

    /**
     * Handles hiding the UI immediately when consent starts updating
     */
    private fun handleModalHiding() {
        val webView = this.webView ?: return
        
        // Hide the WebView immediately to prevent user interactions during update
        // The WebView remains in the view hierarchy to complete network operations
        webView.visibility = android.view.View.GONE
        
        Janus.log("TCF WebView hidden, consent update in progress", level = LogLevel.DEBUG)
    }
    
    /**
     * Handles the completion of the TCF flow when the modal is closed
     */
    private fun handleModalHide() {
        val jsBridge = this.jsBridge ?: return
        val webView = this.webView ?: return
        
        // When the modal is completed, get the TCF consent selections from JavaScript
        jsBridge.getConsentValuesFromJS { consentValues, fidesString, consentMethod ->
            Janus.log("Received TCF consent from WebView", metadata = mapOf(
                "consentMethod" to consentMethod,
                "consentMap" to consentValues.toString(),
                "fidesString" to fidesString
            ), level = LogLevel.DEBUG)
            
            if (consentValues.isNotEmpty() || fidesString.isNotEmpty()) {
                // Trigger ExperienceSelectionUpdatingEvent before saving
                val updatingEvent = ExperienceSelectionUpdatingEvent(_consentIntended = consentValues)
                Janus.notifyEventListeners(updatingEvent)

                // Apply consent changes
                consentManager.setConsent(
                    values = consentValues,
                    versionHash = Janus.currentExperience?.meta?.versionHash ?: "",
                    fidesString = fidesString,
                    consentMethod = ConsentMethod.fromString(consentMethod)
                )

                // Update WebViews with the appropriate consentMethod
                // Use the external consent format (transformed) for WebView synchronization
                WebViewManager.propagateConsentToOtherWebViews(
                    consentValues = Janus.consent,
                    sourceWebView = webView,
                    consentMethod = consentMethod
                )

                // Trigger ExperienceSelectionUpdatedEvent after saving
                val updatedEvent = ExperienceSelectionUpdatedEvent()
                Janus.notifyEventListeners(updatedEvent)
            }

            // Generate and fire the appropriate event when the view is hidden
            val completedEvent = ExperienceClosedEvent("tcf_closed")
            Janus.notifyEventListeners(completedEvent)

            // Finish the activity
            runOnUiThread {
                setResult(Activity.RESULT_OK)
                finish()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        
        // Release the WebView (this will handle removal from collection)
        webView?.let { Janus.releaseConsentWebView(it) }
    }
}
