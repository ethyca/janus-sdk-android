package com.ethyca.janussdk.android

import android.util.Log
import com.google.gson.Gson
import com.google.gson.GsonBuilder

/**
 * Log levels for Janus SDK logging
 */
enum class LogLevel {
    VERBOSE, DEBUG, INFO, WARNING, ERROR
}

/**
 * Interface for Janus SDK logging.
 * Implement this interface to provide custom logging behavior.
 */
interface JanusLogger {
    /**
     * Log a message with optional level, metadata, and error
     *
     * @param message The message to log
     * @param level The log level (defaults to INFO)
     * @param metadata Optional metadata map to include with the log
     * @param error Optional exception for error-specific logging
     */
    fun log(message: String, level: LogLevel = LogLevel.INFO, metadata: Map<String, String>? = null, error: Throwable? = null)
}

/**
 * Default implementation of JanusLogger that logs to Android's Log system
 */
class DefaultJanusLogger : JanusLogger {
    
    private companion object {
        const val TAG = "JanusSDK"
    }
    
    private val gson = GsonBuilder()
        .setPrettyPrinting()
        .create()
    
    override fun log(message: String, level: LogLevel, metadata: Map<String, String>?, error: Throwable?) {
        try {
            var logMessage = message
            
            if (metadata != null) {
                val formattedMetadata = formatMetadata(metadata)
                logMessage += " | Metadata: $formattedMetadata"
            }
            
            if (error != null) {
                logMessage += " | Error: ${error.message ?: error.javaClass.simpleName}"
            }
            
            when (level) {
                LogLevel.VERBOSE -> Log.v(TAG, logMessage)
                LogLevel.DEBUG -> Log.d(TAG, logMessage)
                LogLevel.INFO -> Log.i(TAG, logMessage)
                LogLevel.WARNING -> Log.w(TAG, logMessage)
                LogLevel.ERROR -> Log.e(TAG, logMessage)
            }
        } catch (e: Exception) {
            // Fallback to System.out if Android Log fails
            try {
                val fallbackMessage = "[$TAG] LOGGING ERROR (${e.javaClass.simpleName}: ${e.message}) - Original: $message"
                System.out.println(fallbackMessage)
                if (metadata != null) {
                    System.out.println("[$TAG] Original metadata: $metadata")
                }
            } catch (fallbackError: Exception) {
                // Ultimate fallback - just try to print something
                try {
                    System.err.println("[$TAG] CRITICAL LOGGING FAILURE: ${fallbackError.javaClass.simpleName}")
                } catch (ignored: Exception) {
                    // Give up silently if even System.err fails
                }
            }
        }
    }
    
    /**
     * Safely formats metadata for logging with JSON pretty printing support
     * @param metadata The metadata map to format
     * @return A formatted string representation
     */
    private fun formatMetadata(metadata: Map<String, String>): String {
        return try {
            // Try to format as pretty JSON
            gson.toJson(metadata)
        } catch (e: Exception) {
            try {
                // Fallback to safe string conversion
                metadata.toString()
            } catch (e: Exception) {
                // Ultimate fallback if toString() fails
                "<Metadata map with ${metadata.size} entries>"
            }
        }
    }
} 