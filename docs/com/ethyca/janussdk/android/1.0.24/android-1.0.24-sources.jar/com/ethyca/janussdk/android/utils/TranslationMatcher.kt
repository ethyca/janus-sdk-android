package com.ethyca.janussdk.android.utils

import com.ethyca.janussdk.android.Janus
import com.ethyca.janussdk.android.LogLevel
import java.util.Locale

/**
 * Interface that represents a translatable item with a language identifier
 */
interface TranslationInterface {
    /**
     * The language code (e.g. "en", "fr", "de")
     */
    val language: String?
}

/**
 * Interface that represents a translatable item with a default indicator
 */
interface TranslationWithDefaultInterface : TranslationInterface {
    val isDefault: Boolean?
}

/**
 * Helper class for finding the most appropriate translation based on device language
 */
class TranslationMatcher {
    companion object {
        /**
         * Find the preferred locale string based on device language and available locales
         * @param availableLocales List of available locale strings
         * @return The preferred locale string, or the first device locale if no match found
         */
        fun preferredLocale(availableLocales: List<String>?): String {
            Janus.log("Finding translation: preferredLocale called with availableLocales: $availableLocales", level = LogLevel.VERBOSE)
            
            // Get device locales for fallback
            val deviceLocales = getDeviceLocales()
            Janus.log("Finding translation: device locales in priority order: $deviceLocales", level = LogLevel.VERBOSE)

            // If availableLocales is null or empty, fall back to first device locale
            if (availableLocales.isNullOrEmpty()) {
                val fallback = deviceLocales.firstOrNull() ?: "en"
                Janus.log("Finding translation: no available locales provided, using device fallback: '$fallback'", level = LogLevel.VERBOSE)
                return fallback
            }

            // Convert the list of strings to a list of objects that implement TranslationInterface
            val translations = availableLocales.map { locale ->
                object : TranslationInterface {
                    override val language: String = locale
                }
            }

            // Try to find a matching translation
            val matchingTranslation = findMatchingTranslation(translations)
            matchingTranslation?.language?.let { language ->
                if (!language.isNullOrEmpty()) {
                    Janus.log("Finding translation: found matching translation with language: '$language'", level = LogLevel.VERBOSE)
                    return language
                }
            }

            // If no match found, fall back to first device locale
            val fallback = deviceLocales.firstOrNull() ?: "en"
            Janus.log("Finding translation: no matching translation found, using device fallback: '$fallback'", level = LogLevel.VERBOSE)
            return fallback
        }

        /**
         * Find the best matching translation from a collection based on device language
         * @param translations Collection of translations conforming to TranslationInterface
         * @return The best matching translation, or null if no translations available
         */
        fun <T : TranslationInterface> find(translations: List<T>?): T? {
            Janus.log("Finding translation: find called with ${translations?.size ?: 0} translations", level = LogLevel.VERBOSE)
            
            // Return null if translations list is null or empty
            if (translations.isNullOrEmpty()) {
                Janus.log("Finding translation: no translations available, returning null", level = LogLevel.VERBOSE)
                return null
            }

            // First try to find an exact match based on device language
            val matchingTranslation = findMatchingTranslation(translations)
            if (matchingTranslation != null) {
                Janus.log("Finding translation: found device language match with language: '${matchingTranslation.language}'", level = LogLevel.VERBOSE)
                return matchingTranslation
            }

            // Then try to find a translation marked as default if the type supports it
            val defaultTranslation = translations.firstOrNull { translation ->
                // Check if the translation has an isDefault property that is true
                (translation as? TranslationWithDefaultInterface)?.isDefault == true
            }
            if (defaultTranslation != null) {
                Janus.log("Finding translation: found default translation with language: '${defaultTranslation.language}'", level = LogLevel.VERBOSE)
                return defaultTranslation
            }

            // Fallback to English if available
            val englishTranslation = translations.firstOrNull {
                it.language?.lowercase() == "en"
            }
            if (englishTranslation != null) {
                Janus.log("Finding translation: found English fallback translation", level = LogLevel.VERBOSE)
                return englishTranslation
            }

            // Last resort: return the first translation
            val firstTranslation = translations.firstOrNull()
            if (firstTranslation != null) {
                Janus.log("Finding translation: using first available translation with language: '${firstTranslation.language}'", level = LogLevel.VERBOSE)
            } else {
                Janus.log("Finding translation: no translations found, returning null", level = LogLevel.VERBOSE)
            }
            return firstTranslation
        }

        /**
         * Get a list of device locales in priority order
         * @return Array of locale codes
         */
        private fun getDeviceLocales(): List<String> {
            val deviceLocales = mutableListOf<String>()

            for (locale in Locale.getDefault().toLanguageTag().split(",")) {
                val parts = locale.split("-")

                when (parts.size) {
                    3 -> {
                        // language-script-region
                        val (language, script, region) = parts
                        deviceLocales.add("$language-$script-$region".lowercase())
                        deviceLocales.add("$language-$script".lowercase())
                        deviceLocales.add(language.lowercase())
                    }
                    2 -> {
                        // language-script OR language-region
                        val (language, scriptOrRegion) = parts
                        deviceLocales.add("$language-$scriptOrRegion".lowercase())
                        deviceLocales.add(language.lowercase())
                    }
                    1 -> {
                        // just language
                        deviceLocales.add(parts[0].lowercase())
                    }
                }
            }

            return deviceLocales
        }

        /**
         * Find a translation that matches one of the device locales
         * @param translations Collection of translations to search
         * @param deviceLocales List of device locales in priority order (defaults to current device locales)
         * @return The matching translation, or null if no match found
         */
        private fun <T : TranslationInterface> findMatchingTranslation(
            translations: List<T>,
            deviceLocales: List<String> = getDeviceLocales()
        ): T? {
            val validTranslations = translations.filter { !it.language.isNullOrEmpty() }

            // Iterate through deviceLocales in priority order, but apply each one across all translations
            for (deviceLocale in deviceLocales) {
                // 1. Exact match
                val exactMatch = validTranslations.firstOrNull {
                    it.language?.equals(deviceLocale, ignoreCase = true) == true
                }
                if (exactMatch != null) {
                    return exactMatch
                }

                // 2. Special base-language fallback with safe script substitution
                if (!deviceLocale.contains("-")) {
                    // Serbian (sr) ✅  Cyrl ⇆ Latn okay
                    // Uzbek (uz)   ✅  Cyrl ⇆ Latn okay
                    // Azeri (az)   ✅  Some caution but fine
                    // Kazakh (kk)  ✅  Cyrl ⇆ Latn fine
                    // Chinese (zh) 🚫  Don't fallback across Hans/Hant
                    // Punjabi (pa) 🚫  Scripts = Different audiences
                    // Kurdish (ku) 🚫  Scripts = Political difference
                    when (deviceLocale.lowercase()) {
                        "sr", "uz", "az", "kk" -> {
                            // Safe fallback between scripts
                            val scriptFallback = validTranslations.firstOrNull {
                                val parts = it.language?.split("-") ?: emptyList()
                                parts.size >= 2 && parts[1].length == 4 && parts[0].equals(deviceLocale, ignoreCase = true)
                            }
                            if (scriptFallback != null) {
                                return scriptFallback
                            }
                        }
                    }

                    // 3. Generic base language match (e.g. "es" should match "es-MX" or "es-ES" if allowed)
                    val regionFallback = validTranslations.firstOrNull {
                            val parts = it.language?.split("-") ?: emptyList()
                            parts.size == 2 && parts[1].length != 4 && parts[0].equals(deviceLocale, ignoreCase = true) 
                    }
                    if (regionFallback != null) {
                        return regionFallback
                    }
                }
            }

            return null
        }
    }
}