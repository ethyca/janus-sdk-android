package com.ethyca.janussdk.android.models

import com.google.gson.annotations.SerializedName
import java.util.Date

/**
 * Response from the privacy experience API endpoint
 */
data class PrivacyExperienceResponseDTO(
    val items: List<PrivacyExperienceItemDTO>? = null,
    val total: Int? = null,
    val page: Int? = null,
    val size: Int? = null,
    val pages: Int? = null
)

/**
 * An individual privacy experience configuration item
 */
data class PrivacyExperienceItemDTO(
    val id: String? = null,
    @SerializedName("created_at") val createdAt: Date? = null,
    @SerializedName("updated_at") val updatedAt: Date? = null,
    val region: String? = null,
    @SerializedName("gpp_settings") val gppSettings: GPPSettingsDTO? = null,
    @SerializedName("privacy_notices") val privacyNotices: List<PrivacyNoticeDTO>? = null,
    @SerializedName("non_applicable_privacy_notices") val nonApplicablePrivacyNotices: List<String>? = null,
    @SerializedName("experience_config") val experienceConfig: ExperienceConfigDTO? = null,
    @SerializedName("available_locales") val availableLocales: List<String>? = null,
    val meta: PrivacyMetaDTO? = null,
    @SerializedName("tcf_system_legitimate_interests") val tcfSystemLegitimateInterests: List<TCFSystemDTO>? = null,
    @SerializedName("tcf_special_features") val tcfSpecialFeatures: List<TCFSpecialFeatureDTO>? = null,
    @SerializedName("tcf_vendor_legitimate_interests") val tcfVendorLegitimateInterests: List<TCFVendorLegitimateInterestDTO>? = null,
    @SerializedName("tcf_vendor_relationships") val tcfVendorRelationships: List<TCFVendorRelationshipDTO>? = null,
    @SerializedName("gvl_translations") val gvlTranslations: Map<String, GVLTranslationDTO>? = null,
    @SerializedName("tcf_purpose_consents") val tcfPurposeConsents: List<TCFPurposeItemDTO>? = null,
    @SerializedName("tcf_vendor_consents") val tcfVendorConsents: List<TCFVendorDTO>? = null,
    @SerializedName("tcf_purpose_legitimate_interests") val tcfPurposeLegitimateInterests: List<TCFPurposeItemDTO>? = null,
    @SerializedName("tcf_system_relationships") val tcfSystemRelationships: List<TCFSystemRelationshipDTO>? = null,
    @SerializedName("tcf_special_purposes") val tcfSpecialPurposes: List<TCFSpecialPurposeDTO>? = null,
    val gvl: Map<String, String>? = null,
    @SerializedName("tcf_publisher_country_code") val tcfPublisherCountryCode: String? = null,

    // Minimal TCF specific fields
    @SerializedName("minimal_tcf") val minimalTcf: Boolean? = null,
    @SerializedName("vendor_count") val vendorCount: Int? = null,
    @SerializedName("tcf_vendor_consent_ids") val tcfVendorConsentIds: List<String>? = null,
    @SerializedName("tcf_vendor_legitimate_interest_ids") val tcfVendorLegitimateInterestIds: List<String>? = null,
    @SerializedName("tcf_purpose_consent_ids") val tcfPurposeConsentIds: List<Int>? = null,
    @SerializedName("tcf_purpose_legitimate_interest_ids") val tcfPurposeLegitimateInterestIds: List<Int>? = null,
    @SerializedName("tcf_special_feature_ids") val tcfSpecialFeatureIds: List<Int>? = null,
    @SerializedName("tcf_special_purpose_ids") val tcfSpecialPurposeIds: List<Int>? = null,
    @SerializedName("tcf_feature_ids") val tcfFeatureIds: List<Int>? = null,
    @SerializedName("tcf_system_consent_ids") val tcfSystemConsentIds: List<String>? = null,
    @SerializedName("tcf_system_legitimate_interest_ids") val tcfSystemLegitimateInterestIds: List<String>? = null,
    @SerializedName("tcf_purpose_names") val tcfPurposeNames: List<String>? = null,
    @SerializedName("tcf_special_feature_names") val tcfSpecialFeatureNames: List<String>? = null
) {
    // Computed property to get all notices (including children) in a flat list
    val allNotices: List<PrivacyNoticeDTO>
        get() {
            val notices = mutableListOf<PrivacyNoticeDTO>()
            privacyNotices?.let { notices.addAll(it) }
            privacyNotices?.forEach { notice ->
                notice.children?.let { children ->
                    notices.addAll(children.flatMap { it.allNotices })
                }
            }
            return notices
        }
}

/**
 * Represents the GVL translations for a specific language
 */
data class GVLTranslationDTO(
    @SerializedName("gvl_specification_version") val gvlSpecificationVersion: Int? = null,
    @SerializedName("vendor_list_version") val vendorListVersion: Int? = null,
    @SerializedName("tcf_policy_version") val tcfPolicyVersion: Int? = null,
    @SerializedName("last_updated") val lastUpdated: String? = null,
    val purposes: Map<String, GVLPurposeDTO>? = null
)

/**
 * Represents a GVL Purpose
 */
data class GVLPurposeDTO(
    val id: Int? = null,
    val name: String? = null,
    val description: String? = null,
    val illustrations: List<String>? = null
)

/**
 * Represents a TCF Purpose Item used in purpose consents and legitimate interests
 */
data class TCFPurposeItemDTO(
    val id: Int? = null,
    val name: String? = null,
    val description: String? = null,
    val illustrations: List<String>? = null,
    @SerializedName("data_uses") val dataUses: List<String>? = null,
    @SerializedName("default_preference") val defaultPreference: String? = null,
    val vendors: List<TCFVendorDTO>? = null,
    val systems: List<TCFSystemDTO>? = null
)

/**
 * Represents a TCF Vendor Legitimate Interest object
 */
data class TCFVendorLegitimateInterestDTO(
    val id: String? = null,
    @SerializedName("has_vendor_id") val hasVendorId: Boolean? = null,
    val name: String? = null,
    val description: String? = null,
    @SerializedName("vendor_deleted_date") val vendorDeletedDate: String? = null,
    @SerializedName("default_preference") val defaultPreference: String? = null,
    @SerializedName("purpose_legitimate_interests") val purposeLegitimateInterests: List<PurposeLegitimateInterestDTO>? = null
)

/**
 * Represents a Purpose Legitimate Interest within a TCF Vendor
 */
data class PurposeLegitimateInterestDTO(
    val id: Int? = null,
    val name: String? = null,
    @SerializedName("retention_period") val retentionPeriod: String? = null
)

/**
 * Represents a TCF Special Feature object seen in some API responses
 */
data class TCFSpecialFeatureDTO(
    val id: Int? = null,
    val name: String? = null,
    val description: String? = null,
    @SerializedName("default_preference") val defaultPreference: String? = null,
    val vendors: List<TCFVendorDTO>? = null,
    val systems: List<TCFSystemDTO>? = null
)

/**
 * Represents a TCF Vendor object
 */
data class TCFVendorDTO(
    val id: String? = null,
    val name: String? = null
)

/**
 * Represents a TCF System object
 * This is an empty class that can be expanded as needed based on actual API responses.
 * Regular class is used instead of data class to allow for an empty implementation.
 */
class TCFSystemDTO {
    // Empty class that will be expanded when we know more about the implementation

    // Override equals and hashCode for proper collection handling
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        return true
    }

    override fun hashCode(): Int {
        return javaClass.hashCode()
    }
}

/**
 * Global Privacy Platform settings
 */
data class GPPSettingsDTO(
    @SerializedName("us_approach") val usApproach: String? = null,
    @SerializedName("mspa_service_provider_mode") val mspaServiceProviderMode: Boolean? = null,
    @SerializedName("mspa_opt_out_option_mode") val mspaOptOutOptionMode: Boolean? = null,
    @SerializedName("mspa_covered_transactions") val mspaCoveredTransactions: Boolean? = null,
    @SerializedName("enable_tcfeu_string") val enableTcfeuString: Boolean? = null,
    val enabled: Boolean? = null
)

/**
 * Represents the GPP field mapping structure
 */
data class GPPFieldMappingDTO(
    val region: String? = null,
    val mechanism: List<GPPMechanismDTO>? = null,
    val notice: List<String>? = null
) {
    // Computed property to get all mechanisms
    val allMechanisms: List<GPPMechanismDTO>
        get() = mechanism ?: emptyList()
}

/**
 * Represents a GPP mechanism mapping
 */
data class GPPMechanismDTO(
    @SerializedName("opt_out") val optOut: String? = null,
    @SerializedName("not_available") val notAvailable: String? = null,
    @SerializedName("not_opt_out") val notOptOut: String? = null,
    val field: String? = null
)

/**
 * Privacy notice definition
 */
data class PrivacyNoticeDTO(
    val name: String? = null,
    @SerializedName("notice_key") val noticeKey: String? = null,
    @SerializedName("internal_description") val internalDescription: String? = null,
    @SerializedName("consent_mechanism") val consentMechanism: String? = null,
    @SerializedName("data_uses") val dataUses: List<String>? = null,
    @SerializedName("enforcement_level") val enforcementLevel: String? = null,
    val disabled: Boolean? = null,
    @SerializedName("has_gpc_flag") val hasGpcFlag: Boolean? = null,
    val framework: String? = null,
    @SerializedName("default_preference") val defaultPreference: String? = null,
    val id: String? = null,
    val origin: String? = null,
    @SerializedName("created_at") val createdAt: Date? = null,
    @SerializedName("updated_at") val updatedAt: Date? = null,
    val cookies: List<CookieDTO>? = null,
    @SerializedName("systems_applicable") val systemsApplicable: Boolean? = null,
    val translations: List<PrivacyNoticeTranslationDTO>? = null,
    val children: List<PrivacyNoticeDTO>? = null,
    @SerializedName("gpp_field_mapping") val gppFieldMapping: List<GPPFieldMappingDTO>? = null
) {
    // Computed property to get all notices (including children) in a flat list
    val allNotices: List<PrivacyNoticeDTO>
        get() {
            val notices = mutableListOf(this)
            children?.let { childList ->
                notices.addAll(childList.flatMap { it.allNotices })
            }
            return notices
        }
}

/**
 * Cookie definition
 */
data class CookieDTO(
    val name: String? = null,
    val path: String? = null,
    val domain: String? = null
)

/**
 * Translation for a privacy notice
 */
data class PrivacyNoticeTranslationDTO(
    val language: String? = null,
    val title: String? = null,
    val description: String? = null,
    @SerializedName("privacy_notice_history_id") val privacyNoticeHistoryId: String? = null
)

/**
 * Configuration for the privacy experience UI
 */
data class ExperienceConfigDTO(
    val name: String? = null,
    val disabled: Boolean? = null,
    val dismissable: Boolean? = null,
    @SerializedName("show_layer1_notices") val showLayer1Notices: Boolean? = null,
    @SerializedName("layer1_button_options") val layer1ButtonOptions: String? = null,
    @SerializedName("allow_language_selection") val allowLanguageSelection: Boolean? = null,
    @SerializedName("auto_detect_language") val autoDetectLanguage: Boolean? = null,
    @SerializedName("auto_subdomain_cookie_deletion") val autoSubdomainCookieDeletion: Boolean? = null,
    val regions: List<String>? = null,
    val id: String? = null,
    @SerializedName("created_at") val createdAt: Date? = null,
    @SerializedName("updated_at") val updatedAt: Date? = null,
    val component: String? = null,
    val translations: List<ExperienceConfigTranslationDTO>? = null,
    val properties: List<PropertyInfoDTO>? = null
)

/**
 * Translation for the experience configuration
 */
data class ExperienceConfigTranslationDTO(
    val language: String? = null,
    @SerializedName("accept_button_label") val acceptButtonLabel: String? = null,
    @SerializedName("acknowledge_button_label") val acknowledgeButtonLabel: String? = null,
    @SerializedName("banner_title") val bannerTitle: String? = null,
    @SerializedName("is_default") val isDefault: Boolean? = null,
    @SerializedName("modal_link_label") val modalLinkLabel: String? = null,
    @SerializedName("privacy_policy_link_label") val privacyPolicyLinkLabel: String? = null,
    @SerializedName("privacy_policy_url") val privacyPolicyUrl: String? = null,
    @SerializedName("privacy_preferences_link_label") val privacyPreferencesLinkLabel: String? = null,
    @SerializedName("purpose_header") val purposeHeader: String? = null,
    @SerializedName("reject_button_label") val rejectButtonLabel: String? = null,
    @SerializedName("save_button_label") val saveButtonLabel: String? = null,
    val title: String? = null,
    @SerializedName("banner_description") val bannerDescription: String? = null,
    val description: String? = null,
    @SerializedName("privacy_experience_config_history_id") val privacyExperienceConfigHistoryId: String? = null
)

/**
 * Metadata for the privacy experience
 */
data class PrivacyMetaDTO(
    @SerializedName("version_hash") val versionHash: String? = null,
    @SerializedName("accept_all_fides_string") val acceptAllFidesString: String? = null,
    @SerializedName("accept_all_fides_mobile_data") val acceptAllFidesMobileData: FidesMobileData? = null,
    @SerializedName("reject_all_fides_string") val rejectAllFidesString: String? = null,
    @SerializedName("reject_all_fides_mobile_data") val rejectAllFidesMobileData: FidesMobileData? = null
)

/**
 * Property information
 */
data class PropertyInfoDTO(
    val id: String? = null,
    val name: String? = null
)

/**
 * Represents a TCF Vendor Relationship
 */
data class TCFVendorRelationshipDTO(
    val id: String? = null,
    val name: String? = null
    // Additional fields can be added as needed
)

/**
 * Represents a TCF System Relationship
 */
data class TCFSystemRelationshipDTO(
    val id: String? = null,
    val name: String? = null
    // Additional fields can be added as needed
)

/**
 * Represents a TCF Special Purpose
 */
data class TCFSpecialPurposeDTO(
    val id: Int? = null,
    val name: String? = null,
    val description: String? = null
)
