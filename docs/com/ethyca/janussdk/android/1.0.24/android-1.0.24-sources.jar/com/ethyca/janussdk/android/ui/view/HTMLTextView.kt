package com.ethyca.janussdk.android.ui.view

import android.content.Context
import android.text.method.LinkMovementMethod
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatTextView

/**
 * A specialized TextView that can render HTML content with proper handling
 * of links and formatting.
 */
class HTMLTextView : AppCompatTextView {
    
    // Indicates whether content has HTML tags that need special handling
    private var hasHtmlContent = false
    
    constructor(context: Context) : super(context) {
        init()
    }
    
    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
        init()
    }
    
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        init()
    }
    
    private fun init() {
        // Default setup - will be configured further when content is set
        isClickable = true
        isFocusable = true
        linksClickable = true
    }
    
    /**
     * Sets HTML content to the text view, with sanitization and proper rendering
     * @param htmlContent The raw HTML content
     * @param vendorCount Optional vendor count to replace placeholder
     */
    fun setHtmlContent(htmlContent: String, vendorCount: Int? = null) {
        // If the content contains vendor count placeholder and we have a vendor count,
        // replace it first
        val processedContent = HTMLSanitizer.processWithVendorCount(htmlContent, vendorCount)
        
        // Apply the HTML content - this handles sanitization
        HTMLSanitizer.apply(this, processedContent)
        
        // Check if the text contains HTML and enable link movement if necessary
        hasHtmlContent = HTMLSanitizer.containsHtml(processedContent)
        if (hasHtmlContent) {
            // Enable link handling
            movementMethod = LinkMovementMethod.getInstance()
        }
    }
    
    /**
     * Returns whether the current content contains HTML tags
     */
    fun hasHtmlContent(): Boolean {
        return hasHtmlContent
    }
    
    override fun setText(text: CharSequence?, type: BufferType?) {
        super.setText(text, type)
        
        // Reset HTML content flag when text is set directly
        if (text is String) {
            hasHtmlContent = HTMLSanitizer.containsHtml(text)
        }
    }
} 