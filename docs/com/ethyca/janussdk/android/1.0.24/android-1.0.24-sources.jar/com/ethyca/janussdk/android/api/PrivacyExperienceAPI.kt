package com.ethyca.janussdk.android.api

import com.ethyca.janussdk.android.models.DetailOnlyResponse
import com.ethyca.janussdk.android.models.PrivacyExperienceMapper
import com.ethyca.janussdk.android.models.PrivacyExperienceResponse
import com.ethyca.janussdk.android.models.PrivacyExperienceResponseDTO
import com.ethyca.janussdk.android.Janus
import com.ethyca.janussdk.android.LogLevel
import com.ethyca.janussdk.android.utils.ApiRoutes
import com.google.gson.Gson
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executors

/**
 * API client for fetching privacy experience data
 */
open class PrivacyExperienceAPI
/**
 * Initialize with a custom API endpoint
 * @param apiHost The base URL for the API
 */(
    /**
     * Base URL for API requests
     */
    private val apiHost: String
) {

    /**
     * URL session used for network requests
     */
    private val executorService = Executors.newCachedThreadPool()

    /**
     * Creates connection to URL
     * @param url The URL to connect to
     * @return HttpURLConnection
     */
    protected open fun createConnection(url: URL): HttpURLConnection {
        return url.openConnection() as HttpURLConnection
    }

    /**
     * Fetch privacy experience for a specific region and optional property ID
     * @param region The region code (e.g. "US", "EU")
     * @param propertyId Optional Fides property ID
     * @param page The page number to fetch
     * @param size The number of items per page
     * @param minimalTcf Whether to request a minimal TCF response (faster loading)
     * @param completion Completion handler with result containing either PrivacyExperienceResponse or an error
     */
    fun fetchPrivacyExperiences(
        region: String,
        propertyId: String? = null,
        page: Int? = null,
        size: Int? = null,
        minimalTcf: Boolean? = false,
        completion: (Result<PrivacyExperienceResponse>) -> Unit
    ) {
        executorService.submit {
            try {
                // Create URL with query parameters
                val urlBuilder = StringBuilder("$apiHost${ApiRoutes.PRIVACY_EXPERIENCE.path}?")

                // Add required region parameter
                urlBuilder.append("region=").append(URLEncoder.encode(region, StandardCharsets.UTF_8.name()))

                // Add optional parameters if they exist
                if (!propertyId.isNullOrEmpty()) {
                    urlBuilder.append("&property_id=").append(URLEncoder.encode(propertyId, StandardCharsets.UTF_8.name()))
                }

                if (page != null) {
                    urlBuilder.append("&page=").append(page)
                }

                if (size != null) {
                    urlBuilder.append("&size=").append(size)
                }

                if (minimalTcf == true) {
                    urlBuilder.append("&minimal_tcf=true")
                }

                // parameters we always want to include
                urlBuilder.append("&include_meta=true")
                urlBuilder.append("&systems_applicable=true")
                urlBuilder.append("&show_disabled=false")
                urlBuilder.append("&has_notices=true")
                urlBuilder.append("&include_non_applicable_notices=true")

                // Create and configure the connection
                val url = URL(urlBuilder.toString())
                Janus.log("Opening privacy experience URL", level = LogLevel.DEBUG, metadata = mapOf("url" to url.toString()))

                val connection = createConnection(url)
                connection.requestMethod = "GET"
                connection.setRequestProperty("Accept", "application/json")
                connection.setRequestProperty("Fides-Client", "Janus-SDK")

                try {
                    // Execute request and handle response
                    val responseCode = connection.responseCode

                    // Handle HTTP error codes
                    if (responseCode < 200 || responseCode >= 300) {
                        val errorStream = connection.errorStream ?: connection.inputStream
                        val errorMessage = errorStream?.let {
                            BufferedReader(InputStreamReader(it)).use { reader ->
                                reader.readText()
                            }
                        } ?: "No error message"

                        // Try to parse as detail-only response even for error status codes
                        try {
                            val gson = Gson()
                            val detailResponse = gson.fromJson(errorMessage, DetailOnlyResponse::class.java)
                            if (detailResponse != null) {
                                Janus.log("Received error response from Privacy Experience API", level = LogLevel.INFO, metadata = mapOf(
                                    "statusCode" to responseCode.toString(),
                                    "detail" to detailResponse.detail
                                ))
                                
                                // Return an empty successful response instead of an error
                                val emptyResponse = PrivacyExperienceResponse(items = emptyList())
                                completion(Result.Success(emptyResponse))
                                return@submit
                            }
                        } catch (e: Exception) {
                            // Not a detail-only response, continue with normal error handling
                        }

                        val error = APIError.ServerError(responseCode, errorMessage)
                        Janus.log("Privacy Experience API Error", level = LogLevel.ERROR, error = error)
                        completion(Result.Failure(error))
                        return@submit
                    }

                    // Read the response
                    val inputStream = connection.inputStream
                    val response = BufferedReader(InputStreamReader(inputStream)).use { reader ->
                        reader.readText()
                    }

                    // Parse the JSON response to DTO then map to domain model
                    try {
                        // First parse to DTO
                        val privacyExperienceDTO = Gson().fromJson(response, PrivacyExperienceResponseDTO::class.java)

                        // Map to domain model
                        val privacyExperience = PrivacyExperienceMapper.mapResponseToDomain(privacyExperienceDTO)

                        // Return domain model to caller
                        completion(Result.Success(privacyExperience))
                    } catch (e: Exception) {
                        Janus.log("Privacy Experience API Decoding Error", level = LogLevel.ERROR, error = e)
                        completion(Result.Failure(APIError.DecodingError(e)))
                    }

                } catch (e: Exception) {
                    // Handle network errors
                    completion(Result.Failure(APIError.NetworkError(e)))
                } finally {
                    connection.disconnect()
                }

            } catch (e: Exception) {
                // Handle URL creation or other errors
                completion(Result.Failure(APIError.InvalidURL))
            }
        }
    }
}
