package com.ethyca.janussdk.android.webview

import android.webkit.JavascriptInterface
import com.ethyca.janussdk.android.Janus
import com.ethyca.janussdk.android.LogLevel
import com.google.gson.Gson
import com.google.gson.JsonSyntaxException
import com.google.gson.annotations.SerializedName

/**
 * Internal data structure for parsing log messages from JavaScript.
 */
data class JsLogPayload(
    @SerializedName("type") val type: String?,
    @SerializedName("message") val message: String?,
    @SerializedName("data") val data: Any? // Keep data flexible for parsing
)

/**
 * Receives log messages from JavaScript (via `window.JanusLogBridge.log`) 
 * and logs them using Android's Logcat.
 */
class JanusLogBridge {
    
    companion object {
        const val INTERFACE_NAME = "JanusLogBridge"
        private const val TAG = "JanusLogBridge" // Log tag for messages FROM JS
    }
    
    private val gson = Gson()
    
    /**
     * Method exposed to JavaScript.
     * Receives a JSON string representing the log entry.
     */
    @JavascriptInterface
    fun log(jsonPayload: String) {
        try {
            val payload = gson.fromJson(jsonPayload, JsLogPayload::class.java)
            val message = payload.message ?: "(No message)"
            val logType = payload.type?.lowercase() ?: "debug"
            
            // Convert data to Map<String, String>? if possible, otherwise pass null
            val metadata = convertToStringMap(payload.data)

            // Map the JS log level to Android Log levels
            when (logType) {
                "error" -> Janus.log("JS: $message", level = LogLevel.ERROR, metadata = metadata)
                "warn", "warning" -> Janus.log("JS: $message", level = LogLevel.WARNING, metadata = metadata)
                "info" -> Janus.log("JS: $message", level = LogLevel.INFO, metadata = metadata)
                else -> Janus.log("JS: $message", level = LogLevel.DEBUG, metadata = metadata) // Default to debug
            }
        } catch (e: JsonSyntaxException) {
            Janus.log("Failed to parse log JSON from JavaScript: $jsonPayload", level = LogLevel.ERROR, error = e)
        } catch (e: Exception) {
            Janus.log("Error processing log from JavaScript: $jsonPayload", level = LogLevel.ERROR, error = e)
        }
    }
    
    /**
     * Converts various data types to Map<String, String>? for consistency
     * Returns null if conversion is not straightforward
     */
    private fun convertToStringMap(data: Any?): Map<String, String>? {
        return when (data) {
            null -> null
            is Map<*, *> -> {
                // Try to convert to Map<String, String>
                try {
                    data.entries.associate { 
                        it.key.toString() to it.value.toString() 
                    }
                } catch (e: Exception) {
                    null
                }
            }
            else -> {
                // For non-map objects, create a simple entry
                mapOf("value" to data.toString(), "type" to data.javaClass.simpleName)
            }
        }
    }
} 