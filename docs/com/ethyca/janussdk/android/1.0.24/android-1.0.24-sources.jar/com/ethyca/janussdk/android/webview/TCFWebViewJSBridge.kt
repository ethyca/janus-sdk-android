package com.ethyca.janussdk.android.webview

import android.content.Context
import android.webkit.WebView
import com.ethyca.janussdk.android.webview.FidesJSBridge.Companion
import com.ethyca.janussdk.android.Janus
import com.ethyca.janussdk.android.LogLevel

/**
 * TCFWebViewJSBridge
 *
 * This class provides specialized JavaScript bridge functionality for TCF WebViews.
 * It handles TCF-specific messaging and event handling between Kotlin and JavaScript for Transparency
 * and Consent Framework (TCF) compliance experiences.
 *
 * Key responsibilities:
 * - Managing TCF-specific JavaScript interactions
 * - Handling modal state management
 * - Providing specialized message handling for the TCF experience
 * - Supporting the TCF web modal lifecycle (show, interaction, close)
 */
class TCFWebViewJSBridge() : FidesJSBridge() {
    
    companion object {
        private const val TAG = "TCFWebViewJSBridge"
    }
    
    // Callback interfaces - simplifies the communication flow
    var onModalReady: (() -> Unit)? = null
    var onModalHiding: (() -> Unit)? = null
    var onModalHide: (() -> Unit)? = null
    
    /**
     * Sets up the WebView with TCF-specific configurations
     * Adds the TCF-specific JavaScript
     *
     * @param webView The WebView to configure
     * @param autoSyncOnStart Whether to enable automatic synchronization (passed to super)
     */
    override fun setupWebView(webView: WebView, autoSyncOnStart: Boolean, includeTCFScript: Boolean) {
        // Call the parent class's setup first to establish base functionality
        super.setupWebView(webView, autoSyncOnStart, true)
    }
    
    /**
     * Overrides to prevent propagation of Janus events translated to Fides events
     * TCF WebViews should not receive events from other sources to avoid event loops and errors
     */
    override fun sendFidesEventToJS(eventType: String, data: Map<String, Any>) {
        // No-op implementation to block event propagation
        Janus.log("Blocking propagation of Fides event: $eventType", level = LogLevel.DEBUG)
    }
    
    /**
     * Process events from FidesJS, handling TCF-specific events
     * 
     * @param eventTypeString The event type string
     * @param data The event data
     */
    override fun processEventFromFidesJS(eventTypeString: String, data: Map<String, Any>, handler: WebViewEventHandler) {
        // Log all events received by TCF bridge for debugging
        Janus.log("TCFWebViewJSBridge received event: $eventTypeString", level = LogLevel.DEBUG)
        
        // Check if this event originated from JanusSDK (our own sync)
        // If so, ignore it to prevent auto-closing when we sync TO FidesJS
        val source = data["source"] as? String
        if (source == "JanusSDK") {
            Janus.log("TCFWebViewJSBridge ignoring event from JanusSDK: $eventTypeString", level = LogLevel.DEBUG)
            super.processEventFromFidesJS(eventTypeString, data, handler)
            return
        }
        
        // Handle TCF-specific events (only from user actions, not our syncs)
        when (eventTypeString) {
            "TCFWebViewReady" -> {
                Janus.log("TCF modal is ready", level = LogLevel.DEBUG)
                onModalReady?.invoke()
                return
            }
            
            "FidesUpdating" -> {
                Janus.log("TCF consent updating - hiding UI immediately", level = LogLevel.DEBUG)
                // Hide the UI immediately when consent starts updating
                onModalHiding?.invoke()
                // Let parent handle the event for consent processing
                super.processEventFromFidesJS(eventTypeString, data, handler)
                return
            }
            
            "FidesUpdated" -> {
                Janus.log("TCF consent updated - closing modal", level = LogLevel.DEBUG)
                // Close the modal completely after consent is saved
                onModalHide?.invoke()
                // Let parent handle the event for consent sync
                super.processEventFromFidesJS(eventTypeString, data, handler)
                return
            }
            
            else -> {
                // Pass other events to parent handler
                super.processEventFromFidesJS(eventTypeString, data, handler)
            }
        }
    }
} 