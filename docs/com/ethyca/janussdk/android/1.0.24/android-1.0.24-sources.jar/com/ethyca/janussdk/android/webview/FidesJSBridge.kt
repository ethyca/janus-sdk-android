package com.ethyca.janussdk.android.webview

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.ethyca.janussdk.android.*
import com.ethyca.janussdk.android.core.JanusProvider
import com.google.gson.Gson
import com.google.gson.JsonSyntaxException
import com.google.gson.annotations.SerializedName
import com.google.gson.reflect.TypeToken
import java.lang.ref.WeakReference
import java.net.URLEncoder
import org.json.JSONArray
import org.json.JSONException
import com.ethyca.janussdk.android.events.*

/**
 * Internal data structure for parsing event messages from JavaScript.
 */
data class JsEventPayload(
    @SerializedName("type") val type: String?,
    @SerializedName("data") val data: Map<String, Any>?
)

/**
 * Communication layer between native Android code and FidesJS running in a specific WebView.
 *
 * @param context Application context.
 */
open class FidesJSBridge() {

    companion object {
        const val INTERFACE_NAME = "JanusEventBridge" // Name exposed to JS
        internal const val TAG = "FidesJSBridge"
    }

    internal val appContext = JanusProvider.applicationContext
    private val gson = Gson()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var synchronizer: WebViewSynchronizer? = null

    // References for the single WebView and Handler this bridge instance manages
    internal var webViewRef: WeakReference<WebView>? = null
    private var eventHandler: WebViewEventHandler? = null

    /**
     * Sets up the JS interfaces and event handling for the associated WebView.
     *
     * @param webView The single WebView this bridge instance will manage.
     * @param autoSyncOnStart Whether to enable automatic synchronization when pages load.
     */
    open fun setupWebView(webView: WebView, autoSyncOnStart: Boolean = true, includeTCFScript: Boolean = false) {
        if (this.webViewRef?.get() != null || this.eventHandler != null) {
            Janus.log("Bridge for WebView seems already set up. Re-setup requested.", level = LogLevel.WARNING)
            // Allow re-setup, but log warning. Previous teardown should have occurred.
        }

        Janus.log("Setting up bridge for WebView", level = LogLevel.DEBUG)
        this.webViewRef = WeakReference(webView)

        // 1. Create and store the handler for this bridge/WebView
        this.eventHandler = WebViewEventHandler(this.webViewRef!!, WeakReference(this))

        // 2. Add JavaScript interfaces
        webView.addJavascriptInterface(this, INTERFACE_NAME) // For events
        webView.addJavascriptInterface(JanusLogBridge(), JanusLogBridge.INTERFACE_NAME) // For logs
        Janus.log("Added JS Interfaces: $INTERFACE_NAME, ${JanusLogBridge.INTERFACE_NAME} to WebView", level = LogLevel.DEBUG)

        // Initialize synchronizer if autoSyncOnStart is true
        if (autoSyncOnStart) {
            Janus.log("Creating WebViewSynchronizer for automatic consent synchronization", level = LogLevel.DEBUG)
            synchronizer = WebViewSynchronizer(this)
        }

        // 3. Set up a WebViewClient to inject scripts after page loads
        setupWebViewClient(webView, includeTCFScript)
    }

    /**
     * Sets up a WebViewClient to inject scripts when pages finish loading.
     */
    private fun setupWebViewClient(webView: WebView, includeTCFScript: Boolean = false) {
        webView.webViewClient = object : android.webkit.WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                
                // Ensure it's our WebView 
                if (view != null && view === webViewRef?.get()) {
                    Janus.log("Page finished loading, injecting scripts", level = LogLevel.DEBUG)
                    
                    // Inject scripts after the page has loaded
                    JSResourceLoader.injectAllScripts(appContext, view)

                    if (includeTCFScript) {
                        JSResourceLoader.injectScript(appContext,"tcfWebView.js", webView)
                    }
                    
                    // Synchronize consent data after scripts are injected if synchronizer exists
                    synchronizer?.synchronizeConsentData(view)
                }
            }
        }
    }

    /**
     * Removes JS interfaces and cleans up resources for the associated WebView.
     *
     * @param webView Should be the same WebView passed during setup.
     */
    fun teardownWebView(webView: WebView) {
        val currentWebView = webViewRef?.get()
        if (currentWebView == null) {
            Janus.log("Teardown requested but WebView reference is already null.", level = LogLevel.WARNING)
            return
        }
        if (currentWebView !== webView) {
            Janus.log("Teardown requested for different WebView than bridge is associated with! Aborting teardown.", level = LogLevel.ERROR)
            // This indicates a logic error in the managing layer (e.g., WebViewManager)
            return
        }

        Janus.log("Tearing down bridge for WebView", level = LogLevel.DEBUG)
        webView.removeJavascriptInterface(INTERFACE_NAME)
        webView.removeJavascriptInterface(JanusLogBridge.INTERFACE_NAME)

        // Clear references
        this.eventHandler = null
        this.webViewRef = null
        Janus.log("Cleared handler and WebView reference.", level = LogLevel.DEBUG)
    }

    // MARK: - Message Handling (From JavaScript)

    /**
     * Method exposed to JavaScript via the `JanusEventBridge` interface.
     * Receives event messages as JSON strings.
     */
    @JavascriptInterface
    fun postMessage(jsonPayload: String) {
        Janus.log("Received message from JS: $jsonPayload", level = LogLevel.VERBOSE)
        val handler = this.eventHandler
        if (handler == null) {
             Janus.log("Received JS message but eventHandler is null (bridge might be torn down or not setup?). Discarding: $jsonPayload", level = LogLevel.ERROR)
             return
        }

        try {
            val payload = gson.fromJson(jsonPayload, JsEventPayload::class.java)
            val eventTypeString = payload.type
            val data = payload.data ?: emptyMap()

            if (eventTypeString == null) {
                Janus.log("Received message from JS with missing 'type': $jsonPayload", level = LogLevel.ERROR)
                return
            }

            // Process the event (map string to JanusEvent)
            processEventFromFidesJS(eventTypeString, data, handler)

        } catch (e: JsonSyntaxException) {
            Janus.log("Failed to parse event JSON from JavaScript: $jsonPayload", level = LogLevel.ERROR, error = e)
        } catch (e: Exception) {
            Janus.log("Error processing event from JavaScript: $jsonPayload", level = LogLevel.ERROR, error = e)
        }
    }

    /**
     * Processes the raw event type string and data from JS, converting it to a JanusEvent.
     *
     * @param eventTypeString The `type` field from the JS message.
     * @param data The `data` field from the JS message.
     * @param handler The specific handler instance to use.
     */
    internal open fun processEventFromFidesJS(eventTypeString: String, data: Map<String, Any>, handler: WebViewEventHandler) {
        if (data["source"] as? String == "JanusSDK") {
            Janus.log("Ignoring event originating from JanusSDK: $eventTypeString", level = LogLevel.DEBUG)
            return
        }

        // Map FidesJS event types string to our JanusEvent classes
        val event: JanusEvent? = when (eventTypeString) {
            FidesEventType.FIDES_INITIALIZING.value -> WebViewFidesInitializingEvent()
            FidesEventType.FIDES_INITIALIZED.value -> {
                val shouldShow = data.nestedGet<Boolean>("extraDetails", "shouldShowExperience") ?: false
                WebViewFidesInitializedEvent(shouldShowExperience = shouldShow)
            }
            FidesEventType.FIDES_UI_SHOWN.value -> WebViewFidesUIShownEvent()
            FidesEventType.FIDES_UI_CHANGED.value -> {
                val interaction = data.nestedGet<Map<String, Boolean>>("consent") ?: emptyMap()
                WebViewFidesUIChangedEvent(_interaction = interaction)
            }
            FidesEventType.FIDES_MODAL_CLOSED.value -> {
                val method = data.nestedGet<String>("extraDetails", "consentMethod") ?: "unknown"
                WebViewFidesModalClosedEvent(consentMethod = method)
            }
            FidesEventType.FIDES_UPDATING.value -> {
                val consent = data.nestedGet<Map<String, Boolean>>("consent") ?: emptyMap()
                WebViewFidesUpdatingEvent(_consentIntended = consent)
            }
            FidesEventType.FIDES_UPDATED.value -> WebViewFidesUpdatedEvent()
            else -> {
                Janus.log("Unknown FidesJS event type received: $eventTypeString", level = LogLevel.WARNING)
                null
            }
        }

        if (event != null) {
            Janus.log("Processed JS event '$eventTypeString' into JanusEvent: ${event.eventType}", level = LogLevel.DEBUG)
            handler.handleEvent(event) // Pass to the specific handler
        } else {
            Janus.log("Failed to process JS event type: $eventTypeString", level = LogLevel.WARNING)
        }
    }

    // MARK: - Communication TO JavaScript

    /**
     * Sends a message to the `window.Janus.receiveMessageFromNative` function in the associated WebView.
     *
     * @param message The message payload to send.
     */
    internal fun sendMessageToJS(message: Map<String, Any>) {
        val webView = webViewRef?.get()
        if (webView == null) {
            Janus.log("Cannot send message to JS, WebView reference is null.", level = LogLevel.ERROR)
            return
        }
        // Implementation of sending remains the same, but uses the member webViewRef
        try {
            val jsonString = gson.toJson(message)
            val escapedJsonString = jsonString.encodeForJavaScript()
            val jsCode = "window.Janus.receiveMessageFromNative(decodeURIComponent('$escapedJsonString'));"
            Janus.log("Sending message to JS: $jsCode", level = LogLevel.VERBOSE)

            mainHandler.post {
                webView.evaluateJavascript(jsCode) { result ->
                    Janus.log("JS evaluation result for sending message: $result", level = LogLevel.VERBOSE)
                }
            }
        } catch (e: Exception) {
            Janus.log("Error serializing or escaping message for JavaScript", level = LogLevel.ERROR, error = e)
        }
    }

    /**
     * Sends a consent update to FidesJS in the associated WebView.
     *
     * @param consentValues The consent values to update.
     * @param consentMethod Optional consent method.
     */
    fun sendConsentUpdateToJS(consentValues: Map<String, Any>, consentMethod: String? = null) {
         val webView = webViewRef?.get()
         if (webView == null) {
             Janus.log("Cannot send consent update to JS, WebView reference is null.", level = LogLevel.ERROR)
             return
         }
        val messageData = mutableMapOf<String, Any>("consent" to consentValues)
        consentMethod?.let { messageData["consentMethod"] = it }

        val message = mapOf(
            "type" to "UpdateConsent",
            "data" to messageData
        )
        sendMessageToJS(message) // No need to pass webView explicitly
    }

    /**
     * Sends a command to dispatch a FidesJS event within the associated WebView.
     *
     * @param eventType The type of FidesJS event (e.g., "FidesUIShown").
     * @param data Additional data for the event.
     */
    open fun sendFidesEventToJS(eventType: String, data: Map<String, Any>) {
        val webView = webViewRef?.get()
        if (webView == null) {
            Janus.log("Cannot send Fides event to JS, WebView reference is null.", level = LogLevel.ERROR)
            return
        }
        val eventDataWithSource = data.toMutableMap().apply { this["source"] = "JanusSDK" }
        val message = mapOf(
            "type" to "DispatchFidesEvent",
            "data" to mapOf("eventType" to eventType, "eventData" to eventDataWithSource)
        )
        sendMessageToJS(message) // No need to pass webView explicitly
    }

    /**
     * Retrieves current consent values from FidesJS in the associated WebView.
     *
     * @param completion Callback function receiving (consentMap, fidesString, consentMethod).
     */
    fun getConsentValuesFromJS(
        completion: (consentMap: Map<String, Boolean>, fidesString: String, consentMethod: String) -> Unit
    ) {
        val webView = webViewRef?.get()
        val errorResult = Triple(emptyMap<String, Boolean>(), "", "error")
        val mainThreadCompletion = { result: Triple<Map<String, Boolean>, String, String> ->
            mainHandler.post { completion(result.first, result.second, result.third) }
        }

        if (webView == null) {
            Janus.log("Cannot get consent values from JS, WebView reference is null.", level = LogLevel.ERROR)
            mainThreadCompletion(errorResult)
            return
        }

        // Logic for calling JS and handling callbacks remains similar
        evaluateJsSafely(webView, "window.Janus.getFidesConsent();") { consentResult ->
             if (consentResult == null) {
                 Janus.log("Failed to get consent values from JS (null result).", level = LogLevel.ERROR)
                 mainThreadCompletion(errorResult)
                 return@evaluateJsSafely
             }
             val consentMap: Map<String, Boolean> = try {
                 val type = object : TypeToken<Map<String, Boolean>>() {}.type
                 gson.fromJson(consentResult, type) ?: emptyMap()
             } catch (e: Exception) {
                 Janus.log("Error parsing consent values JSON from JS: $consentResult", level = LogLevel.ERROR, error = e)
                 emptyMap()
             }

             evaluateJsSafely(webView, "window.Janus.getFidesString();") { fidesStringResult ->
                 val fidesString = fidesStringResult ?: ""
                 if (fidesStringResult == null) Janus.log("Failed to get fidesString from JS (null result).", level = LogLevel.WARNING)

                 evaluateJsSafely(webView, "window.Janus.getFidesConsentMethod();") { methodResult ->
                     val consentMethod = methodResult ?: "error"
                     if (methodResult == null) Janus.log("Failed to get consentMethod from JS (null result).", level = LogLevel.WARNING)

                     val finalResult = if (consentMap.isEmpty() && fidesString.isEmpty() && consentMethod == "error") {
                         Janus.log("Consent map/fidesString empty and method is error after JS calls.", level = LogLevel.ERROR)
                         errorResult
                     } else {
                          Triple(consentMap, fidesString, consentMethod)
                     }
                     mainThreadCompletion(finalResult)
                 }
             }
         }
    }

    /** Helper to run evaluateJavascript safely. */
    private fun evaluateJsSafely(webView: WebView, script: String, callback: (String?) -> Unit) {
        mainHandler.post {
            webView.evaluateJavascript(script) { result ->
                if (result == null || result.equals("null", ignoreCase = true) || result.equals("undefined", ignoreCase = true)) {
                     Janus.log("JavaScript evaluation returned null/undefined for script: $script", level = LogLevel.WARNING)
                     callback(null)
                } else {
                    callback(unescapeJsResult(result))
                }
            }
        }
    }
    
    /**
     * Properly unescapes a JSON string returned from JavaScript.
     * Handles all escape sequences by leveraging the JSON parser itself.
     */
    fun unescapeJsResult(result: String): String {
        return if (result.isNullOrEmpty() || result == "null" || result == "\"null\"") {
            ""
        } else {
            try {
                JSONArray("[$result]").getString(0)
            } catch (e: JSONException) {
                Janus.log("Error unescaping JS result: $result", level = LogLevel.ERROR, error = e)
                result.removeSurrounding("\"") // Fallback to basic unescaping
            }
        }
    }
    
    /**
     * Encodes a string to be safely used in JavaScript.
     * Used with decodeURIComponent() in JavaScript.
     */
    fun String.encodeForJavaScript(): String {
        return URLEncoder.encode(this, "UTF-8")
    }
}

inline fun <reified T> Map<String, Any>.nestedGet(vararg keys: String): T? {
    var current: Any? = this
    for (key in keys) {
        current = (current as? Map<*, *>)?.get(key)
        if (current == null) return null
    }
    return current as? T
}
