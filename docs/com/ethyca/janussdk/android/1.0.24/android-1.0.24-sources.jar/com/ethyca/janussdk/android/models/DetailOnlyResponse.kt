package com.ethyca.janussdk.android.models

import com.google.gson.annotations.SerializedName

/**
 * Response structure for API calls that return only a detail message
 * This is used to handle special cases where the server returns a 
 * message like {"detail":"Cached experience is not available"}
 */
data class DetailOnlyResponse(
    @SerializedName("detail") val detail: String
) 