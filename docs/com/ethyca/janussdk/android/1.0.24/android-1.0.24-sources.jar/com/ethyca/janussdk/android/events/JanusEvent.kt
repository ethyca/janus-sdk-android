package com.ethyca.janussdk.android.events

import android.webkit.WebView
import com.ethyca.janussdk.android.core.JanusProvider
import com.ethyca.janussdk.android.models.ConsentFlagType
import com.ethyca.janussdk.android.models.ConsentNonApplicableFlagMode
import com.ethyca.janussdk.android.utils.ConsentTransformationUtils

/**
 * Types of events that can be emitted by the JanusSDK
 */
enum class JanusEventType(private val stringValue: String) {
    // Native experience events
    EXPERIENCE_SHOWN("experienceShown"),
    EXPERIENCE_INTERACTION("experienceInteraction"),
    EXPERIENCE_CLOSED("experienceClosed"),
    EXPERIENCE_SELECTION_UPDATING("experienceSelectionUpdating"),
    EXPERIENCE_SELECTION_UPDATED("experienceSelectionUpdated"),

    // WebView events
    WEBVIEW_FIDES_INITIALIZING("webviewFidesInitializing"),
    WEBVIEW_FIDES_INITIALIZED("webviewFidesInitialized"),
    WEBVIEW_FIDES_UI_SHOWN("webviewFidesUIShown"),
    WEBVIEW_FIDES_UI_CHANGED("webviewFidesUIChanged"),
    WEBVIEW_FIDES_MODAL_CLOSED("webviewFidesModalClosed"),
    WEBVIEW_FIDES_UPDATING("webviewFidesUpdating"),
    WEBVIEW_FIDES_UPDATED("webviewFidesUpdated"),

    // Consent events
    CONSENT_UPDATED_FROM_WEBVIEW("consentUpdatedFromWebView");

    /**
     * Override toString to return the string value instead of the enum name
     */
    override fun toString(): String {
        return stringValue
    }
}

/**
 * Types of events that can be emitted by FidesJS
 * FidesInitializing and FidesInitialized are not included because they
 * are emitted before JanusSDK interacts with FidesJS
 */
enum class FidesEventType(val value: String) {
    FIDES_INITIALIZING("FidesInitializing"),
    FIDES_INITIALIZED("FidesInitialized"),
    FIDES_UI_SHOWN("FidesUIShown"),
    FIDES_UI_CHANGED("FidesUIChanged"),
    FIDES_MODAL_CLOSED("FidesModalClosed"),
    FIDES_UPDATING("FidesUpdating"),
    FIDES_UPDATED("FidesUpdated")
}

/**
 * Helper function to apply the full two-step consent transformation
 * (flag type transformation + non-applicable notice handling)
 */
private fun applyFullConsentTransformation(booleanConsent: Map<String, Boolean>): Map<String, Any> {
    val flagType = JanusProvider.configuration?.consentFlagType ?: ConsentFlagType.BOOLEAN
    val nonApplicableFlagMode = JanusProvider.configuration?.consentNonApplicableFlagMode ?: ConsentNonApplicableFlagMode.OMIT
    val privacyNotices = JanusProvider.shared.currentExperience?.privacyNotices
    
    // First, transform consent values based on the flag type
    var transformedConsent = ConsentTransformationUtils.applyOverridesToConsent(
        booleanConsent = booleanConsent,
        flagType = flagType,
        privacyNotices = privacyNotices
    )
    
    // Then, handle non-applicable notices based on the flag mode
    val nonApplicableNotices = JanusProvider.shared.currentExperience?.nonApplicablePrivacyNotices
    if (nonApplicableNotices != null) {
        transformedConsent = ConsentTransformationUtils.handleNonApplicableNotices(
            consent = transformedConsent,
            nonApplicableNotices = nonApplicableNotices,
            flagType = flagType,
            mode = nonApplicableFlagMode
        )
    }
    
    return transformedConsent
}

/**
 * Base class for events emitted by the JanusSDK
 */
open class JanusEvent {
    val eventType: JanusEventType
    val detail: Map<String, Any>?

    /**
     * Indicates whether this event should be propagated to FidesJS in WebViews
     * Defaults to false for most events, overridden to true for specific native events
     */
    open val shouldPropagateToFidesJS: Boolean = false

    constructor(eventType: JanusEventType, detail: Map<String, Any>? = null) {
        this.eventType = eventType
        this.detail = detail
    }
}

/**
 * Base class for all native Janus events that should propagate to FidesJS
 */
open class NativeJanusEvent : JanusEvent {
    /**
     * Override to indicate all native events should be propagated to FidesJS
     */
    override val shouldPropagateToFidesJS: Boolean = true

    constructor(eventType: JanusEventType, detail: Map<String, Any>? = null) : super(eventType, detail)
}

/**
 * Event fired when the experience UI is shown
 */
class ExperienceShownEvent : NativeJanusEvent(JanusEventType.EXPERIENCE_SHOWN)

/**
 * Event fired when user interacts with the experience UI
 */
class ExperienceInteractionEvent(private val _interaction: Map<String, Boolean>) : NativeJanusEvent(
    JanusEventType.EXPERIENCE_INTERACTION,
    mapOf("interaction" to applyFullConsentTransformation(_interaction))
) {
    /**
     * Interaction data (format depends on consentFlagType configuration)
     */
    val interaction: Map<String, Any>
        get() = applyFullConsentTransformation(_interaction)
}

/**
 * Event fired when the experience UI is closed
 */
class ExperienceClosedEvent(closeMethod: String) : NativeJanusEvent(
    JanusEventType.EXPERIENCE_CLOSED,
    mapOf("closeMethod" to closeMethod)
)

/**
 * Event fired before updating the user's consent selections
 */
class ExperienceSelectionUpdatingEvent(private val _consentIntended: Map<String, Boolean>) : NativeJanusEvent(
    JanusEventType.EXPERIENCE_SELECTION_UPDATING,
    mapOf("consent" to applyFullConsentTransformation(_consentIntended))
) {
    /**
     * Intended consent data (format depends on consentFlagType configuration)
     */
    val consentIntended: Map<String, Any>
        get() = applyFullConsentTransformation(_consentIntended)
}

/**
 * Event fired after updating the user's consent selections
 */
class ExperienceSelectionUpdatedEvent : NativeJanusEvent(JanusEventType.EXPERIENCE_SELECTION_UPDATED)

/**
 * Event fired when FidesJS begins initializing in a WebView
 */
class WebViewFidesInitializingEvent : JanusEvent(JanusEventType.WEBVIEW_FIDES_INITIALIZING)

/**
 * Event fired when FidesJS has completed initialization in a WebView
 */
class WebViewFidesInitializedEvent(shouldShowExperience: Boolean) : JanusEvent(
    JanusEventType.WEBVIEW_FIDES_INITIALIZED,
    mapOf("shouldShowExperience" to shouldShowExperience)
)

/**
 * Event fired when a FidesJS UI component is shown
 */
class WebViewFidesUIShownEvent : JanusEvent(JanusEventType.WEBVIEW_FIDES_UI_SHOWN)

/**
 * Event fired when user changes preferences in the FidesJS UI
 */
class WebViewFidesUIChangedEvent(private val _interaction: Map<String, Boolean>) : JanusEvent(
    JanusEventType.WEBVIEW_FIDES_UI_CHANGED,
    mapOf("interaction" to applyFullConsentTransformation(_interaction))
) {
    /**
     * Interaction data (format depends on consentFlagType configuration)
     */
    val interaction: Map<String, Any>
        get() = applyFullConsentTransformation(_interaction)
}

/**
 * Event fired when FidesJS modal is closed
 */
class WebViewFidesModalClosedEvent(consentMethod: String) : JanusEvent(
    JanusEventType.WEBVIEW_FIDES_MODAL_CLOSED,
    mapOf("consentMethod" to consentMethod)
)

/**
 * Event fired when FidesJS begins updating user's consent preferences
 */
class WebViewFidesUpdatingEvent(private val _consentIntended: Map<String, Boolean>) : JanusEvent(
    JanusEventType.WEBVIEW_FIDES_UPDATING,
    mapOf("consent" to applyFullConsentTransformation(_consentIntended))
) {
    /**
     * Intended consent data (format depends on consentFlagType configuration)
     */
    val consentIntended: Map<String, Any>
        get() = applyFullConsentTransformation(_consentIntended)
}

/**
 * Event fired when FidesJS has updated and saved user's consent preferences
 */
class WebViewFidesUpdatedEvent : JanusEvent(JanusEventType.WEBVIEW_FIDES_UPDATED)

/**
 * Event fired after consent values have been updated from a WebView
 */
class ConsentUpdatedFromWebViewEvent(
    private val _values: Map<String, Boolean>,
    private val fidesString: String,
    private val sourceWebView: WebView?
) : JanusEvent(JanusEventType.CONSENT_UPDATED_FROM_WEBVIEW) {

    /**
     * Get the consent values that were updated (format depends on consentFlagType configuration)
     * @return Dictionary of consent values
     */
    fun getConsentValues(): Map<String, Any> {
        return applyFullConsentTransformation(_values)
    }

    /**
     * Get the Fides string associated with the consent values
     * @return The Fides string
     */
    fun getFidesString(): String {
        return fidesString
    }

    /**
     * Get the WebView that originated the consent update
     * @return The source WebView, if still available
     */
    fun getSourceWebView(): WebView? {
        return sourceWebView
    }
}
