package com.ethyca.janussdk.android.api

import com.ethyca.janussdk.android.models.IPLocationResponse
import com.ethyca.janussdk.android.Janus
import com.ethyca.janussdk.android.LogLevel
import com.google.gson.Gson
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

open class IPLocationAPI {
    
    companion object {
        val shared: IPLocationAPI = IPLocationAPI()
    }
    
    private val locationEndpoint = "https://cdn-api.ethyca.com/location"
    private val gson = Gson()
    
    // Made open for testing
    protected open fun createConnection(url: URL): HttpURLConnection {
        return url.openConnection() as HttpURLConnection
    }
    
    open fun fetchLocation(completion: (Result<IPLocationResponse>) -> Unit) {
        thread {
            try {
                val url = URL(locationEndpoint)
                val connection = createConnection(url)
                connection.requestMethod = "GET"
                connection.connectTimeout = 15000
                connection.readTimeout = 15000
                connection.setRequestProperty("Accept", "application/json")
                
                val responseCode = connection.responseCode
                
                if (responseCode in 200..299) {
                    val inputStream = connection.inputStream
                    val responseString = inputStream.bufferedReader().use { it.readText() }
                    val response = gson.fromJson(responseString, IPLocationResponse::class.java)
                    
                    completion(Result.success(response))
                } else {
                    Janus.log("IP Location API HTTP Error", level = LogLevel.ERROR, metadata = mapOf("statusCode" to responseCode.toString()))
                    completion(Result.failure(APIError.BadResponse(responseCode)))
                }
            } catch (e: IOException) {
                Janus.log("IP Location API Error", level = LogLevel.ERROR, error = e)
                completion(Result.failure(APIError.NetworkError(e)))
            } catch (e: Exception) {
                if (e is IOException) {
                    Janus.log("IP Location API Error", level = LogLevel.ERROR, error = e)
                    completion(Result.failure(APIError.NetworkError(e)))
                } else {
                    Janus.log("IP Location API Decoding Error", level = LogLevel.ERROR, error = e)
                    completion(Result.failure(APIError.DecodingError(e)))
                }
            }
        }
    }
} 