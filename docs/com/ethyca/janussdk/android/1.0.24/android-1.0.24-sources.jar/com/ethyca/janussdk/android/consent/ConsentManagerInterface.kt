package com.ethyca.janussdk.android.consent

import com.ethyca.janussdk.android.models.ConsentMethod

/**
 * Interface defining the consent management contract
 * This allows for mocking and dependency injection of the consent manager
 */
interface ConsentManagerInterface {
    /**
     * Get the current consent values
     */
    fun getConsent(): Map<String, Boolean>

    /**
     * Get metadata about consent timestamps
     */
    fun getMetadata(): ConsentMetadata

    /**
     * Get the current fides_string
     */
    fun getFidesString(): String

    /**
     * Get the current consent method
     */
    fun getConsentMethod(): ConsentMethod

    /**
     * Set multiple consent values
     * @param values Dictionary of consent values to set
     * @param versionHash Version hash from the privacy experience
     * @param fidesString Optional fides_string to save with the consent values
     * @param consentMethod Optional method used to set consent
     */
    fun setConsent(values: Map<String, Boolean>, versionHash: String, fidesString: String? = null, consentMethod: ConsentMethod? = null)

    /**
     * Clear all consent values
     * @param clearMetadata Whether to also clear metadata timestamps
     */
    fun clearConsent(clearMetadata: Boolean = false)
}