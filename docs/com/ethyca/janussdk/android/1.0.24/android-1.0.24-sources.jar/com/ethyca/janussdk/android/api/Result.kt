package com.ethyca.janussdk.android.api

/**
 * A generic class to handle success and failure cases for API operations
 */
sealed class Result<out T> {
    data class Success<T>(val value: T) : Result<T>()
    data class Failure(val error: APIError) : Result<Nothing>()

    companion object {
        fun <T> success(value: T): Result<T> = Success(value)
        fun <T> failure(error: APIError): Result<T> = Failure(error)
    }
} 