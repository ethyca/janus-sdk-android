package com.ethyca.janussdk.android.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CompoundButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.widget.SwitchCompat
import androidx.recyclerview.widget.RecyclerView
import com.ethyca.janussdk.android.events.ExperienceInteractionEvent
import com.ethyca.janussdk.android.Janus
import com.ethyca.janussdk.android.R
import com.ethyca.janussdk.android.models.TranslatedPrivacyNotice
import com.ethyca.janussdk.android.ui.view.HTMLTextView

/**
 * Adapter for displaying privacy notices in a RecyclerView
 */
class PrivacyNoticeAdapter : RecyclerView.Adapter<PrivacyNoticeAdapter.NoticeViewHolder>() {

    private var notices: List<TranslatedPrivacyNotice> = emptyList()
    private val consentValues: MutableMap<String, Boolean> = mutableMapOf()
    private val expandedItems = mutableSetOf<Int>()
    
    /**
     * Set the privacy notices to display
     */
    fun setNotices(notices: List<TranslatedPrivacyNotice>) {
        this.notices = notices
        
        // Initialize consent values based on current consent values or default preferences
        for (notice in notices) {
            notice.noticeKey?.let { key ->
                if (notice.consentMechanism == "notice_only") {
                    // For notice_only consent mechanisms, always set to true
                    consentValues[key] = true
                } else {
                    // If we have a consent value for this key, use it
                    // Otherwise use the notice's default preference
                    val existingConsent = Janus.internalConsent[key]
                    val defaultValue = notice.defaultPreference == "opt_in" || notice.defaultPreference == "acknowledge"
                    consentValues[key] = existingConsent ?: defaultValue
                }
            }
        }
        
        // Clear expanded state when updating notices
        expandedItems.clear()
        notifyDataSetChanged()
    }
    
    /**
     * Get the current consent values
     */
    fun getConsentValues(): Map<String, Boolean> {
        return consentValues.toMap()
    }
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NoticeViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_privacy_notice, parent, false)
        return NoticeViewHolder(view)
    }
    
    override fun onBindViewHolder(holder: NoticeViewHolder, position: Int) {
        val notice = notices[position]
        val isExpanded = expandedItems.contains(position)
        holder.bind(notice, position, isExpanded)
    }
    
    override fun getItemCount(): Int = notices.size
    
    /**
     * Update a specific consent value and fire the interaction event
     * 
     * @param key Consent key
     * @param value Consent value (true = granted, false = denied)
     */
    private fun updateConsent(key: String, value: Boolean) {
        // Update the local map
        consentValues[key] = value
        
        // Fire ExperienceInteractionEvent
        val interaction = mapOf(key to value)
        val interactionEvent = ExperienceInteractionEvent(interaction)
        Janus.notifyEventListeners(interactionEvent)
    }
    
    inner class NoticeViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val titleTextView: TextView = itemView.findViewById(R.id.noticeTitle)
        private val descriptionTextView: HTMLTextView = itemView.findViewById(R.id.noticeDescription)
        private val requiredIndicator: TextView = itemView.findViewById(R.id.requiredIndicator)
        private val toggleSwitch: SwitchCompat = itemView.findViewById(R.id.noticeToggle)
        private val expandCollapseIcon: ImageView = itemView.findViewById(R.id.expandCollapseIcon)
        private val expandableContent: LinearLayout = itemView.findViewById(R.id.expandableContent)
        private val headerLayout: LinearLayout = itemView.findViewById(R.id.noticeHeaderLayout)
        
        fun bind(notice: TranslatedPrivacyNotice, position: Int, isExpanded: Boolean) {
            // Use the pre-resolved translation data - no more duplication!
            titleTextView.text = notice.title
            
            // Use HTMLTextView's setHtmlContent method for the description
            descriptionTextView.setHtmlContent(notice.description)
            
            // Check if this is a required notice (notice_only consent mechanism)
            val isRequired = notice.consentMechanism == "notice_only"
            
            // Show/hide required indicator
            requiredIndicator.visibility = if (isRequired) View.VISIBLE else View.GONE
            
            // Update expanded state UI
            expandableContent.visibility = if (isExpanded) View.VISIBLE else View.GONE
            expandCollapseIcon.setImageResource(
                if (isExpanded) R.drawable.ic_chevron_up else R.drawable.ic_chevron_down
            )
            
            // Set background color based on expanded state
            val noticeContainer = itemView.findViewById<LinearLayout>(R.id.noticeContainer)
            if (isExpanded) {
                noticeContainer.setBackgroundResource(R.color.background_light_gray)
            } else {
                noticeContainer.setBackgroundResource(android.R.color.transparent)
            }
            
            // Set click listener for expand/collapse on both header and chevron
            headerLayout.setOnClickListener {
                toggleExpanded(position)
            }
            
            expandCollapseIcon.setOnClickListener {
                toggleExpanded(position)
            }
            
            // Handle toggle state
            val noticeKey = notice.noticeKey
            if (noticeKey.isNotEmpty()) {
                // Clear previous listeners to avoid duplication
                toggleSwitch.setOnCheckedChangeListener(null)
                
                // Get the current value (will be from existing consent, or default from setNotices)
                val isEnabled = consentValues[noticeKey] ?: false
                toggleSwitch.isChecked = isEnabled
                
                // Disable toggle for required notices
                toggleSwitch.isEnabled = !isRequired
                
                // Add change listener (if not required)
                if (!isRequired) {
                    toggleSwitch.setOnCheckedChangeListener { _, isChecked ->
                        // Update and fire event
                        updateConsent(noticeKey, isChecked)
                    }
                } else {
                    // For required notices, always set to true
                    consentValues[noticeKey] = true
                    toggleSwitch.isChecked = true
                }
            } else {
                toggleSwitch.isEnabled = false
            }
        }
    }
    
    private fun toggleExpanded(position: Int) {
        val isCurrentlyExpanded = expandedItems.contains(position)
        if (isCurrentlyExpanded) {
            expandedItems.remove(position)
        } else {
            expandedItems.add(position)
        }
        notifyItemChanged(position)
    }
} 
