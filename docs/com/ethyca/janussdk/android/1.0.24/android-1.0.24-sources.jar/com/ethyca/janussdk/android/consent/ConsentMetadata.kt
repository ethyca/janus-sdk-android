package com.ethyca.janussdk.android.consent

import com.ethyca.janussdk.android.models.ConsentMethod
import java.util.Date

/**
 * Metadata about when consent values were created and updated
 */
data class ConsentMetadata(
    /**
     * The timestamp when consent was first created
     */
    var createdAt: Date? = null,

    /**
     * The timestamp when consent was last updated
     */
    var updatedAt: Date? = null,

    /**
     * The method by which consent was last set
     */
    var consentMethod: ConsentMethod = ConsentMethod.UNKNOWN,

    /**
     * The version hash of the privacy experience that was used to set consent
     */
    var versionHash: String = ""
)