package com.ethyca.janussdk.android.utils

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.ethyca.janussdk.android.Janus
import com.ethyca.janussdk.android.LogLevel

/**
 * Helper class for URL-related operations such as opening links in external applications
 */
class UrlHelper {
    companion object {
        /**
         * Opens a URL in the system's default browser application
         * @param context The context to use for starting the browser activity
         * @param url The URL to open
         * @return true if the URL was successfully opened, false otherwise
         */
        fun openInBrowser(context: Context, url: Uri): Boolean {
            return try {
                val intent = Intent(Intent.ACTION_VIEW, url)
                context.startActivity(intent)
                true
            } catch (e: Exception) {
                Janus.log( "Failed to open URL: $url", LogLevel.ERROR, error = e)
                false
            }
        }
    }
} 