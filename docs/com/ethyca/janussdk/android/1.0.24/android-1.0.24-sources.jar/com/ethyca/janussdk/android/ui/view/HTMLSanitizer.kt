package com.ethyca.janussdk.android.ui.view

import android.os.Build
import android.text.Html
import android.text.Spanned
import android.text.method.LinkMovementMethod
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.ethyca.janussdk.android.R
import java.util.regex.Pattern

/**
 * Utility class for sanitizing and processing HTML content safely
 */
class HTMLSanitizer {
    companion object {
        // Pattern to detect HTML tags
        private val HTML_PATTERN = Pattern.compile("<[^>]+>")
        
        /**
         * Sanitizes HTML content by decoding entities and removing unsafe tags
         * @param content HTML content string, which may be encoded or raw
         * @return HTML string with entities decoded and unsafe tags removed
         */
        @JvmStatic
        fun sanitize(content: String): String {
            // Decode HTML entities
            val decoded = decodeHTMLEntities(content)
            
            // Apply sanitization to remove unsafe tags but keep safe ones
            return sanitizeHTML(decoded)
        }
        
        /**
         * Converts sanitized HTML to a Spanned object for display in TextViews
         * @param content Already sanitized HTML content string
         * @return A Spanned object with HTML formatting
         */
        @JvmStatic
        fun fromHtml(content: String): Spanned {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                Html.fromHtml(content, Html.FROM_HTML_MODE_LEGACY)
            } else {
                @Suppress("DEPRECATION")
                Html.fromHtml(content)
            }
        }
        
        /**
         * Determines if the provided content contains HTML tags
         * @param content The content to check
         * @return True if content contains HTML tags
         */
        @JvmStatic
        fun containsHtml(content: String): Boolean {
            return HTML_PATTERN.matcher(content).find()
        }
        
        /**
         * Determines if the provided content contains HTML entities
         * @param content The content to check
         * @return True if content contains HTML entities
         */
        @JvmStatic
        fun containsHtmlEntities(content: String): Boolean {
            return content.contains("&") && 
                   (content.contains(";") || 
                    content.contains("&#"))
        }
        
        /**
         * Decodes HTML entities in content
         * @param html HTML content with potential entities
         * @return Decoded content
         */
        private fun decodeHTMLEntities(html: String): String {
            // First check if we have entities that need decoding
            if (!containsHtmlEntities(html)) {
                return html
            }
            
            // We'll use Android's HTML parser to decode entities
            // This handles both named entities (&lt;) and numeric entities (&#x27;)
            val spanned = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY)
            } else {
                @Suppress("DEPRECATION")
                Html.fromHtml(html)
            }
            
            return spanned.toString()
        }
        
        /**
         * Removes potentially harmful HTML tags and attributes from content
         * @param html The raw HTML content
         * @return Sanitized HTML content
         */
        private fun sanitizeHTML(html: String): String {
            var sanitized = html
            
            // List of tags to remove completely with their content
            val dangerousTags = listOf("script", "iframe", "object", "embed", "style", "form", "input")
            
            // Remove dangerous tags and their content
            for (tag in dangerousTags) {
                // Remove tags with content - use regex with dot matches all flag
                val contentPattern = "<\\s*$tag[^>]*>.*?<\\s*/$tag\\s*>"
                sanitized = sanitized.replace(Regex(contentPattern, RegexOption.DOT_MATCHES_ALL), "")
                
                // Remove self-closing tags
                val selfClosingPattern = "<\\s*$tag[^>]*\\s*/?>"
                sanitized = sanitized.replace(Regex(selfClosingPattern), "")
            }
            
            // Remove any event handlers (onclick, onload, etc.)
            val eventHandlerPattern = " on[a-z]+\\s*="
            sanitized = sanitized.replace(Regex(eventHandlerPattern, RegexOption.IGNORE_CASE), " data-removed=")
            
            // Remove javascript: URLs
            val javascriptPattern = "javascript\\s*:"
            sanitized = sanitized.replace(Regex(javascriptPattern, RegexOption.IGNORE_CASE), "invalid:")
            
            // Add target="_blank" to all links if not already present
            val linkPattern = "<a ([^>]*)>"
            sanitized = sanitized.replace(Regex(linkPattern)) { matchResult ->
                val linkAttrs = matchResult.groupValues[1]
                if (linkAttrs.contains("target=")) {
                    matchResult.value
                } else {
                    "<a target=\"_blank\" $linkAttrs>"
                }
            }
            
            return sanitized
        }
        
        /**
         * Convenience method to apply sanitized HTML to a TextView
         * @param textView The TextView to update
         * @param htmlContent The HTML content (encoded or unencoded)
         */
        @JvmStatic
        fun apply(textView: TextView, htmlContent: String) {
            val sanitizedContent = sanitize(htmlContent)
            
            if (containsHtml(sanitizedContent) || containsHtmlEntities(sanitizedContent)) {
                // Convert to Spanned
                val spanned = fromHtml(sanitizedContent)
                
                // Apply to TextView
                textView.text = spanned
                
                // Set link colors to adapt to theme
                val linkColor = ContextCompat.getColor(textView.context, R.color.link_color)
                textView.setLinkTextColor(linkColor)
                
                // Enable links
                textView.movementMethod = LinkMovementMethod.getInstance()
            } else {
                // No HTML - just set as plain text
                textView.text = sanitizedContent
            }
        }
        
        /**
         * Process HTML with vendor count replacement
         * @param htmlContent The HTML content to process
         * @param vendorCount The vendor count to insert
         * @return Processed HTML with vendor count inserted
         */
        @JvmStatic
        fun processWithVendorCount(htmlContent: String, vendorCount: Int?): String {
            val sanitized = sanitize(htmlContent)
            
            return if (sanitized.contains("__VENDOR_COUNT_LINK__") && vendorCount != null) {
                sanitized.replace("__VENDOR_COUNT_LINK__", vendorCount.toString())
            } else {
                sanitized
            }
        }
    }
} 