package com.ethyca.janussdk.android.models

/**
 * A privacy notice with its resolved translation to avoid duplication of translation matching
 *
 * @param originalNotice The original privacy notice
 * @param resolvedTranslation The matched translation for the current locale, or null if none found
 */
data class TranslatedPrivacyNotice(
    val originalNotice: PrivacyNotice,
    val resolvedTranslation: PrivacyNoticeTranslation?
) {
    // Convenience properties that delegate to the resolved translation or original notice
    val title: String
        get() = resolvedTranslation?.title ?: originalNotice.name ?: "Unknown Notice"
    
    val description: String
        get() = resolvedTranslation?.description ?: originalNotice.internalDescription ?: ""
    
    val privacyNoticeHistoryId: String?
        get() = resolvedTranslation?.privacyNoticeHistoryId
    
    val noticeKey: String
        get() = originalNotice.noticeKey ?: ""
    
    val consentMechanism: String?
        get() = originalNotice.consentMechanism
    
    val defaultPreference: String?
        get() = originalNotice.defaultPreference
} 