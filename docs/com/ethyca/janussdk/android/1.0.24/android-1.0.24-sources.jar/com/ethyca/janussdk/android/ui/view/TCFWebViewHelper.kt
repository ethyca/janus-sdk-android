package com.ethyca.janussdk.android.ui.view

import android.content.Context
import android.util.Log
import android.webkit.WebView
import com.ethyca.janussdk.android.Janus
import com.ethyca.janussdk.android.LogLevel
import com.ethyca.janussdk.android.webview.TCFWebViewJSBridge
import com.ethyca.janussdk.android.webview.WebViewManager

/**
 * Helper class for creating TCF WebViews that are ready before being presented
 */
class TCFWebViewHelper {
    
    companion object {
        private const val EMBEDDED_CONSENT_BASE_URL = "/embedded-consent.html"
        private const val QUERY_PARAM_GEOLOCATION = "geolocation"
        private const val QUERY_PARAM_PROPERTY_ID = "property_id"
        private const val QUERY_PARAM_LOCALE = "fides_locale"
        
        /**
         * Creates a TCF WebView and loads it until ready, then calls completion
         * 
         * @param context The application context to create the webView with
         * @param host The host URL for the TCF experience
         * @param region The region code (ISO-3166-2 format, e.g., "US-CA")
         * @param propertyId The optional property ID for the experience
         * @param preferredLocale The preferred locale for the TCF experience
         * @param completion Called when webView is ready with the WebView ID reference
         */
        fun createReadyWebView(
            context: Context,
            host: String,
            region: String? = null,
            propertyId: String? = null,
            preferredLocale: String? = null,
            completion: (String) -> Unit
        ) {
            // Build the TCF embedded URL
            val tcfEmbeddedUrl = buildTCFUrl(host, region, propertyId, preferredLocale)
            
            Janus.log("Loading TCF WebView for URL: $tcfEmbeddedUrl", level = LogLevel.INFO)
            
            // Create the WebView by reference using WebViewManager
            val webViewId = WebViewManager.createConsentWebViewWithId(
                context.applicationContext,
                autoSyncOnStart = true,
                tcfWebView = true
            )
            
            // Get the WebView and bridge using the reference
            val managedWebView = WebViewManager.getWebView(webViewId)
                ?: throw IllegalStateException("Failed to retrieve WebView by reference: $webViewId")
            
            val webView = managedWebView.webView
            val bridge = managedWebView.bridge
            
            if (bridge is TCFWebViewJSBridge) {
                // Set up ready callback
                bridge.onModalReady = {
                    Janus.log("TCF WebView is ready, calling completion", level = LogLevel.INFO)
                    completion(webViewId)
                }
                
                // Load the TCF experience
                webView.loadUrl(tcfEmbeddedUrl)
            } else {
                Janus.log("Error: Bridge is not a TCFWebViewJSBridge", level = LogLevel.ERROR)
            }
        }
        
        /**
         * Builds the TCF embedded URL with query parameters
         */
        private fun buildTCFUrl(
            host: String,
            region: String?,
            propertyId: String?,
            preferredLocale: String?
        ): String {
            var tcfUrl = "$host$EMBEDDED_CONSENT_BASE_URL"
            
            // Add query parameters if available
            val queryParams = mutableListOf<String>()
            
            region?.takeIf { it.isNotEmpty() }?.let {
                queryParams.add("$QUERY_PARAM_GEOLOCATION=$it")
            }
            
            propertyId?.takeIf { it.isNotEmpty() }?.let {
                queryParams.add("$QUERY_PARAM_PROPERTY_ID=$it")
            }
            
            preferredLocale?.takeIf { it.isNotEmpty() }?.let {
                queryParams.add("$QUERY_PARAM_LOCALE=$it")
            }
            
            // Append query parameters to URL if any exist
            if (queryParams.isNotEmpty()) {
                tcfUrl += "?" + queryParams.joinToString("&")
            }
            
            return tcfUrl
        }
    }
} 