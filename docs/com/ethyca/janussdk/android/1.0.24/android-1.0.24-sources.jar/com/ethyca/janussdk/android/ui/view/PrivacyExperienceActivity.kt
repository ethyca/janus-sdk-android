package com.ethyca.janussdk.android.ui.view

import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.ethyca.janussdk.android.Janus
import com.ethyca.janussdk.android.LogLevel
import com.ethyca.janussdk.android.R
import com.ethyca.janussdk.android.api.NoticesServedAPI
import com.ethyca.janussdk.android.consent.ConsentManager
import com.ethyca.janussdk.android.core.JanusProvider
import com.ethyca.janussdk.android.databinding.ActivityPrivacyExperienceBinding
import com.ethyca.janussdk.android.events.*
import com.ethyca.janussdk.android.models.ConsentMethod
import com.ethyca.janussdk.android.models.ExperienceConfigTranslation
import com.ethyca.janussdk.android.models.PrivacyExperienceItem
import com.ethyca.janussdk.android.models.PrivacyNotice
import com.ethyca.janussdk.android.models.TranslatedPrivacyNotice
import com.ethyca.janussdk.android.ui.adapter.PrivacyNoticeAdapter
import com.ethyca.janussdk.android.utils.TranslationMatcher
import com.ethyca.janussdk.android.utils.UrlHelper
import androidx.core.net.toUri
import com.ethyca.janussdk.android.api.PrivacyPreferencesAPI

/**
 * Activity that displays the privacy experience UI to the user.
 * This is a modal full-screen UI that allows users to view and update their privacy settings.
 */
class PrivacyExperienceActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPrivacyExperienceBinding
    private lateinit var noticeAdapter: PrivacyNoticeAdapter

    // Create a local instance of ConsentManager (following iOS approach)
    private lateinit var consentManager: ConsentManager

    // The current experience to display
    private var currentExperience: PrivacyExperienceItem? = null

    // Add tracking property for event fired on dismiss
    private var eventFiredOnDismiss = false

    // Store all notices with resolved translations (flattened)
    private var allNotices: List<TranslatedPrivacyNotice> = emptyList()
    
    // Cache the translated experience config to avoid multiple getLocalizedTranslation calls
    private var translatedExperienceConfig: ExperienceConfigTranslation? = null
    
    // Store the served notice history ID from NoticesServedAPI to pass to PrivacyPreferencesAPI
    private var servedNoticeHistoryId: String? = null

    companion object {
        private const val TAG = "PrivacyExperience"
        private const val ETHYCA_URL = "https://ethyca.com"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Apply the privacy experience theme
        setTheme(R.style.Theme_JanusSDK_Dialog)

        // Initialize binding
        binding = ActivityPrivacyExperienceBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initialize consent manager with activity context
        consentManager = ConsentManager()

        // Add close button listener
        // TODO: Uncomment when close button is implemented in the layout
        // binding.closeButton?.setOnClickListener {
        //     handleDismiss("close_button")
        //     finish()
        // }

        // Set up the back press handling
        setupBackPressHandling()

        // Set up the UI
        setupUI()

        // Load the privacy experience
        loadPrivacyExperience()
    }

    /**
     * Set up callback for handling back presses
     */
    private fun setupBackPressHandling() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                handleDismiss("back_button")
                finish()
            }
        })
    }

    private fun setupUI() {
        // Set up RecyclerView
        binding.privacyNoticesRecyclerView.layoutManager = LinearLayoutManager(this)
        noticeAdapter = PrivacyNoticeAdapter()
        binding.privacyNoticesRecyclerView.adapter = noticeAdapter
        
        // Set up powered by footer click handler
        setupPoweredByFooter()
    }
    
    /**
     * Set up click handler for the powered by footer to open Ethyca website
     */
    private fun setupPoweredByFooter() {
        val poweredByFooter = findViewById<LinearLayout>(R.id.powered_by_footer)
        poweredByFooter?.setOnClickListener {
            UrlHelper.openInBrowser(this, ETHYCA_URL.toUri())
        }
    }

    /**
     * Load the privacy experience from Janus
     */
    private fun loadPrivacyExperience() {
        // Show loading state
        showLoadingState()

        try {
            // Get the current experience from Janus (already fetched during initialization)
            currentExperience = JanusProvider.shared.currentExperience

            if (currentExperience != null) {
                updateUI(currentExperience!!)
            } else {
                showErrorState("No privacy experience available")
            }
        } catch (e: Exception) {
            showErrorState(e.message ?: "Failed to load privacy experience")
        }
    }

    /**
     * Update the UI with the privacy experience data
     */
    private fun updateUI(experience: PrivacyExperienceItem) {
        // Get the title and description from the experience config's default translation and cache it
        translatedExperienceConfig = getLocalizedTranslation(experience)
        
        // Resolve translations for all notices to avoid duplication
        allNotices = flattenNotices(experience.privacyNotices ?: emptyList())

        // Update title and description
        binding.privacyExperienceTitle.text = translatedExperienceConfig?.title ?: "Privacy Settings"

        // Use our new HTML handling for the description
        val descriptionText = translatedExperienceConfig?.description ?: "Please review your privacy choices."
        binding.privacyExperienceDescription.setHtmlContent(
            htmlContent = descriptionText,
            vendorCount = experience.vendorCount
        )

        // Log the Privacy Experience UI setup with structured metadata
        Janus.log("Showing Privacy Experience UI", metadata = mapOf(
            "notices" to allNotices.map { it.title }.filter { it.isNotEmpty() }.joinToString(", "),
            "consent" to Janus.internalConsent.toString()
        ), level = LogLevel.DEBUG)

        // Initialize adapter with notices (includes children flattened)
        noticeAdapter.setNotices(allNotices)

        // Configure action buttons
        setupActionButtons(experience, translatedExperienceConfig)

        // Show content
        showContentState()
        
        // Record that notices were served now that the content is visible to the user
        NoticesServedAPI().recordNoticesServed(
            experience,
            allNotices,
            translatedExperienceConfig?.privacyExperienceConfigHistoryId ?: ""
        ) { response ->
            // Store the served notice history ID for use in PrivacyPreferencesAPI
            servedNoticeHistoryId = response?.servedNoticeHistoryId
        }
    }

    /**
     * Show the primary save button and hide the secondary one
     */
    private fun showPrimarySaveButton() {
        binding.savePreferencesButtonSecondary.visibility = View.GONE
        binding.savePreferencesButtonPrimary.visibility = View.VISIBLE
    }

    /**
     * Show the secondary save button and hide the primary one
     */
    private fun showSecondarySaveButton() {
        binding.savePreferencesButtonPrimary.visibility = View.GONE
        binding.savePreferencesButtonSecondary.visibility = View.VISIBLE
    }

    /**
     * Configure the action buttons based on experience data
     */
    private fun setupActionButtons(experience: PrivacyExperienceItem, translation: ExperienceConfigTranslation?) {
        val noticesCount = experience.privacyNotices?.size ?: 0
        val allNoticesAreNoticeOnly = experience.privacyNotices?.all { it.consentMechanism == "notice_only" } ?: false

        // Case 1: No privacy notices or all are notice_only - show only acknowledge button
        if (noticesCount == 0 || allNoticesAreNoticeOnly) {
            // Hide other buttons
            binding.acceptAllButton.visibility = View.GONE
            binding.rejectAllButton.visibility = View.GONE

            // Show primary save button as acknowledge (filled style when it's the only button)
            showPrimarySaveButton()
            binding.savePreferencesButtonPrimary.text = translation?.acknowledgeButtonLabel ?: "OK"
            binding.savePreferencesButtonPrimary.setOnClickListener {
                acknowledgeAll()
                finish()
            }
        }
        // Case 2: Exactly one privacy notice (not notice_only) - show only save button
        else if (noticesCount == 1) {
            // Hide other buttons
            binding.acceptAllButton.visibility = View.GONE
            binding.rejectAllButton.visibility = View.GONE

            // Show primary save button (filled style when it's the only button)
            showPrimarySaveButton()
            binding.savePreferencesButtonPrimary.text = translation?.saveButtonLabel ?: "Save"
            binding.savePreferencesButtonPrimary.setOnClickListener {
                savePreferences()
                finish()
            }
        }
        // Case 3: Multiple privacy notices (at least one not notice_only) - show all three buttons
        else {
            // Configure Accept All button
            binding.acceptAllButton.visibility = View.VISIBLE
            binding.acceptAllButton.text = translation?.acceptButtonLabel ?: "Opt in to all"
            binding.acceptAllButton.setOnClickListener {
                acceptAll()
                finish()
            }

            // Configure Reject All button
            binding.rejectAllButton.visibility = View.VISIBLE
            binding.rejectAllButton.text = translation?.rejectButtonLabel ?: "Opt out of all"
            binding.rejectAllButton.setOnClickListener {
                rejectAll()
                finish()
            }

            // Configure Save button - use secondary style (outlined) when other buttons are visible
            showSecondarySaveButton()
            binding.savePreferencesButtonSecondary.text = translation?.saveButtonLabel ?: "Save"
            binding.savePreferencesButtonSecondary.setOnClickListener {
                savePreferences()
                finish()
            }
        }
    }

    /**
     * Gets the localized translation based on device language
     */
    private fun getLocalizedTranslation(experience: PrivacyExperienceItem): ExperienceConfigTranslation? {
        val translations = experience.experienceConfig?.translations ?: return null

        // Use TranslationMatcher to find the best matching translation based on device language
        return TranslationMatcher.find(translations)
    }

    /**
     * Apply consent changes and notify
     * This is a shared helper method that handles consent changes consistently
     *
     * @param changes The consent changes to apply
     * @param closeMethod The method used to close the experience (for events)
     * @param consentMethod The method used to record consent
     */
    private fun applyConsentChangesAndNotify(changes: Map<String, Boolean>, closeMethod: String, consentMethod: ConsentMethod) {
        // Log the action
        Janus.log("$closeMethod: $changes", level = LogLevel.DEBUG)

        // Fire ExperienceSelectionUpdatingEvent before saving
        val updatingEvent = ExperienceSelectionUpdatingEvent(changes)
        Janus.notifyEventListeners(updatingEvent)

        // TODO: Placeholder for fides_string once this view supports TCF
        val fidesString = ""

        // Apply the consent changes using the consent manager
        consentManager.setConsent(
            values = changes,
            versionHash = Janus.currentExperience?.meta?.versionHash ?: "",
            fidesString = fidesString,
            consentMethod = consentMethod
        )

        // Save privacy preferences to Fides asynchronously with notices
        PrivacyPreferencesAPI().savePrivacyPreferences(
            consentChanges = changes, 
            consentMethod = consentMethod, 
            fidesString = fidesString, 
            notices = allNotices,
            privacyExperienceConfigHistoryId = translatedExperienceConfig?.privacyExperienceConfigHistoryId,
            servedNoticeHistoryId = servedNoticeHistoryId
        )

        // Fire ExperienceSelectionUpdatedEvent after saving
        val updatedEvent = ExperienceSelectionUpdatedEvent()
        Janus.notifyEventListeners(updatedEvent)

        // Fire ExperienceClosedEvent with the close method
        val closedEvent = ExperienceClosedEvent(closeMethod)
        Janus.notifyEventListeners(closedEvent)
    }

    /**
     * Accept all consents
     */
    private fun acceptAll() {
        // Set all values to true
        val acceptedValues = allNotices.associate { notice ->
            notice.noticeKey to true
        }

        // Apply consent changes using the shared helper
        applyConsentChangesAndNotify(
            changes = acceptedValues,
            closeMethod = "accept_all",
            consentMethod = ConsentMethod.ACCEPT
        )

        // Set eventFiredOnDismiss flag to prevent duplicate events
        eventFiredOnDismiss = true
    }

    /**
     * Reject all consents except required ones
     */
    private fun rejectAll() {
        // Create a map with all non-required consents set to false
        val rejectedValues = allNotices.associate { notice ->
            // Set to true only if it's a required notice (notice_only)
            val isRequired = notice.consentMechanism == "notice_only"
            notice.noticeKey to isRequired
        }

        // Apply consent changes using the shared helper
        applyConsentChangesAndNotify(
            changes = rejectedValues,
            closeMethod = "reject_all",
            consentMethod = ConsentMethod.REJECT
        )

        // Set eventFiredOnDismiss flag to prevent duplicate events
        eventFiredOnDismiss = true
    }

    /**
     * Save the user's current preferences
     */
    private fun savePreferences() {
        // Get current consent values from adapter
        val consentValues = noticeAdapter.getConsentValues()

        // Apply consent changes using the shared helper
        applyConsentChangesAndNotify(
            changes = consentValues,
            closeMethod = "save_button",
            consentMethod = ConsentMethod.SAVE
        )

        // Set eventFiredOnDismiss flag to prevent duplicate events
        eventFiredOnDismiss = true
    }

    /**
     * Acknowledge the privacy experience
     * Used when there are no privacy notices or all are notice_only
     */
    private fun acknowledgeAll() {
        if (allNotices.isEmpty()) {
            // No notices, just acknowledge with empty map
            applyConsentChangesAndNotify(
                changes = emptyMap(),
                closeMethod = "acknowledged",
                consentMethod = ConsentMethod.ACKNOWLEDGE
            )
        } else {
            // Set all notice_only consents to true
            val acknowledgedValues = allNotices.associate { notice ->
                notice.noticeKey to true
            }

            // Apply consent changes using the shared helper
            applyConsentChangesAndNotify(
                changes = acknowledgedValues,
                closeMethod = "acknowledged",
                consentMethod = ConsentMethod.ACKNOWLEDGE
            )
        }

        // Set eventFiredOnDismiss flag to prevent duplicate events
        eventFiredOnDismiss = true
    }

    /**
     * Show the loading state
     */
    private fun showLoadingState() {
        binding.progressBar.visibility = View.VISIBLE
        binding.errorView.visibility = View.GONE
    }

    /**
     * Show the error state
     */
    private fun showErrorState(message: String) {
        binding.progressBar.visibility = View.GONE
        binding.errorView.visibility = View.VISIBLE
        binding.errorTextView.text = message
    }

    /**
     * Show the content state
     */
    private fun showContentState() {
        binding.progressBar.visibility = View.GONE
        binding.errorView.visibility = View.GONE
    }

    /**
     * Get all notices including children recursively
     * flattening the notices to the matched translation
     * Only includes notices with valid (non-empty) noticeKeys
     */
    private fun flattenNotices(notices: List<PrivacyNotice>): List<TranslatedPrivacyNotice> {
        val result = mutableListOf<TranslatedPrivacyNotice>()
        
        for (notice in notices) {
            // Only include notices that have a valid noticeKey
            if (!notice.noticeKey.isNullOrEmpty()) {
                // Resolve translation for this notice
                val resolvedTranslation = notice.translations?.let { translations ->
                    TranslationMatcher.find(translations)
                }
                result.add(TranslatedPrivacyNotice(notice, resolvedTranslation))
            }
            
            // Recursively resolve children
            notice.children?.let { children ->
                result.addAll(flattenNotices(children))
            }
        }

        return result
    }

    /**
     * Handle dismissal with a specific close method
     * @param closeMethod The method used to close the experience (e.g., "close_button", "swipe_dismiss")
     */
    private fun handleDismiss(closeMethod: String) {
        // Only fire event if we haven't already
        if (!eventFiredOnDismiss) {
            // Extract notice keys that require consent
            val noticeKeys = allNotices.map { it.noticeKey }

            // Check if user has existing consent for any of these notice keys
            val hasExistingConsent = noticeKeys.any { key ->
                Janus.internalConsent.keys.contains(key)
            }

            // If no existing consent for any of the notice keys, apply defaults
            if (!hasExistingConsent) {
                // No existing consent, use default values from privacy notices
                val defaultConsent = mutableMapOf<String, Boolean>()

                // Look up default values for all notices
                for (notice in allNotices) {
                    // Imply consent to true if defaultPreference is "opt_in" or "acknowledge"
                    val defaultValue = notice.defaultPreference == "opt_in" || notice.defaultPreference == "acknowledge"
                    defaultConsent[notice.noticeKey] = defaultValue
                }

                // Apply the default consent values with dismiss as the consent method
                applyConsentChangesAndNotify(defaultConsent, closeMethod, ConsentMethod.DISMISS)
            } else {
                // Just fire an ExperienceClosedEvent
                val closeEvent = ExperienceClosedEvent(closeMethod)
                Janus.notifyEventListeners(closeEvent)
            }

            // Mark that we've fired an event on dismissal
            eventFiredOnDismiss = true
        }
    }

    /**
     * Handle when the user swipes to dismiss the sheet
     */
    override fun finish() {
        // If we're finishing but eventFiredOnDismiss is still false,
        // assume it's a swipe dismiss and handle it
        if (!eventFiredOnDismiss) {
            handleDismiss("swipe_dismiss")
        }
        super.finish()
    }
}
