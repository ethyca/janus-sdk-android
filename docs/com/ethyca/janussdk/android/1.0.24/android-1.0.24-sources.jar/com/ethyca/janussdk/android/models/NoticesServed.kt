package com.ethyca.janussdk.android.models

import com.google.gson.annotations.SerializedName
import com.google.gson.TypeAdapter
import com.google.gson.stream.JsonReader
import com.google.gson.stream.JsonWriter
import com.google.gson.annotations.JsonAdapter

/**
 * Gson adapter for ServingComponent enum
 */
class ServingComponentAdapter : TypeAdapter<ServingComponent>() {
    override fun write(out: JsonWriter, value: ServingComponent?) {
        if (value == null) {
            out.nullValue()
        } else {
            out.value(value.value)
        }
    }

    override fun read(input: JsonReader): ServingComponent? {
        val value = input.nextString()
        return ServingComponent.values().find { it.value == value }
    }
}

/**
 * Enum for serving component values
 * This matches the ServingComponent enum from Fides
 */
@JsonAdapter(ServingComponentAdapter::class)
enum class ServingComponent(val value: String) {
    // OVERLAY("overlay") DEPRECATED ON THE BACKEND
    BANNER("banner"),
    MODAL("modal"),
    PRIVACY_CENTER("privacy_center"),
    TCF_OVERLAY("tcf_overlay"),  // TCF modal in this case
    TCF_BANNER("tcf_banner")
}

/**
 * Request body for the Notices Served API
 * Contains only the fields actually being sent
 */
data class NoticesServedRequest(
    @SerializedName("privacy_notice_history_ids") val privacyNoticeHistoryIds: List<String>,
    @SerializedName("browser_identity") val browserIdentity: BrowserIdentity,
    @SerializedName("privacy_experience_id") val privacyExperienceId: String,
    @SerializedName("privacy_experience_config_history_id") val privacyExperienceConfigHistoryId: String,
    @SerializedName("user_geography") val userGeography: String,
    @SerializedName("serving_component") val servingComponent: ServingComponent = ServingComponent.MODAL,
    @SerializedName("property_id") val propertyId: String?
)

/**
 * Response from the Notices Served API
 * Contains only the fields actually returned
 */
data class NoticesServedResponse(
    @SerializedName("privacy_notice_history_ids") val privacyNoticeHistoryIds: List<String>,
    @SerializedName("served_notice_history_id") val servedNoticeHistoryId: String
) 