package com.ethyca.janussdk.android.webview

import android.content.Context
import android.webkit.WebView
import com.ethyca.janussdk.android.Janus
import com.ethyca.janussdk.android.LogLevel
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap // Use thread-safe map for caching

/**
 * Utility object to load JavaScript files from the app's assets and inject them into WebViews.
 * Mirrors the functionality of the iOS JSResourceLoader.
 */
object JSResourceLoader {
    // Files are expected to be under assets/javascript/
    private const val JS_ASSET_PATH = "javascript"

    // Default loaded JavaScript file names in the order they should be loaded
    // Matches the iOS order
    private val jsFiles = listOf(
        "native.js",
        "utils.js",
        "bridge.js",
        "messaging.js",
        "consent.js"
    )

    // Cached JavaScript content to avoid reading from disk repeatedly
    // Use ConcurrentHashMap for thread safety, although access might often be from main thread
    private val cachedScripts: MutableMap<String, String> = ConcurrentHashMap()

    /**
     * Gets the content of a JavaScript file from the app's assets.
     *
     * @param context Context required to access AssetManager.
     * @param filename Name of the JavaScript file (e.g., "native.js").
     * @return Content of the file as a String, or null if not found or an error occurs.
     */
    fun getJavaScriptContent(context: Context, filename: String): String? {
        // Check if the content is already cached
        cachedScripts[filename]?.let {
            Janus.log("Using cached JavaScript content for $filename", level = LogLevel.DEBUG)
            return it
        }

        // Construct the full path within the assets folder
        val assetFilePath = "$JS_ASSET_PATH/$filename"

        return try {
            Janus.log("Loading JavaScript content for $filename from assets ($assetFilePath)", level = LogLevel.DEBUG)
            // Access AssetManager via context
            val content = context.assets.open(assetFilePath).bufferedReader().use { it.readText() }
            // Cache the content for future use
            cachedScripts[filename] = content
            Janus.log("Successfully loaded and cached $filename", level = LogLevel.DEBUG)
            content
        } catch (e: IOException) {
            Janus.log("Error reading JavaScript file '$filename' from assets path '$assetFilePath'", level = LogLevel.ERROR, error = e)
            null // Return null on error, similar to Swift's nil
        }
    }

    /**
     * Injects a specific JavaScript file's content into a WebView.
     * Note: Injection happens asynchronously via evaluateJavascript.
     *
     * @param context Context required to load the script content.
     * @param filename Name of the JavaScript file.
     * @param webView The WebView to inject the script into.
     */
    fun injectScript(context: Context, filename: String, webView: WebView) {
        val scriptContent = getJavaScriptContent(context, filename)
        if (scriptContent != null) {
            // Use evaluateJavascript for efficient and asynchronous execution
            // Prepending "javascript:" is generally not needed for evaluateJavascript
             webView.evaluateJavascript(scriptContent) { result ->
                 Janus.log("Successfully evaluated JavaScript from $filename. Result: $result", level = LogLevel.DEBUG)
             }
             Janus.log("Requested injection of script $filename into WebView", level = LogLevel.DEBUG)
        } else {
            Janus.log("Failed to inject script $filename: content not available.", level = LogLevel.ERROR)
        }
    }

    /**
     * Injects all predefined JavaScript files into a WebView in the specified order.
     *
     * @param context Context required to load the script content.
     * @param webView The WebView to inject scripts into.
     */
    fun injectAllScripts(context: Context, webView: WebView) {
        Janus.log("Injecting all scripts into WebView...", level = LogLevel.INFO)
        jsFiles.forEach { filename ->
            injectScript(context, filename, webView)
        }
        Janus.log("Finished requesting injection of all scripts.", level = LogLevel.INFO)
    }
} 