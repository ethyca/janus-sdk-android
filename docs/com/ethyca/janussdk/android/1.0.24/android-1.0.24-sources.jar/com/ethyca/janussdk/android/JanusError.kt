package com.ethyca.janussdk.android

import com.ethyca.janussdk.android.models.IPLocationResponse

/**
 * Error types that can occur during Janus operations
 */
sealed class JanusError(message: String) : Exception(message) {
    /**
     * Invalid SDK configuration
     */
    class InvalidConfiguration : JanusError("Invalid Janus configuration")
    
    /**
     * SDK not initialized when an operation requires initialization
     */
    class NotInitialized : JanusError("Janus SDK has not been initialized")
    
    /**
     * Network error occurred during API request
     */
    class NetworkError(override val cause: Throwable) : JanusError("Network error: ${cause.message}")
    
    /**
     * Authentication failed with the API
     */
    class AuthenticationFailed : JanusError("Authentication failed with the API")
    
    /**
     * Generic API error
     */
    class ApiError(errorMessage: String) : JanusError("API error: $errorMessage")
    
    /**
     * Region code is invalid or not supported
     */
    class InvalidRegion : JanusError("Invalid region code provided")
    
    /**
     * Experience data is invalid or missing
     */
    class InvalidExperience : JanusError("Invalid or missing privacy experience data")
    
    /**
     * IP location detection failed with invalid or empty data
     */
    class IPLocationFailed(result: IPLocationResponse) :
        JanusError("IP location detection failed or returned invalid data") {
        val ipLocationResponse: IPLocationResponse

        init {
            this.ipLocationResponse = result
        }
    }
    
    /**
     * No region provided and IP location detection failed or disabled
     */
    class NoRegionProvidedIPLocationFailed(result: IPLocationResponse?) :
        JanusError("No region provided and IP location detection failed") {
        val ipLocationResponse: IPLocationResponse?

        init {
            this.ipLocationResponse = result
        }
    }

    /**
     * No region provided and IP location detection failed or disabled
     */
    class NoRegionProvidedIPLocationFalse : JanusError("No region provided and IP location was disabled")
} 