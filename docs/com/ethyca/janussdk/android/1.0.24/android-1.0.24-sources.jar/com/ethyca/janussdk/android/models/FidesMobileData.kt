package com.ethyca.janussdk.android.models

import com.google.gson.annotations.SerializedName

/**
 * Structure for mobile data in privacy experience
 */
data class FidesMobileData(
    @SerializedName("IABGPP_HDR_Version") val headerVersion: String? = null,
    @SerializedName("IABGPP_HDR_Sections") val headerSections: String? = null,
    @SerializedName("IABGPP_HDR_GppString") val headerGppString: String? = null,
    @SerializedName("IABGPP_GppSID") val gppSid: String? = null,
    @SerializedName("IABGPP_7_String") val gppString: String? = null
)
