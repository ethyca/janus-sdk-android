package com.ethyca.janussdk.android.api

import com.ethyca.janussdk.android.Janus
import com.ethyca.janussdk.android.LogLevel
import com.ethyca.janussdk.android.consent.ConsentManager
import com.ethyca.janussdk.android.core.JanusProvider
import com.ethyca.janussdk.android.models.BrowserIdentity
import com.ethyca.janussdk.android.models.NoticesServedRequest
import com.ethyca.janussdk.android.models.NoticesServedResponse
import com.ethyca.janussdk.android.models.PrivacyExperienceItem
import com.ethyca.janussdk.android.models.TranslatedPrivacyNotice
import com.ethyca.janussdk.android.utils.ApiRoutes
import com.google.gson.Gson
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executors

/**
 * API client for recording that notices were served to the user
 */
open class NoticesServedAPI {

    /**
     * Thread pool for network requests
     */
    private val executorService = Executors.newCachedThreadPool()

    /**
     * Creates connection to URL
     * @param url The URL to connect to
     * @return HttpURLConnection
     */
    protected open fun createConnection(url: URL): HttpURLConnection {
        return url.openConnection() as HttpURLConnection
    }

    /**
     * Record that notices were served to the user when privacy experience is shown
     *
     * @param privacyExperience The privacy experience that was shown to the user
     * @param translatedNotices The already translated privacy notices
     * @param privacyExperienceConfigHistoryId The privacy experience config history ID from the translated config
     * @param completion Optional completion handler - receives NoticesServedResponse on success, null on failure
     */
    fun recordNoticesServed(
        privacyExperience: PrivacyExperienceItem,
        translatedNotices: List<TranslatedPrivacyNotice>,
        privacyExperienceConfigHistoryId: String,
        completion: ((NoticesServedResponse?) -> Unit)? = null
    ) {
        // Get configuration from JanusProvider
        val configuration = JanusProvider.configuration
        
        // Check if notices served saving is enabled
        if (!configuration.saveNoticesServedToFides) {
            Janus.log("Notices served recording is disabled", level = LogLevel.DEBUG)
            completion?.invoke(null) // Return null since it's intentionally disabled
            return
        }

        // Check if we have the required data
        if (privacyExperience.id.isNullOrEmpty()) {
            Janus.log("No privacy experience ID available for notices served", level = LogLevel.WARNING)
            completion?.invoke(null)
            return
        }

        if (translatedNotices.isEmpty()) {
            Janus.log("No translated privacy notices available for notices served", level = LogLevel.DEBUG)
            completion?.invoke(null)
            return
        }
        
        // Extract privacy notice history IDs from already translated notices
        val privacyNoticeHistoryIds = translatedNotices.mapNotNull { it.privacyNoticeHistoryId }
        
        if (privacyNoticeHistoryIds.isEmpty()) {
            Janus.log("No valid privacy notice history IDs to record as served", level = LogLevel.DEBUG)
            completion?.invoke(null)
            return
        }

        // Create consent manager to get device ID
        val consentManager = ConsentManager()

        // Create the request with the correct structure
        val request = NoticesServedRequest(
            privacyNoticeHistoryIds = privacyNoticeHistoryIds,
            browserIdentity = BrowserIdentity(
                fidesUserDeviceId = consentManager.getFidesUserDeviceId(),
                externalId = JanusProvider.externalId
            ),
            privacyExperienceId = privacyExperience.id,
            privacyExperienceConfigHistoryId = privacyExperienceConfigHistoryId,
            userGeography = Janus.region.replace("-", "_").lowercase(), // Backend expects lowercase with underscores
            propertyId = configuration.propertyId.ifEmpty { null }
        )

        // Send the request
        sendNoticesServedRequest(request, completion)
    }

    /**
     * Send notices served request asynchronously
     * @param request The notices served request to send
     * @param completion Optional completion handler - receives NoticesServedResponse on success, null on failure
     */
    private fun sendNoticesServedRequest(
        request: NoticesServedRequest,
        completion: ((NoticesServedResponse?) -> Unit)? = null
    ) {
        executorService.submit {
            try {
                // Get API host from configuration
                val apiHost = JanusProvider.configuration.apiHost
                
                // Create URL for the notices served endpoint
                val url = URL("$apiHost${ApiRoutes.NOTICES_SERVED.path}")
                
                Janus.log("Recording notices served", level = LogLevel.DEBUG, metadata = mapOf(
                    "url" to url.toString(),
                    "propertyId" to (request.propertyId ?: "null"),
                    "userGeography" to request.userGeography,
                    "privacyExperienceId" to request.privacyExperienceId,
                    "noticesCount" to request.privacyNoticeHistoryIds.size.toString(),
                    "fidesUserDeviceId" to request.browserIdentity.fidesUserDeviceId
                ))

                // Create and configure the connection
                val connection = createConnection(url)
                connection.requestMethod = "PATCH"
                connection.setRequestProperty("Content-Type", "application/json")
                connection.setRequestProperty("Accept", "application/json")
                connection.setRequestProperty("Fides-Client", "Janus-SDK")
                connection.doOutput = true

                try {
                    // Convert request to JSON
                    val gson = Gson()
                    val jsonString = gson.toJson(request)

                    // Write the request body
                    OutputStreamWriter(connection.outputStream, StandardCharsets.UTF_8).use { writer ->
                        writer.write(jsonString)
                        writer.flush()
                    }

                    // Execute request and handle response
                    val responseCode = connection.responseCode

                    // Handle HTTP response codes
                    if (responseCode >= 200 && responseCode < 300) {
                        // Success - try to parse response
                        val responseData = connection.inputStream?.let { inputStream ->
                            BufferedReader(InputStreamReader(inputStream)).use { reader ->
                                reader.readText()
                            }
                        }

                        val response = if (!responseData.isNullOrEmpty()) {
                            try {
                                gson.fromJson(responseData, NoticesServedResponse::class.java)
                            } catch (e: Exception) {
                                Janus.log("Failed to parse notices served response", level = LogLevel.WARNING, error = e)
                                null
                            }
                        } else {
                            null
                        }

                        Janus.log("Notices served recorded successfully", level = LogLevel.DEBUG, metadata = mapOf(
                            "statusCode" to responseCode.toString(),
                            "privacyExperienceId" to request.privacyExperienceId,
                            "servedNoticeHistoryId" to (response?.servedNoticeHistoryId ?: "null")
                        ))
                        completion?.invoke(response)
                    } else {
                        // Error response
                        val errorStream = connection.errorStream ?: connection.inputStream
                        val errorMessage = errorStream?.let {
                            BufferedReader(InputStreamReader(it)).use { reader ->
                                reader.readText()
                            }
                        } ?: "No error message"

                        Janus.log("Failed to record notices served", level = LogLevel.WARNING, metadata = mapOf(
                            "statusCode" to responseCode.toString(),
                            "errorMessage" to errorMessage,
                            "privacyExperienceId" to request.privacyExperienceId,
                            "requestPayload" to jsonString,
                            "url" to url.toString()
                        ))
                        completion?.invoke(null)
                    }

                } catch (e: Exception) {
                    // Handle network errors
                    Janus.log("Network error recording notices served", level = LogLevel.WARNING, error = e)
                    completion?.invoke(null)
                } finally {
                    connection.disconnect()
                }
                
            } catch (e: Exception) {
                // Handle URL creation or other errors
                Janus.log("Error creating notices served request", level = LogLevel.WARNING, error = e)
                completion?.invoke(null)
            }
        }
    }
} 