package com.ethyca.janussdk.android.core

import android.content.Context
import com.ethyca.janussdk.android.JanusConfiguration

/**
 * Provider class for JanusSDK implementation
 * 
 * This class acts as a factory for creating the implementation instance,
 * allowing for dependency injection and easier testing.
 */
object JanusProvider {
    /**
     * Private instance of the JanusImplementation used by the shared instance
     */
    private var _implementation: JanusInterface? = null
    
    /**
     * The application context used by the SDK
     */
    private var _applicationContext: Context? = null
    
    /**
     * The configuration used by the SDK
     */
    private var _configuration: JanusConfiguration? = null

    /**
     * External ID for the current user — set after login, cleared on logout.
     * Included in all BrowserIdentity payloads sent to the Fides API.
     */
    var externalId: String? = null

    /**
     * Set the application context used by the SDK
     *
     * @param context The application context
     */
    fun setApplicationContext(context: Context) {
        _applicationContext = context
    }
    
    /**
     * Set the configuration used by the SDK
     *
     * @param configuration The JanusConfiguration
     */
    fun setConfiguration(configuration: JanusConfiguration) {
        _configuration = configuration
    }
    
    /**
     * Access to the application context for internal SDK components
     * @throws IllegalStateException if initialize hasn't been called
     */
    internal val applicationContext: Context
        get() {
            return _applicationContext ?: throw IllegalStateException(
                "Application context must be set before accessing Janus. Did you call Janus.initialize()?"
            )
        }
    
    /**
     * Access to the configuration for internal SDK components
     * @throws IllegalStateException if initialize hasn't been called
     */
    internal val configuration: JanusConfiguration
        get() {
            return _configuration ?: throw IllegalStateException(
                "Configuration must be set before accessing Janus. Did you call Janus.initialize()?"
            )
        }
    
    /**
     * Factory method for creating default implementation
     */
    private fun createDefaultImplementation(): JanusInterface {
        return JanusImplementation()
    }
    
    /**
     * Shared singleton instance for convenient access in production code
     */
    val shared: JanusInterface
        get() {
            if (_implementation != null) {
                return _implementation!!
            }
            
            // Make sure we have a context before trying to create the implementation
            val defaultImpl = createDefaultImplementation()
            _implementation = defaultImpl
            return defaultImpl
        }
    
    /**
     * Reset the implementation to the default (real) JanusImplementation
     * This is typically called during test tearDown
     */
    fun resetToDefault() {
        _implementation = createDefaultImplementation()
    }
    
    /**
     * For testing purposes - set a specific implementation
     *
     * @param implementation The implementation to use
     */
    fun setupForTesting(implementation: JanusInterface) {
        _implementation = implementation
    }
} 