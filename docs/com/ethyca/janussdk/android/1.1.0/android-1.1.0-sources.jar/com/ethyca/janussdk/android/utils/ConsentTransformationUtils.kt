package com.ethyca.janussdk.android.utils

import com.ethyca.janussdk.android.models.ConsentFlagType
import com.ethyca.janussdk.android.models.ConsentMechanism
import com.ethyca.janussdk.android.models.ConsentNonApplicableFlagMode
import com.ethyca.janussdk.android.models.PrivacyNotice
import com.ethyca.janussdk.android.models.TranslatedPrivacyNotice
import com.ethyca.janussdk.android.models.UserConsentPreference

/**
 * Utility functions for transforming consent values between boolean and consent mechanism formats
 * Mirrors the transformation logic from FidesJS shared-consent-utils.ts
 */
object ConsentTransformationUtils {

  /**
   * Transforms a boolean consent value to a UserConsentPreference based on the consent mechanism
   * Mirrors the transformConsentToFidesUserPreference function from FidesJS
   * @param consented The boolean consent value
   * @param consentMechanism The mechanism for collecting consent (optional)
   * @return The corresponding UserConsentPreference
   */
  fun transformConsentToUserPreference(
          consented: Boolean,
          consentMechanism: ConsentMechanism? = null
  ): UserConsentPreference {
    return if (consented) {
      if (consentMechanism == ConsentMechanism.NOTICE_ONLY) {
        UserConsentPreference.ACKNOWLEDGE
      } else {
        UserConsentPreference.OPT_IN
      }
    } else {
      UserConsentPreference.OPT_OUT
    }
  }

  /** Consent saved on Acknowledge, matching FidesJS: the current toggles, with notice_only always on */
  fun acknowledgedConsent(
          notices: List<TranslatedPrivacyNotice>,
          toggles: Map<String, Boolean>
  ): Map<String, Boolean> =
          notices.filter { it.noticeKey.isNotEmpty() }.associate { notice ->
            val isNoticeOnly = notice.consentMechanism == ConsentMechanism.NOTICE_ONLY.value
            notice.noticeKey to (isNoticeOnly || (toggles[notice.noticeKey] ?: false))
          }

  /** The privacy-preferences value for a notice, given its raw consent mechanism string */
  fun preferenceValue(consented: Boolean, consentMechanism: String?): String =
          transformConsentToUserPreference(
                  consented,
                  ConsentMechanism.values().find { it.value == consentMechanism }
          ).value

  /**
   * Transforms a UserConsentPreference string to a boolean value Mirrors the
   * transformUserPreferenceToBoolean function from FidesJS
   * @param preference The UserConsentPreference to convert
   * @return The corresponding boolean value
   */
  fun transformUserPreferenceToBoolean(preference: UserConsentPreference?): Boolean {
    return when (preference) {
      UserConsentPreference.OPT_OUT -> false
      UserConsentPreference.OPT_IN -> true
      UserConsentPreference.ACKNOWLEDGE -> true
      UserConsentPreference.NOT_APPLICABLE -> false
      null -> false
    }
  }

  /**
   * Applies consent flag type overrides to transform boolean consent values to the appropriate
   * external format Mirrors the applyOverridesToConsent function from FidesJS
   * @param booleanConsent Map of boolean consent values
   * @param flagType The format to return values in
   * @param privacyNotices Privacy notices to determine consent mechanisms (required for
   * consent_mechanism format)
   * @return Map with values in the requested format (Any to support both Boolean and String) Note:
   * This function is deterministic - same inputs always produce same outputs
   */
  fun applyOverridesToConsent(
          booleanConsent: Map<String, Boolean>,
          flagType: ConsentFlagType,
          privacyNotices: List<PrivacyNotice>? = null
  ): Map<String, Any> {

    // For boolean flag type, return as-is
    if (flagType == ConsentFlagType.BOOLEAN) {
      return booleanConsent.mapValues { it.value as Any }
    }

    // For consent mechanism flag type, transform to UserConsentPreference strings
    val transformedConsent: MutableMap<String, Any> = mutableMapOf()

    // Create a mapping of notice keys to consent mechanisms for efficient lookup
    val consentMechanismMap =
            privacyNotices
                    ?.mapNotNull { notice ->
                      val noticeKey = notice.noticeKey
                      val mechanismString = notice.consentMechanism
                      if (noticeKey != null && mechanismString != null) {
                        val mechanism = ConsentMechanism.fromString(mechanismString)
                        noticeKey to mechanism
                      } else {
                        null
                      }
                    }
                    ?.toMap()
                    ?: emptyMap()

    for ((noticeKey, booleanValue) in booleanConsent) {
      val mechanism = consentMechanismMap[noticeKey]
      val preference =
              transformConsentToUserPreference(
                      consented = booleanValue,
                      consentMechanism = mechanism
              )
      transformedConsent[noticeKey] = preference.value
    }

    return transformedConsent
  }

  /**
   * Handles non-applicable privacy notices based on the configured flag mode
   * Mirrors the handleNonApplicableNotices functionality from FidesJS
   * @param consent The consent values to modify
   * @param nonApplicableNotices List of notice keys that are not applicable
   * @param flagType The target format for normalization
   * @param mode Whether to include or omit non-applicable notices
   * @return Modified consent map with non-applicable notices handled according to the mode
   */
  fun handleNonApplicableNotices(
          consent: Map<String, Any>,
          nonApplicableNotices: List<String>,
          flagType: ConsentFlagType,
          mode: ConsentNonApplicableFlagMode = ConsentNonApplicableFlagMode.OMIT
  ): Map<String, Any> {
    if (nonApplicableNotices.isEmpty()) {
      return consent
    }

    val result = consent.toMutableMap()

    if (mode == ConsentNonApplicableFlagMode.INCLUDE) {
      // Add non-applicable notices with appropriate values
      for (key in nonApplicableNotices) {
        val value: Any = if (flagType == ConsentFlagType.CONSENT_MECHANISM) {
          UserConsentPreference.NOT_APPLICABLE.value // "not_applicable"
        } else {
          true
        }
        result[key] = value
      }
    } else {
      // Remove non-applicable notices
      for (key in nonApplicableNotices) {
        result.remove(key)
      }
    }

    return result
  }

  // Validation & Debugging

  /**
   * Validates that the external consent format is consistent with the internal boolean format This
   * is useful for debugging and ensuring data integrity
   * @param internalConsent The internal boolean consent values
   * @param externalConsent The external consent values (from Janus.consent)
   * @param flagType The current consent flag type configuration
   * @return True if consistent, false if there are discrepancies
   */
  fun validateConsentConsistency(
          internalConsent: Map<String, Boolean>,
          externalConsent: Map<String, Any>,
          flagType: ConsentFlagType
  ): Boolean {
    // For boolean mode, external should contain the same boolean values
    if (flagType == ConsentFlagType.BOOLEAN) {
      for ((key, internalValue) in internalConsent) {
        val externalValue = externalConsent[key] as? Boolean ?: return false
        if (internalValue != externalValue) {
          return false
        }
      }
      return true
    }

    // For consent mechanism mode, we need to validate the transformation
    for ((key, internalValue) in internalConsent) {
      val externalValue = externalConsent[key] as? String ?: return false

      // Convert external string back to boolean and compare
      val preference = UserConsentPreference.fromString(externalValue)
      val convertedBoolean = transformUserPreferenceToBoolean(preference)
      if (internalValue != convertedBoolean) {
        return false
      }
    }

    return true
  }
}
