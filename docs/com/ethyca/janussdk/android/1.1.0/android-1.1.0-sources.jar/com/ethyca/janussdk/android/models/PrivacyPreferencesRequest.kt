package com.ethyca.janussdk.android.models

import com.google.gson.annotations.SerializedName

/**
 * Request body for the Privacy Preferences API
 */
data class PrivacyPreferencesRequest(
    @SerializedName("property_id") val propertyId: String,
    val source: String = "Janus SDK",
    @SerializedName("browser_identity") val browserIdentity: BrowserIdentity,
    val preferences: List<UserPreference>,
    @SerializedName("user_geography") val userGeography: String,
    @SerializedName("fides_string") val fidesString: String? = null,
    @SerializedName("privacy_experience_config_history_id") val privacyExperienceConfigHistoryId: String? = null,
    @SerializedName("served_notice_history_id") val servedNoticeHistoryId: String? = null,
    val method: String?,
    @SerializedName("request_origin") val requestOrigin: String? = null
)

/**
 * Browser identity containing the fides user device ID and optional external user ID.
 * When externalId is set, Fides links consent records to it, enabling DSR correlation
 * and multi-device consent merging.
 */
data class BrowserIdentity(
    @SerializedName("fides_user_device_id") val fidesUserDeviceId: String,
    @SerializedName("external_id") val externalId: String? = null
)

/**
 * Individual user preference for a privacy notice
 */
data class UserPreference(
    @SerializedName("privacy_notice_history_id") val privacyNoticeHistoryId: String,
    val preference: String // "opt_in", "opt_out", or "acknowledge"
) 