package com.ethyca.janussdk.android.webview

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import com.ethyca.janussdk.android.*
import com.ethyca.janussdk.android.consent.ConsentManager
import com.ethyca.janussdk.android.events.*
import com.ethyca.janussdk.android.models.ConsentMethod
import java.lang.ref.WeakReference

/**
 * Processes events received via FidesJSBridge for a specific WebView instance.
 * Handles tasks like updating consent based on WebView events.
 * Ensures listener callbacks happen on the main thread.
 *
 * @param webViewRef WeakReference to the associated WebView to avoid memory leaks.
 * @param bridgeRef WeakReference to the FidesJSBridge.
 * @param listener The listener to notify of processed JanusEvents.
 * @param context The context of the WebViewEventHandler.
 */
class WebViewEventHandler(
    private val webViewRef: WeakReference<WebView>,
    private val bridgeRef: WeakReference<FidesJSBridge>
) {
    companion object {
        private const val TAG = "WebViewEventHandler"
    }

    // Instantiate ConsentManager directly using the passed context
    private val consentManager = ConsentManager()

    // Handler to ensure listener callbacks are on the main thread
    private val mainHandler = Handler(Looper.getMainLooper())

    /**
     * Handles an event received from the bridge, forwards it to the listener,
     * and performs WebView-specific actions like triggering consent updates.
     *
     * This method is expected to be called from the bridge (potentially background thread).
     *
     * @param event The event processed by the bridge.
     */
    fun handleEvent(event: JanusEvent) {
        Janus.log("Handling event: ${event.eventType}", level = LogLevel.DEBUG)

        // Forward the event to the main Janus event system
        Janus.notifyEventListeners(event)

        // Perform actions based on event type
        when (event) {
            is WebViewFidesUpdatedEvent -> {
                Janus.log("WebView Fides Updated Event received, triggering consent update from WebView.", level = LogLevel.INFO)
                updateConsentFromWebView()
            }
            // Add other event-specific handling if needed
            else -> { /* No specific action needed for other events currently */ }
        }
    }

    /**
     * Initiates the process of retrieving consent values from the associated WebView's JavaScript.
     */
    private fun updateConsentFromWebView() {
        val webView = webViewRef.get()
        val bridge = bridgeRef.get()

        if (webView == null || bridge == null) {
            Janus.log("WebView or Bridge is null, cannot update consent from WebView.", level = LogLevel.WARNING)
            return
        }

        Janus.log("Requesting consent values from JS", level = LogLevel.DEBUG)
        bridge.getConsentValuesFromJS { consentMap, fidesString, consentMethod ->
            // This callback likely runs on the main thread (from evaluateJavascript)
            if (consentMap.isEmpty() && fidesString.isEmpty()) {
                Janus.log("A WebView was opened but no consent value was retrieved from it", level = LogLevel.WARNING)
                return@getConsentValuesFromJS
            }

            Janus.log("Received consent from WebView", metadata = mapOf(
                "consentMethod" to consentMethod,
                "consentMap" to consentMap.toString(),
                "fidesString" to fidesString
            ), level = LogLevel.DEBUG)

            // Capture before mutation — used below to skip propagation when values haven't
            // changed (echo guard for multi-WebView scenarios).
            val previousConsent = consentManager.getConsent()

            // Update ConsentManager with retrieved values
            consentManager.setConsent(
                values = consentMap,
                versionHash = Janus.currentExperience?.meta?.versionHash ?: "",
                fidesString = fidesString,
                consentMethod = ConsentMethod.fromString(consentMethod)
            )

            // Only propagate to other WebViews when values actually changed.
            // This provides a native-side loop break: if FidesJS in a second WebView
            // echoes back the same values after receiving an update, the echo stops here
            // rather than bouncing indefinitely.
            if (consentMap != previousConsent) {
                WebViewManager.propagateConsentToOtherWebViews(
                    consentValues = Janus.consent,
                    sourceWebView = webView,
                    consentMethod = consentMethod,
                    fidesString = fidesString,
                    tcfVersionHash = Janus.consentMetadata.versionHash
                )
            }

            // Create and fire a ConsentUpdatedFromWebViewEvent
            val event = ConsentUpdatedFromWebViewEvent(_values = consentMap, fidesString = fidesString, sourceWebView = webView)
            Janus.notifyEventListeners(event)
        }
    }

    /** Gets the associated WebView, if it still exists. */
    fun getWebView(): WebView? = webViewRef.get()

    /** Gets the associated FidesJSBridge, if it still exists. */
    fun getBridge(): FidesJSBridge? = bridgeRef.get()

}
