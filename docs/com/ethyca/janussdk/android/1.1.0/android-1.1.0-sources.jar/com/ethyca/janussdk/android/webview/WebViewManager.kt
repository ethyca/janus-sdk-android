package com.ethyca.janussdk.android.webview

import android.annotation.SuppressLint
import android.content.Context
import android.webkit.WebSettings
import android.webkit.WebView
import com.ethyca.janussdk.android.events.*
import com.ethyca.janussdk.android.Janus
import com.ethyca.janussdk.android.LogLevel
import java.util.WeakHashMap

/**
 * WebViewManager provides functionality for creating and managing WebViews with Janus consent capabilities.
 * It encapsulates the setup of the WebView with proper JavaScript and cookie configurations.
 */
class WebViewManager {

    companion object {
        private const val TAG = "WebViewManager"
        // Singleton instance
        private val instance = WebViewManager()

        /**
         * Configures the WebViewManager with settings from Janus.
         * Should be called during Janus initialization.
         * 
         * @param fidesEvents Whether Janus events should be propagated to FidesJS in WebViews
         */
        @JvmStatic
        fun configure(fidesEvents: Boolean) {
            instance.fidesEvents = fidesEvents
        }

        /**
         * Creates a WebView configured for Janus consent management
         * @param context The Android context
         * @param autoSyncOnStart Whether to enable initial synchronization when the webview loads (default is true)
         * @param tcfWebView Whether to create a WebView specifically configured for TCF (default is false)
         * @return A configured WebView ready to load content
         */
        @JvmStatic
        fun createConsentWebView(
            context: Context,
            autoSyncOnStart: Boolean = true,
            tcfWebView: Boolean = false
        ): WebView {
            return instance.createManagedWebView(context, autoSyncOnStart, tcfWebView).webView
        }

        /**
         * Creates a WebView configured for Janus consent management and returns an ID reference
         * This is useful for passing WebViews between components without direct references
         * @param context The Android context
         * @param autoSyncOnStart Whether to enable initial synchronization when the webview loads (default is true)
         * @param tcfWebView Whether to create a WebView specifically configured for TCF (default is false)
         * @return A unique ID that can be used to retrieve the WebView later
         */
        @JvmStatic
        fun createConsentWebViewWithId(
            context: Context,
            autoSyncOnStart: Boolean = true,
            tcfWebView: Boolean = false
        ): String {
            return instance.createManagedWebView(context, autoSyncOnStart, tcfWebView).id
        }

        /**
         * Retrieves a managed WebView by ID reference
         * @param webViewId The ID returned by createConsentWebViewWithId
         * @return ManagedWebView if found, null otherwise
         */
        @JvmStatic
        internal fun getWebView(webViewId: String): ManagedWebView? {
            return instance.managedWebViews.find { it.id == webViewId }
        }

        /**
         * Removes a webview from management when it's no longer needed
         * @param webView The webview to remove
         */
        @JvmStatic
        fun releaseConsentWebView(webView: WebView) {
            instance.removeWebView(webView)
        }

        /**
         * Propagates consent values to all managed WebViews except the specified source WebView.
         * Called internally when consent is updated from one WebView.
         *
         * @param consentValues The consent values to propagate.
         * @param sourceWebView The WebView to exclude from propagation.
         * @param consentMethod Optional consent method to use.
         * @param fidesString Optional fides string (TC string) to seed FidesJS with.
         * @param tcfVersionHash Optional TCF experience version hash, sent only alongside a fides string.
         */
        @JvmStatic
        internal fun propagateConsentToOtherWebViews(
            consentValues: Map<String, Any>,
            sourceWebView: WebView?,
            consentMethod: String? = null, // Default method handling might be in JS bridge
            fidesString: String? = null,
            tcfVersionHash: String? = null
        ) {
            Janus.log("Propagating consent update from source WebView to other WebViews.", level = LogLevel.DEBUG)
            instance.sendConsentToAllWebViews(consentValues, excluding = sourceWebView, consentMethod = consentMethod, fidesString = fidesString, tcfVersionHash = tcfVersionHash)
        }

        /**
         * Get the JavaScript bridge associated with a WebView
         * Used internally to access the bridge for specialized functionalities
         * 
         * @param webView The WebView to get the bridge for
         * @return The associated FidesJSBridge or null if not found
         */
        @JvmStatic
        internal fun getBridgeForWebView(webView: WebView): FidesJSBridge? {
            return instance.managedWebViews.find { it.webView == webView }?.bridge
        }
    }

    // Event listener ID for Janus events
    private var janusEventListenerId: String? = null
    
    // Whether to propagate Janus events to FidesJS in WebViews
    private var fidesEvents: Boolean = true

    // Data class to hold WebView, Bridge, and ID together
    internal data class ManagedWebView(
        val id: String,
        val webView: WebView,
        val bridge: FidesJSBridge
    )
    
    // Single robust collection for all WebView management (replaces WeakHashMap)
    private val managedWebViews = mutableListOf<ManagedWebView>()

    init {
        // Initialize the event listener for Janus events
        setupJanusEventListener()
    }

    /**
     * Sets up event listener for Janus events to propagate to FidesJS
     */
    private fun setupJanusEventListener() {
        janusEventListenerId = Janus.addConsentEventListener { event ->
            // Only propagate if the event has shouldPropagateToFidesJS set to true
            // and only if fidesEvents is enabled in the configuration
            if (fidesEvents && event.shouldPropagateToFidesJS) {
                propagateJanusEventToFidesJS(event)
            }
        }
    }

    /**
     * Propagates Janus events to FidesJS in all managed WebViews
     */
    private fun propagateJanusEventToFidesJS(event: JanusEvent) {
        // Map the Janus event to FidesJS event type
        val fidesEventType: String?
        val eventData = mutableMapOf<String, Any>()

        // Map native Janus events to their FidesJS equivalents
        when (event.eventType) {
            JanusEventType.EXPERIENCE_SHOWN -> {
                fidesEventType = FidesEventType.FIDES_UI_SHOWN.value
            }
            JanusEventType.EXPERIENCE_INTERACTION -> {
                fidesEventType = FidesEventType.FIDES_UI_CHANGED.value
                event.detail?.get("interaction")?.let { 
                    eventData["consent"] = it 
                }
            }
            JanusEventType.EXPERIENCE_CLOSED -> {
                fidesEventType = FidesEventType.FIDES_MODAL_CLOSED.value
                val extraDetails = mutableMapOf<String, Any>()
                event.detail?.get("closeMethod")?.let { 
                    extraDetails["consentMethod"] = it 
                }
                eventData["extraDetails"] = extraDetails
            }
            JanusEventType.EXPERIENCE_SELECTION_UPDATING -> {
                fidesEventType = FidesEventType.FIDES_UPDATING.value
                event.detail?.get("consent")?.let { 
                    eventData["consent"] = it 
                }
            }
            JanusEventType.EXPERIENCE_SELECTION_UPDATED -> {
                fidesEventType = FidesEventType.FIDES_UPDATED.value
                // Get current consent values from Janus
                eventData["consent"] = Janus.consent
            }
            else -> {
                // Other event types don't map to FidesJS events
                return
            }
        }

        // If we have a valid FidesJS event type, propagate it to all WebViews
        for (managedWebView in managedWebViews) {
            managedWebView.bridge.sendFidesEventToJS(
                eventType = fidesEventType,
                data = eventData
            )
        }
    }

    /**
     * Clean up resources when the manager is no longer needed
     */
    fun cleanup() {
        // Remove the Janus event listener
        janusEventListenerId?.let {
            Janus.removeConsentEventListener(listenerId = it)
            janusEventListenerId = null
        }
    }

    /**
     * Internal implementation of managed WebView creation
     * @param context The Android context
     * @param autoSyncOnStart Whether to enable initial synchronization when the webview loads
     * @param tcfWebView Whether to create a WebView specifically configured for TCF
     * @return A ManagedWebView containing the configured WebView, bridge, and ID
     */
    @SuppressLint("SetJavaScriptEnabled")
    private fun createManagedWebView(
        context: Context,
        autoSyncOnStart: Boolean,
        tcfWebView: Boolean
    ): ManagedWebView {
        // Create and configure the WebView
        val webView = WebView(context)
        
        // Configure the WebView settings
        webView.settings.apply {
            // Enable JavaScript
            javaScriptEnabled = true
            
            // Enable DOM storage
            domStorageEnabled = true
            
            // Enable cookies (deprecated in API 35+)
            if (android.os.Build.VERSION.SDK_INT < 35) {
                @Suppress("DEPRECATION")
                databaseEnabled = true
            }
            
            // Set caching mode
            cacheMode = WebSettings.LOAD_DEFAULT
            
            // Allow mixed content for older Android versions if needed
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            
            // Additional settings for better performance
            loadWithOverviewMode = true
            useWideViewPort = true
        }
        
        // Instantiate the appropriate bridge based on the tcfWebView parameter
        val bridge = if (tcfWebView) {
            TCFWebViewJSBridge()
        } else {
            FidesJSBridge()
        }
        
        // Setup the bridge, which handles JavaScript interfaces and script injection
        bridge.setupWebView(webView, autoSyncOnStart)

        // Generate unique ID and create managed WebView
        val webViewId = System.currentTimeMillis().toString() + "_" + webView.hashCode()
        val managedWebView = ManagedWebView(webViewId, webView, bridge)
        
        // Add to collection
        managedWebViews.add(managedWebView)
        
        return managedWebView
    }



    /**
     * Internal implementation of webview removal
     * @param webView The webview to remove
     */
    private fun removeWebView(webView: WebView) {
        // Check if this WebView is managed by us
        val managedWebView = managedWebViews.find { it.webView == webView }
        if (managedWebView == null) {
             Janus.log("Attempted to remove WebView not managed by this instance or already removed.", level = LogLevel.WARNING)
             return
        }
        
        // Properly teardown the bridge associated with this WebView
        managedWebView.bridge.teardownWebView(webView)
        
        // Remove from tracking
        managedWebViews.remove(managedWebView)
        
        // Clean up the WebView
        webView.apply {
            stopLoading()
            clearHistory()
            clearCache(true)
            clearFormData()
            destroy()
        }
    }
    
    /**
     * Get all currently managed WebViews
     * @return A set of all managed WebViews
     */
    fun getManagedWebViews(): Set<WebView> {
        return managedWebViews.map { it.webView }.toSet()
    }

    /**
     * Internal implementation of consent propagation used by the static method.
     *
     * @param consentValues The consent values to propagate.
     * @param excluding Optional WebView to exclude.
     * @param consentMethod Optional consent method.
     */
    private fun sendConsentToAllWebViews(
        consentValues: Map<String, Any>,
        excluding: WebView?,
        consentMethod: String?,
        fidesString: String? = null,
        tcfVersionHash: String? = null
    ) {
        // Iterate safely over a copy if modification occurs
        managedWebViews.toList().forEach { managedWebView ->
            // Skip the source WebView to prevent cycles
            if (excluding != null && managedWebView.webView == excluding) {
                Janus.log("Skipping propagation to source WebView", level = LogLevel.VERBOSE)
                return@forEach
            }

            Janus.log("Sending consent update to WebView", level = LogLevel.VERBOSE)
            managedWebView.bridge.sendConsentUpdateToJS(consentValues = consentValues, consentMethod = consentMethod, fidesString = fidesString, tcfVersionHash = tcfVersionHash)
        }
    }
} 
